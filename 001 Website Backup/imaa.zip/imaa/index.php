<?php
session_start();
include('pages/files/dbconn.php');

if(isset($_POST['login']))
{
	$login = array_map ( 'htmlspecialchars' , $_POST );
	$login = array_map ('trim',$login);
	$login = array_map ('addslashes',$login);
	
	//echo $login['username'];
	if($login['username']=='')
	{
		$errorUsername="Please enter Username.";
	}
	elseif($login['password']=='')
	{
		$errorPassword="Please enter Password."	;	
	}
	else
	{
		$checkUser=$connection->prepare("SELECT userID, name, usertype, image, designation, time	 from user where username=:username and password=:password and active=0");
		$checkUser->bindParam(":username", $login['username']);	
		$checkUser->bindParam(":password", md5($login['password']));
		$checkUser->execute();
		if($checkUser->rowCount()) // if row is returned from database/ table
		{
			$result = $checkUser->fetch(PDO::FETCH_ASSOC);
			//print_r($result);
			 $_SESSION["userID"]					=$result[userID];
			 $_SESSION["sessionUserName"]			=$result[name];
			 $_SESSION["sessionUserType"]			=$result[usertype];
			 $_SESSION["sessionUserImage"]			=$result[image];
			 $_SESSION["sessionUserDesignation"]	=$result[designation];
			 $_SESSION["sessionUserTime"]			=$result[time];
			 
			 //print_r($_SESSION);
			 
			 	echo "<script>document.location.href='pages/main.php'</script>";
			
		}
		else
		{
			$errorGeneral="Sorry!! Invalid Username or Password.";			
		}
		
		
		
	}
}
?>
<!DOCTYPE html>
<html lang="en">
    
<head>
        <title>IMAA</title><meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
        <link rel="stylesheet" href="css/matrix-login.css" />
        <link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

    </head>
    <body>
        <div id="loginbox">  
			 
            <form id="loginform" class="form-vertical" action="" method="post">
				<div class="control-group normal_text"> <h3><img src="img/logoimaa.png" alt="Logo" style="height:50%; width:50%" /></h3>
				
							<?php 
								if(isset($errorGeneral))
								{
							?>		
									<p style="color:red"><i class="icon-bell"> </i> 
							<?php 
									echo $errorGeneral;
								}?>
								</p>
				</div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
							<span class="add-on bg_lg"><i class="fa fa-user"> </i></span>
							<input type="text" name="username" placeholder="Username" />
							<?php 
								if(isset($errorUsername))
								{
							?>		
									<p style="color:red"><i class="icon-bell"> </i> 
							<?php 
									echo $errorUsername;
								}?>
								</p>
                        </div>
                    </div>
                </div>
                <div class="control-group">
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on bg_ly"><i class="fa fa-key"></i></span>
							<input type="password" name="password" placeholder="Password" />
							<?php 
								if(isset($errorPassword))
								{
							?>		
									<p style="color:red"><i class="icon-bell"> </i> 
							<?php 
									echo $errorPassword;
								}?>
								</p>
                        </div>
                    </div>
                </div>
                <div class="form-actions">
                    <span class="pull-left"><a href="#" class="flip-link btn btn-info" id="to-recover">Lost password?</a></span>
                    <span class="pull-right"><input type="submit" value="Login" name="login" href="" class="btn btn-success" /> </span>
                </div>
            </form>
            <form id="recoverform" action="#" class="form-vertical">
				<p class="normal_text">Enter your e-mail address below and we will send you instructions how to recover a password.</p>
				
                    <div class="controls">
                        <div class="main_input_box">
                            <span class="add-on bg_lo"><i class="icon-envelope"></i></span><input type="text" placeholder="E-mail address" />
                        </div>
                    </div>
               
                <div class="form-actions">
                    <span class="pull-left"><a href="#" class="flip-link btn btn-success" id="to-login">&laquo; Back to login</a></span>
                    <span class="pull-right"><a class="btn btn-info"/>Recover</a></span>
                </div>
            </form>
        </div>
        
        <script src="js/jquery.min.js"></script>  
        <script src="js/matrix.login.js"></script> 
    </body>

</html>
