<!-- PHP FUNCTIONS--> 


<?php

//function to get list of all files inside a directory in tree view
function listFolderFiles($dir){
    $ffs = scandir($dir);

    unset($ffs[array_search('.', $ffs, true)]);
    unset($ffs[array_search('..', $ffs, true)]);

    // prevent empty ordered elements
    if (count($ffs) < 1)
        return;

    echo '<ol>';
    foreach($ffs as $ff)
	{
		echo "<li><a href='".$dir."/".$ff ."' target='_blank'>" . $ff . "</a>";
		
        if(is_dir($dir.'/'.$ff)) listFolderFiles($dir.'/'.$ff);
        echo '</li>';
    }
    echo '</ol>';
}

//Calculate the number of months between two dates in PHP?

function month_difference($date1, $date2)
{
	$ts1 = strtotime($date1);
	$ts2 = strtotime($date2);
	
	$year1 = date('Y', $ts1);
	$year2 = date('Y', $ts2);
	
	$month1 = date('m', $ts1);
	$month2 = date('m', $ts2);
	
	$diff = (($year2 - $year1) * 12) + ($month2 - $month1);
	return $diff;
}

// This function to be used while changing the student batch, adding admission fee etc.

function UPDATE_BATCH_ROLL($studID)
{
	include('files/dbconn.php');
	//before updating the roll no. of the student mark his roll no. to blank;
	$connection->query("UPDATE `student` set `rollNo`='' where `studID`='$studID'");
	//get batch preference of the student
	$sql_batchPreferene="SELECT `batchPreferene` from `student` where `studID`='$studID'";
	$statement_batchPreferene= $connection->query($sql_batchPreferene);
	$data_batchPreferene=$statement_batchPreferene->fetch(PDO::FETCH_ASSOC);
	$batchPreference=$data_batchPreferene[batchPreferene];
	
	//then findout the max roll no allocated to that batchPreferene
	$sql_newRollNo="SELECT MAX(`rollNo`) as newRollNo from `student` where `batchPreferene`='$batchPreference'";
	$statement_newRollNo= $connection->query($sql_newRollNo);
	$data_newRollNo=$statement_newRollNo->fetch(PDO::FETCH_ASSOC);
	$newRollNo=$data_newRollNo[newRollNo] + 1;
	
	//Then Update the roll no of the student
	$sql_rollNo="UPDATE `student` SET `rollNo`='$newRollNo' WHERE `studID` = '$studID'";
	if($statement_rollNo = $connection->query($sql_rollNo))
	{
		echo "<script>alert('Roll No. : {$newRollNo} and Batch : {$batchPreference} allocated to the student successfully')</script>";	
	}
}

// This function is to incriment Months in format M-Y EX. $SRCdate="Dec - 2017";  IncrimentMonth($SRCdate, 14);
function IncrimentMonth($SRCdate, $incrimentValue)
{
	$dateArray=explode("-", $SRCdate);
	
	switch(trim($dateArray[0])) //$dateArray[0] -- Month
	{
		case "Jan":
			$monthNUM=1;
		break;
		
		case "Feb":
			$monthNUM=2;
		break;
		
		case "Mar":
			$monthNUM=3;
		break;
		
		case "Apr":
			$monthNUM=4;
		break;
		
		case "May":
			$monthNUM=5;
		break;
		
		case "Jun":
			$monthNUM=6;
		break;
		
		case "Jul":
			$monthNUM=7;
		break;
		
		case "Aug":
			$monthNUM=8;
		break;
		
		case "Sep":
			$monthNUM=9;
		break;
		
		case "Oct":
			$monthNUM=10;
		break;
		
		case "Nov":
			$monthNUM=11;
		break;
				
		case "Dec":
			$monthNUM=12;
		break;
	}
	
	$monthNUM=$monthNUM + $incrimentValue;
	$year=$dateArray[1]; //$dateArray[1] -- Year
	
	while($monthNUM > 12)
	{
		$monthNUM=abs(12-($monthNUM));
		$year += 1;
	}
	switch($monthNUM)
	{
			case 1:
				$monthSTR="Jan";
			break;	
			case 2:
				$monthSTR="Feb";
			break;	
			case 3:
				$monthSTR="Mar";
			break;	
			case 4:
				$monthSTR="Apr";
			break;	
			case 5:
				$monthSTR="May";
			break;	
			case 6:
				$monthSTR="Jun";
			break;	
			case 7:
				$monthSTR="Jul";
			break;	
			case 8:
				$monthSTR="Aug";
			break;	
			case 9:
				$monthSTR="Sep";
			break;	
			case 10:
				$monthSTR="Oct";
			break;	
			case 11:
				$monthSTR="Nov";
			break;	
			case 12:
				$monthSTR="Dec";
			break;	
	}
	
	$new_date= trim($monthSTR) ."-". trim($year);
	return $new_date;
}

function insertUserLog($userID, $time, $tableName, $primaryID, $action, $perticular)
{
		include('files/dbconn.php');
		$sql="INSERT INTO userlog(`userID`, `time`, `tableName`, `primaryID`, `action`, `perticular`) VALUES (:userID, :time, :tableName, :primaryID, :action, :perticular)";
		$statement = $connection->prepare($sql);
		$statement->bindParam(':userID',	$userID);
		$statement->bindParam(':time',		$time);
		$statement->bindParam(':tableName',	$tableName);
		$statement->bindParam(':primaryID',	$primaryID);
		$statement->bindParam(':action',	$action);
		$statement->bindParam(':perticular',$perticular);
		if($statement->execute())
		{
			echo "<script>alert('User Log Updated Successfully.')</script>";
		}
}

// DATE AND TIME
$timezone = new DateTimeZone("Asia/Kolkata" );
$date = new DateTime();
$date->setTimezone($timezone );

$banks=array(
"ALLAHABAD BANK",
"ANDHRA BANK",
"AXIS BANK",
"BANK OF BARODA",
"BANK OF INDIA",
"BANK OF MAHARASHTRA",
"CANARA BANK",
"CENTRAL BANK OF INDIA",
"CITIBANK",
"CITY UNION BANK LTD",
"CORPORATION BANK",
"DENA BANK",
"HDFC BANK LTD",
"HSBC",
"ICICI BANK LTD",
"IDBI BANK LTD",
"INDIAN BANK",
"INDIAN OVERSEAS BANK",
"INDUSIND BANK LTD",
"ING VYSYA BANK LTD",
"JANAKALYAN SAHAKARI BANK LTD",
"KARNATAKA BANK LTD",
"KOTAK MAHINDRA BANK",
"MAHARASHTRA STATE CO OPERATIVE BANK",
"NEW INDIA CO-OPERATIVE BANK LTD.",
"NKGSB CO-OP BANK LTD",
"ORIENTAL BANK OF COMMERCE",
"PUNJAB AND MAHARASHTRA CO-OP BANK LTD.",
"PUNJAB AND SIND BANK",
"PUNJAB NATIONAL BANK",
"RESERVE BANK OF INDIA",
"STATE BANK OF HYDERABAD",
"STATE BANK OF INDIA",
"SOUTH INDIAN BANK",
"SYNDICATE BANK",
"THE FEDERAL BANK LTD",
"UCO BANK",
"UNION BANK OF INDIA",
"UNITED BANK OF INDIA",
"VIJAYA BANK",
"YES BANK LTD"
);

$address_sms="ADMISSION OPEN, Please Contact : Sikkim Manipal University, 401, Hari Om Tower, Circular Road, Ranchi-1,Ph: 0651-2563951";
//------------------------------STATES NAME--------------------
	$states=array(
	'Andhra Pradesh'	,
	'Arunachal Pradesh'	,
	'Assam'	,
	'Bihar'	,
	'Chandigarh'	,
	'Chattisgarh'	,
	'Daman and Diu'	,
	'Delhi'	,
	'Goa'	,
	'Gujarat'	,
	'Haryana'	,
	'Himachal Pradesh'	,
	'Jammu & Kashmir'	,
	'Jharkhand'	,
	'Karnataka'	,
	'Kerala'	,
	'Lakshadweep'	,
	'Madhya Pradesh'	,
	'Manipur'	,
	'Meghalaya'	,
	'Mizoram'	,
	'Nagaland'	,
	'Orissa'	,
	'Pondicherry'	,
	'Rajasthan'	,
	'Sikkim'	,
	'Tamil Nadu'	,
	'Tripura'	,
	'Uttar Pradesh'	,
	'Uttarakhand'	,
	'West Bengal'	,
	'Nepal'	,
	);
	
$comboWidth="-----------------------------------";
$buttonstyle= "style='color:#fff; background:#336666; cursor:hand;'";
// Export Table to excel
// Email
function email($Message)
{
	$ToEmail="info@thesynergy.in; shahzada83@gmail.com; thesynergy.smu@gmail.com";
	$ToSubject="THESYNERGY-Mail from Website";
	$headers .= "Content-type: text; charset=iso-8859-1\r\n";
	$headers .= "From:".'thesynergy@thesynergy.in'."\r\n";
	
	mail($ToEmail,$ToSubject,$Message, $headers);
}

// checkEmail() Check Valid Email ID
function checkEmail($emailID)
{
if(!$result=ereg("^[^@ ]+@[^@ ]+\.[^@ ]+$",$emailID,$trashed) and $emailID!="")
		{
		echo "<script>alert('Please enter valid Email ID')</script>";
		}
}

//-------------------ROW COLOR----
function color($counter)
{
	if($counter%2==0)
	{
		echo "#F2F2FF";
	}
	else
	{
		echo "#fff";	
	}
}
//------SHORT DATE------------
function short_date($date)
{
$string=explode("/",$date);
$new_date=	$string[2]."-".$string[1]."-".$string[0];

return $new_date;
}

function date_mask($date)
{
$string=explode("-",$date);
$new_date=	$string[2]."/".$string[1]."/".$string[0];

return $new_date;	
}

function format_date($date)
{
$string=explode("-",$date);
$new_date=	$string[2]."-".$string[1]."-".$string[0];

return $new_date;
}
/*
// API to send free SMS
function SMS($phone, $msg)
{
echo file_get_contents("http://s1.freesmsapi.com/messages/send?skey=7739020000THESYNERGY&message=".urlencode($msg)."&recipient=$phone") . "<br>";
}
*/

//API for SMS Gupshup.com (enterprose.smsgupshup.com)
/*function SMS($phone, $msg)
{
	$link= "http://sendsms.gngsms.com/sendsms?uname=shahzada83&pwd=shahzada83&senderid=DC_SMU&to=".$phone."&msg=".$msg."&route=A";
	
	echo "<script>document.location.href='$link';</script>";
	
}
*/

function SMSpromotional($phone, $msg)
{
	if(trim($phone)=='' || trim($msg)=='')
	{
		die();
	}
	else
	{
	
	$date=date("d-M-Y");
	$request =""; //initialise the request variable
	$param[method]= "sendMessage";
	$param[send_to] = "91".$phone;
	$param[msg] = $msg;
	$param[userid] = "2000102030";
	$param[password] = "shahzada83";
	$param[v] = "1.1";
	$param[msg_type] = "TEXT"; //Can be "FLASH�/"UNICODE_TEXT"/�BINARY�
	$param[auth_scheme] = "PLAIN";
	//Have to URL encode the values
	foreach($param as $key=>$val) {
	$request.= $key."=".urlencode($val);
	//we have to urlencode the values
	$request.= "&";
	//append the ampersand (&) sign after each parameter/value pair
	}
	$request = substr($request, 0, strlen($request)-1);
	//remove final (&) sign from the request
	$url ="http://enterprise.smsgupshup.com/GatewayAPI/rest?".$request;
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$curl_scraped_page = curl_exec($ch);
	curl_close($ch);
	echo $curl_scraped_page."<br>";
	// Track The SMS Sent, Store the record in Database
	$sent_time=mktime();
	$sender=$logedUser;
	$sent_date=date("Y-m-d");
	$sql="INSERT INTO `sms_sent` (`slno` , `user` ,	`sent_date` ,	`sent_time` ,	`mobile` ,	`msg`)
							VALUES (NULL , '$logedUser', '$sent_date', '$sent_time', '$phone', '$msg')";
	
	$result=mysql_query($sql);	
	}
}


function SMS($phone, $msg)
{
	if(trim($phone)=='' || trim($msg)=='')
	{
		die();
	}
	else
	{
	
	$date=date("d-M-Y");
	$request =""; //initialise the request variable
	$param[method]= "sendMessage";
	$param[send_to] = "91".$phone;
	$param[msg] = $msg;
	$param[userid] = "2000100739";
	$param[password] = "tan2345Shahzada";
	$param[v] = "1.1";
	$param[msg_type] = "TEXT"; //Can be "FLASH�/"UNICODE_TEXT"/�BINARY�
	$param[auth_scheme] = "PLAIN";
	//Have to URL encode the values
	foreach($param as $key=>$val) {
	$request.= $key."=".urlencode($val);
	//we have to urlencode the values
	$request.= "&";
	//append the ampersand (&) sign after each parameter/value pair
	}
	$request = substr($request, 0, strlen($request)-1);
	//remove final (&) sign from the request
	$url ="http://enterprise.smsgupshup.com/GatewayAPI/rest?".$request;
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$curl_scraped_page = curl_exec($ch);
	curl_close($ch);
	echo $curl_scraped_page."<br>";
	// Track The SMS Sent, Store the record in Database
	$sent_time=mktime();
	$sender=$logedUser;
	$sent_date=date("Y-m-d");
	$sql="INSERT INTO `sms_sent` (`slno` , `user` ,	`sent_date` ,	`sent_time` ,	`mobile` ,	`msg`)
							VALUES (NULL , '$logedUser', '$sent_date', '$sent_time', '$phone', '$msg')";
	
	$result=mysql_query($sql);	
	}
}

// Refresh Page
function refresh()
{
	echo "<META HTTP-EQUIV=Refresh CONTENT='0'>"; 	
}
// number to text
function convert_number($number) 
{ 
    if (($number < 0) || ($number > 999999999)) 
    { 
    	//throw new Exception("Number is out of range");
    } 
	
    $Gn = floor($number / 100000);  /* Lakh (giga) */ 
    $number -= $Gn * 100000; 
    $kn = floor($number / 1000);     /* Thousands (kilo) */ 
    $number -= $kn * 1000; 
    $Hn = floor($number / 100);      /* Hundreds (hecto) */ 
    $number -= $Hn * 100; 
    $Dn = floor($number / 10);       /* Tens (deca) */ 
    $n = $number % 10;               /* Ones */ 

    $res = ""; 

    if ($Gn) 
    { 
        $res .= convert_number($Gn) . " Lakh"; 
    } 

    if ($kn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($kn) . " Thousand"; 
    } 

    if ($Hn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($Hn) . " Hundred"; 
    } 

    $ones = array("", "One", "Two", "Three", "Four", "Five", "Six", 
        "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", 
        "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", 
        "Nineteen"); 
    $tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", 
        "Seventy", "Eigthy", "Ninety"); 

    if ($Dn || $n) 
    { 
        if (!empty($res)) 
        { 
            $res .= " and "; 
        } 

        if ($Dn < 2) 
        { 
            $res .= $ones[$Dn * 10 + $n]; 
        } 
        else 
        { 
            $res .= $tens[$Dn]; 

            if ($n) 
            { 
                $res .= "-" . $ones[$n]; 
            } 
        } 
    } 

    if (empty($res)) 
    { 
        $res = "zero"; 
    } 

    return $res; 
} 
//-----------Counter-------------

function counter()
{
	if (file_exists('count_file.txt'))
	{
		$fi1=fopen('count_file.txt',r);
		$dat=fread($fi1, filesize('count_file.txt'));
		$sno=$dat+1;
		fclose($fi1);
		$fi1=fopen('count_file.txt', w);
		fwrite($fi1, $dat+1);
	}
	else
	{
		$fi1=fopen('count_file.txt',w);
		fwrite($fi1,1);
		$sno= '1';
		fclose($fi1);
	}
}
//-----------Counter-------------
?>

<!-- JAVA SCRIPT FUNCTIONS--> 
<script language="javascript">
//Function to check if the field contain numeric value or not
// how to call : <input name="registration_no" type="text" id="registration_no" size="35"  onKeyPress="return isNumberKey(event)"  value= "xyx" >
function isNumberKey(evt)
{ 
	var charCode = (evt.which)?evt.which:event.keyCode;
	if((charCode>=48 && charCode <=57) ||  charCode==46 || charCode==8 || charCode==109 || charCode==189)
	{
		return true;
	}
	else
	{
	alert('Please Enter Numeric Value Only.');
		return false;	
	}
}
// popu window for call
function add_call(stud_slno)
{
//var a=a.id
var ra=Math.random();

window.open("../file/add_call.php?stud_slno="+stud_slno+"&num="+ra,"_blank", "toolbar=no, address=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=520, height=500");
}
//-------------------------------------------------------------------------------------------------------------------------

// popu window for followup_create
function add_followup(prospects_slno)
{
//var a=a.id
var ra=Math.random();

window.open("../file/add_followup.php?prospects_slno="+prospects_slno+"&num="+ra,"_blank", "toolbar=no, address=no, location=yes, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=920, height=550");
}
//-------------------------------------------------------------------------------------------------------------------------
function edit_prospects(prospects_slno)
{
//var a=a.id
var ra=Math.random();

window.open("../file/edit_prospects.php?prospects_slno="+prospects_slno+"&num="+ra,"_blank", "toolbar=no, address=no, location=yes, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=920, height=550");
}
//Edit student
function student_edit(slno)
{
//var a=a.id
var ra=Math.random();

window.open("../offline/student_edit.php?slno="+slno+"&num="+ra,"_blank", "toolbar=no, address=no, location=yes, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=920, height=550,");
}
function confirm_action(ans) 
{
	return confirm(ans);
}
function confirmPassout() 
{
	return confirm("The student will be Marked Passout. Are you sure?");
}
function confirmDropout() 
{
	return confirm("The student will be Marked Dropout. Are you sure?");
}
//-----------------------------------------------
// Check add_cash_chequ_detail.php for Usage
// Used to Hide or Show Table or <div tag>
function setVisibility(id, visibility)
{
	document.getElementById(id).style.display = visibility;
}
	function captcha()
	{
		var text = "";
		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	
		for( var i=0; i < 5; i++ )
			text += possible.charAt(Math.floor(Math.random() * possible.length));
	
		document.getElementById('captchaDisplay').innerHTML=text;
		document.getElementById('verifyCaptcha').value=text;
		/*
			---HTML CODE---
			<span id="captchaDisplay"></span>
			<input type="hidden" name="verifyCaptcha" id="verifyCaptcha" value="" />
			<input name="captcha" type="text" id="captcha" class="form-control" placeholder="Enter the Code Here" style="width:130px" />
		*/
	}	
	
	
</script>

	<!-- DROPDOWN Textbox
		<input type="text" name="myText" value="Norway" selectBoxOptions="Canada;Denmark;Finland;Germany;Mexico">
	-->
	
	<!-- DROPDOWN Textbox
		<input list="column">
		<datalist id="column">
			<option>Admission Fee</option>
		</datalist>
	-->	