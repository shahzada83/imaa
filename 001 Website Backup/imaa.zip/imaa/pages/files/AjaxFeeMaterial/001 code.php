<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="js/jquery-3.2.1.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#insert').click(function(event){
			event.preventDefault();
			$.ajax({
				url: "date.php",
				method: "post",
				data: $('form').serialize(),
				dataType: "text",
				success: function (strDate){
						$('#show_date').text(strDate)
					}
				})
			})
		})
</script>

</head>

<body>
<div id="show_date"></div>

<form method="post">
	<input name="name" id="name" type="text" />
	<input name="email" id="email" type="text" />
	<input name="mobile" id="mobile" type="text" />
	<input name="insert" id="insert" type="submit" value="name" />
</form>
</body>
</html>