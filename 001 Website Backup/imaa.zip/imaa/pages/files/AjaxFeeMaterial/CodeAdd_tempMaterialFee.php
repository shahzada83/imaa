<?php
include('../dbconn.php');
if(isset($_POST))
{
	//print_r($_POST);	
	
	$addTempMaterialFee=array_map('htmlspecialchars',$_POST);
  	$addTempMaterialFee=array_map('trim',$addTempMaterialFee);
  	$addTempMaterialFee=array_map('addslashes',$addTempMaterialFee);
	
	
	$string		=	explode("/",$addTempMaterialFee[payDate]);
	$payDate	=	$string[2]."-".$string[1]."-".$string[0];
	
	$studID		=$addTempMaterialFee[studID]; 
	$receiptNo		=$addTempMaterialFee[receiptNo]; 
	//$payMode		=$addTempMaterialFee[payMode]; 
	//$bankName		=$addTempMaterialFee[bankName]; 
	//$chequeNo		=$addTempMaterialFee[chequeNo]; 
	//$ChequeDate		=$addTempMaterialFee[ChequeDate] ;
	$materialName	=$addTempMaterialFee[materialID]; 
	$quality		=$addTempMaterialFee[quality]; 
	$size			=$addTempMaterialFee[size] ;
	$price			=$addTempMaterialFee[price]; 
	$discount		=$addTempMaterialFee[discount] ;
	$due			=$addTempMaterialFee[due] ;
	$rowTotal		=$addTempMaterialFee[rowTotal]; 
	//$remark			=$addTempMaterialFee[remark]; 
	
	$sqlMaterialID="SELECT materialID from materialdetail where `itemName`='$materialName'	 and	`size`='$size'	and 	`quality`='$quality'";
	$stmtMaterialID=$connection->query($sqlMaterialID);
	$dataMaterialID=$stmtMaterialID->fetch(PDO::FETCH_ASSOC);
	
	$materialID=$dataMaterialID[materialID];
	
	//INSERT INTO `imaa`.`temp_materialfee` (`studID`, `receiptNo`, `materialID`, `productName`, `quality`, `size`, `price`, `discount`, `due`, `feeCollected`, `saveToStudentFee`, `date`) 
	//								VALUES (`studID`, `receiptNo`, `materialID`, `productName`, `quality`, `size`, `price`, `discount`, `due`, `feeCollected`, `saveToStudentFee`, `date`) 
	
	$sqlInserttemp_materialFee="INSERT INTO `temp_materialfee` ( `studID`, `receiptNo`, `materialID`, `productName`, `quality`, `size`, `price`, `discount`, `due`, `feeCollected`, `saveToStudentFee`, `date`) 
														VALUES ( '$studID', '$receiptNo', '$materialID', '$materialName', '$quality', '$size', '$price', '$discount', '$due', '$rowTotal', '1', '$payDate') ";
	if($stmtInserttemp_materialFee=$connection->query($sqlInserttemp_materialFee))													
	{
		echo "
				<div class='alert alert-success alert-dismissable'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <h4>	<i class='icon fa fa-check'></i> Success !</h4>
                    The record saved successfully.
                </div>
			";	
	}
}

?>