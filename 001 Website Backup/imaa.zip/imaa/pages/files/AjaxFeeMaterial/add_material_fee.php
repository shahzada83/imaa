<form action="" method="post" name="formFeeMaterial" id="formFeeMaterial">
<div class="box box-solid box-warning">
	<div class="box-header">
		<?php 
		$studentName = ($studentTable['gender']=="Male")?'Mr. ':'Miss. ';
		$studentName .= ucwords(strtolower($studentTable['name']));
		?>
		  <h3 class="box-title"><i class="fa fa-shopping-cart"></i> Add Fee Details Against Material Purchase By <b> <?php echo $studentName; ?></b> </h3>
		  <div class="box-tools pull-right">
			<button class="btn btn-box-tool" data-widget=""><i class="fa fa-times" onclick="document.getElementById('formMaterial').style.display=='none'"></i></button>
		  </div><!-- /.box-tools -->
	</div><!-- /.box-header -->
	
	<div class="box-body">
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Date</label>
					<input name="payDate" type="text" class="form-control input-sm" id="payDate" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="efeedate"></span>
				</div>
			</div>
		
			<div class="col-md-2">
				<div class="form-group">
					<?php
					$receiptNo = file_get_contents('receiptNo')+1;
					
					?>
					<label class="label_font">Receipt No.</label>
					<input class="form-control input-sm" type="text" name="receiptNo"  readonly="readonly" value="<?php echo $receiptNo; ?>" >
					<span class="error" id="ereceiptNo"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Payment Mode</label>
					<select class="form-control input-sm" name="payMode" id="payModeMaterial" onChange="showPaymentModeMaterial()">
						<option value='Cash' 		<?php if($addStudentFee['paymentMode']=='Cash')			{?> selected="selected" <?php } ?>>Cash</option>
						<option value='Cheque' 		<?php if($addStudentFee['paymentMode']=='Cheque')		{?> selected="selected" <?php } ?>>Cheque</option>
						<option value='NEFT/ RTGS' 	<?php if($addStudentFee['paymentMode']=='NEFT/ RTGS')	{?> selected="selected" <?php } ?>>NEFT/ RTGS</option>
					</select>
					<span class="error" id="epaymentMode"></span>
				</div>
			</div>	
			
			<div class="col-md-2" id="paymentModeBankMaterial">
				<div class="form-group">
					<label class="label_font">Bank Name</label>
					<select class="form-control input-sm" type="text" name="bankName" onChange="document.getElementById('egender').innerHTML ='';">
						<option value='' 		<?php if($addStudentFee['bankName']=='')			{?> selected="selected" <?php } ?>>--- SELECT BANK NAME ---</option>
						<?php
						foreach($banks as $bank) // Getting $banks value from API.php
						{
						?>
							<option value='<?php echo $bank; ?>' <?php if($addStudentFee['bankName']==$bank){?> selected="selected" <?php } ?>><?php echo $bank; ?></option>
						<?php
						}
						?>
						
					</select>
					<span class="error" id="eadmissionFee"></span>
				</div>
			</div>
			
			<div class="col-md-2" id="paymentModeChequeNoMaterial">
				<div class="form-group">
					<label class="label_font">Cheque No./ Ref. No.</label>
					<input class="form-control input-sm" type="text" name="chequeNo" value="<?php echo $addStudentFee['chequeNo']; ?>"  placeholder="" onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="4">
					<span class="error" id="eIDcardFee"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group" id="paymentModeTransactionDateMaterial">
					<label class="label_font">Cheque/ Trans. Date</label>
					<input name="ChequeDate" type="text" class="form-control input-sm" id="ChequeDate" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="eChequeDate"></span>
				</div>
			</div>
			
		
		</div>
		
		<div class="row">
			
		</div>
	</div><!-- /.box-body -->
</div><!-- /.box -->
</form>