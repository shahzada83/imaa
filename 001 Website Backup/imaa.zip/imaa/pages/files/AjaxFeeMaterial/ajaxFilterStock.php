<script src="files/AjaxFeeMaterial/js/jquery-3.2.1.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('#insert').click(function(event){
			event.preventDefault();
			$.ajax({
				url: "getQuality.php",
				method: "post",
				data: $('form').serialize(),
				dataType: "text",
				success: function (strDate){
						$('#show_date').text(strDate)
					}
				})
			})
		})
</script>