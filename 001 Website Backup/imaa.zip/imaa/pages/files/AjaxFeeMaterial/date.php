<?php
		//echo date("d-M-Y");
		
		//$name=$_POST[name];
		//echo $name;
		
		print_r($_POST);
		echo $_POST[name];
		echo $_POST[mobile];
		echo $_POST[email];
?>