<?php


require('../dbconn.php');


if(isset($_GET['materialID']))
{
     $sql = "DELETE from  temp_materialfee where  materialID=".$_GET['materialID'];
     $connection->query($sql);
	
	 echo "
				<div class='alert alert-danger alert-dismissable'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <h4>	<i class='icon fa fa-check'></i> Deleted !</h4>
                    The Record Deleted successfully.
                </div>
			";
}


?>