<?php


require('../dbconn.php');


if(isset($_GET['StockRowID']))
{
     $sql = "DELETE from stockentry where  stockID=".$_GET['StockRowID'];
     $connection->query($sql);
	
	 echo "
				<div class='alert alert-danger alert-dismissable'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <h4>	<i class='icon fa fa-check'></i> Deleted !</h4>
                    The Record Deleted successfully.
                </div>
			";
}


?>