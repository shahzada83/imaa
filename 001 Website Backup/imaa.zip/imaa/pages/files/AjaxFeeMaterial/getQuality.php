<?php 
include('../dbconn.php');

$itemName=$_GET[itm];

$sqlQuality="SELECT distinct(quality) as quality from materialdetail where itemName='$itemName'";
$stmtQuality=$connection->query($sqlQuality);

$strOption="<option></option>";
while($dataQuality=$stmtQuality->fetch(PDO::FETCH_ASSOC))
{

	$strOption .="<option>{$dataQuality[quality]}</option>";

}

echo  $strSelect= $strOption ;
?>