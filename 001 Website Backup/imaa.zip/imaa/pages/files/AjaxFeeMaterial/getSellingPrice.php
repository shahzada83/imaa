<?php
include('../dbconn.php');
$item = $_GET[itm];
$quality =$_GET[quality];
$size=$_GET[size];

$sqlGetSellingPrice="SELECT sellingPrice from materialdetail where itemName='$item' and size='$size' and quality='$quality'";
$stmtGetSellingPrice=$connection->query($sqlGetSellingPrice);
$dataGetSellingPrice=$stmtGetSellingPrice->fetch(PDO::FETCH_ASSOC);

echo $dataGetSellingPrice[sellingPrice];

?>
