<?php 
include('../dbconn.php');

$itemName=$_GET[itm];
$quality=$_GET[qty];

$sqlSize="SELECT distinct(size) as size from materialdetail where itemName='$itemName' and quality='$quality'";
$stmtSize=$connection->query($sqlSize);

$strOption="<option></option>";
while($dataSize=$stmtSize->fetch(PDO::FETCH_ASSOC))
{

	$strOption .="<option>{$dataSize[size]}</option>";

}

echo  $strSelect= $strOption ;
?>