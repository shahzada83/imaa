<?php
include('../dbconn.php');
include('../API.php');
$billNo=$_GET[billNo];

$sqlBillStock="SELECT * from stockentry where BillNo='$billNo' and deleted=0 and materialDetailUpdate=1";
$stmtBillStock=$connection->query($sqlBillStock);
if($stmtBillStock->rowCount())
{
	$tableHead="
			<tr>
				<th>SL No.</th>
				<th>Bill No</th>
				<th>Bill Date</th>
				<th>Item Name</th>
				<th>Quality</th>
				<th>Size</th>
				<th>Quantity</th>
				<th>Cost Price</th>
				<th>Total</th>
				<th>Select <br>To Save</th>
			<th>
			";
	while($dataBillStock=$stmtBillStock->fetch(PDO::FETCH_ASSOC))
	{
		$tableData .="<tr id=" . $dataBillStock[stockID] . ">
						<td>".++$slno."</td>
						<td>$dataBillStock[BillNo]</td>
						<td>". format_date($dataBillStock[BillDate]) ."</td>
						<td>$dataBillStock[itemName]</td>
						<td>$dataBillStock[quality]</td>
						<td>$dataBillStock[size]</td>
						<td>$dataBillStock[receivedQty]</td>
						<td>$dataBillStock[costPrice]</td>
						<td>".$dataBillStock[receivedQty] * $dataBillStock[costPrice]."</td>
						<td><input type='checkbox' class='green' name='stockIDCheckBox[]' value=".$dataBillStock[stockID]."></td>
						<td>
							<a href='#' class='btn btn-danger btn-sm' id='deleteStockRow' onclick='DeleteStockRow(".$dataBillStock[stockID].")'>Delete</a>
						</td>
					</tr>";
		
	}
	
	$table=$tableHead . $tableData;
	echo $table;
}
?>