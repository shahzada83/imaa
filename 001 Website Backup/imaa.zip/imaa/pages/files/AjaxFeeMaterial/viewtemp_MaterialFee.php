
<?php
include('../dbconn.php');
include('../API.php');
$studID=$_GET[studID];

$sqlTempMaterialFee="SELECT * from  temp_materialfee where `studID`='$studID' and saveToStudentFee=1";
$stmtTempMaterialFee=$connection->query($sqlTempMaterialFee);
if($stmtTempMaterialFee->rowCount())
{
	$tableHead="
			<tr>
				<th>SL No.</th>
				<th>Receipt No</th>
				<th>Date</th>
				<th>Prod.ID</th>
				<th>Product Name</th>
				<th>Quality</th>
				<th>Size</th>
				<th>Item Price</th>
				<th>Discount</th>
				<th>Due</th>
				<th>Fee Collected</th>
			<th>
			";
	while($dataTempMaterialFee=$stmtTempMaterialFee->fetch(PDO::FETCH_ASSOC))
	{
		$tableData .="<tr id=" . $dataTempMaterialFee[stockID] . ">
						<td>".++$slno."</td>
						<td>$dataTempMaterialFee[receiptNo]</td>
						<td>". format_date($dataTempMaterialFee[date]) ."</td>
						<td>$dataTempMaterialFee[materialID]</td>
						<td>$dataTempMaterialFee[productName]</td>
						<td>$dataTempMaterialFee[quality]</td>
						<td>$dataTempMaterialFee[size]</td>
						<td>$dataTempMaterialFee[price]</td>
						<td>$dataTempMaterialFee[discount]</td>
						<td>$dataTempMaterialFee[due]</td>
						<td>$dataTempMaterialFee[feeCollected]</td>
						
						<td>
							<a href='#' class='btn btn-danger btn-sm' id='deleteMaterialRow' onclick='DeleteMaterialRow(".$dataTempMaterialFee[materialID].")'>Delete</a>
						</td>
					</tr>";
		
	}
	
	$table=$tableHead . $tableData;
	echo $table;
}
?>