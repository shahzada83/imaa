
<?php
include('../dbconn.php');
include('../API.php');

$studID=$_GET[studID];

$sqlTempMaterialFee="SELECT * from  temp_materialfee where `studID`='$studID' and saveToStudentFee=1";
$stmtTempMaterialFee=$connection->query($sqlTempMaterialFee);
if($stmtTempMaterialFee->rowCount())
{
	$tableHead="
			<table id=\"divTable\" class=\"table table-bordered table-striped table-responsive\">
			<tr>
				<th>SL No.</th>
				<th>Receipt No</th>
				<th>Date</th>
				<th>Prod.ID</th>
				<th>Product Name</th>
				<th>Quality</th>
				<th>Size</th>
				<th>Item Price</th>
				<th>Discount</th>
				<th>Due</th>
				<th>Fee Collected</th>
				<th>Check To <br>Save</th>
			<th>
			";
	while($dataTempMaterialFee=$stmtTempMaterialFee->fetch(PDO::FETCH_ASSOC))
	{
		$tableData .="<tr id=" . $dataTempMaterialFee[stockID] . ">
						<td>".++$slno."</td>
						<td>$dataTempMaterialFee[receiptNo]</td>
						<td>". format_date($dataTempMaterialFee[date]) ."</td>
						<td>$dataTempMaterialFee[materialID]</td>
						<td>$dataTempMaterialFee[productName]</td>
						<td>$dataTempMaterialFee[quality]</td>
						<td>$dataTempMaterialFee[size]</td>
						<td>$dataTempMaterialFee[price]</td>
						<td>".$dataTempMaterialFee[discount]."</td>
						<td>$dataTempMaterialFee[due]</td>
						<td>$dataTempMaterialFee[feeCollected]</td>
						<td><input type='checkbox' name='saveFeeMaterial[]' value=".$dataTempMaterialFee[slno]."></td>
						<td>
							
						</td>
					</tr>";
			$price += $dataTempMaterialFee[price];	
			$discount += $dataTempMaterialFee[discount];	
			$due += $dataTempMaterialFee[due];	
			$feeCollected += $dataTempMaterialFee[feeCollected];		
					
	}
	
	$tableData .="<tr id=" . $dataTempMaterialFee[stockID] . ">
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td><strong>TOTAL :</strong></td>
						<td><strong>$price</strong></td>
						<td><strong>$discount</strong></td>
						<td><strong>$due</strong></td>
						<td><strong><input type='text' id='totalReceived' readonly class='no-border' value='$feeCollected'></strong></td>
						<td></td>
						<td>
							
						</td>
					</tr>";
					
	$table=$tableHead . $tableData ."</table>";
	echo $table;
}
?>