<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<script language="javascript">
	//Function to check if the field contain numeric value or not
	// how to call : <input name="registration_no" type="text" id="registration_no" size="35"  onKeyPress="return isNumberKey(event)"  value= "xyx" >
	function isNumberKey(evt)
	{ 
		var charCode = (evt.which)?evt.which:event.keyCode;
		if((charCode>=48 && charCode <=57) ||  charCode==46 || charCode==8 || charCode==109 || charCode==189)
		{
			return true;
		}	
		else
		{
		alert('Please Enter Numeric Value Only.');
			return false;	
		}
	}
	
	function validateEmail()
	{
	 
	   var emailID = document.addStudentForm.email.value;
	   atpos = emailID.indexOf("@");
	   dotpos = emailID.lastIndexOf(".");
	   if (atpos < 1 || ( dotpos - atpos < 2 )) 
	   {
		   alert("Please Enter Valid Email ID of the User.");
		   document.addStudentForm.email.focus();
		   document.getElementById('eemail').innerHTML ="Invalid Email ID";
		   return false;
	   }
	   return( true );
	}

	function validate(e)
	{
		//alert('');
		if( document.addStudentForm.formNo.value == "")
	    {
			 alert( "Please Enter Form no." );
			 document.addStudentForm.formNo.focus() ;
			 document.getElementById('eFormNo').innerHTML ="Form No. can't be Blank";
			 return false;
	    }
		if( document.addStudentForm.admDate.value == "")
	    {
			 alert( "Please Enter Admission Date." );
			 document.addStudentForm.admDate.focus() ;
			 document.getElementById('eAdmDate').innerHTML ="Admission Date. can't be Blank";
			 return false;
	    }
		/*
		if( document.addStudentForm.karateAdmID.value == "")
	    {
			 alert( "Please Enter Karate Admission ID." );
			 document.addStudentForm.karateAdmID.focus() ;
			 document.getElementById('ekarateAdmID').innerHTML ="Karate Admission ID. can't be Blank";
			 return false;
	    }
		
		if( document.addStudentForm.rollNo.value == "")
	    {
			 alert( "Please Enter Roll No." );
			 document.addStudentForm.rollNo.focus() ;
			 document.getElementById('erollNo').innerHTML ="Roll No. can't be Blank";
			 return false;
	    }
		*/
		if( document.addStudentForm.name.value == "")
	    {
			 alert( "Please Enter Student's Name." );
			 document.addStudentForm.name.focus() ;
			 document.getElementById('ename').innerHTML ="Please enter Student's Name";
			 return false;
	    }
		
		
		if( document.addStudentForm.dob.value == "" )
	    {
			 alert( "Please enter Student's Date of Birth." );
			 document.addStudentForm.dob.focus() ;
			 document.getElementById('edob').innerHTML ="Date of Birth can't be blank";
			 return false;
	    }
		
		if( document.addStudentForm.gender.value == "" )
	    {
			 alert( "Please select Gender of the student." );
			 document.addStudentForm.gender.focus() ;
			 document.getElementById('egender').innerHTML ="Gender can't be None";
			 return false;
	    }
		
				
		if( document.addStudentForm.aadharNo.value != "" && document.addStudentForm.aadharNo.value.length != 12 )
	    {
			//alert(document.addStudentForm.aadharNo.value.length);
			 alert( "Please Enter Valid Aadhar No. of the student." );
			 document.addStudentForm.aadharNo.focus() ;
			 document.getElementById('eaadharNo').innerHTML ="Invalid Aadhar No. - It should be 12 Digit.";
			 return false;
	    }
		
		if( document.addStudentForm.fatherName.value=='')
	    {
			 alert( "Please Enter student's Father's Name." );
			 document.addStudentForm.fatherName.focus() ;
			 document.getElementById('efatherName').innerHTML ="Father name can't be Blank.";
			 return false;
	    }
		
		if( document.addStudentForm.address.value=='')
	    {
			 alert( "Please Enter student's Complete Address." );
			 document.addStudentForm.address.focus() ;
			 document.getElementById('eaddress').innerHTML ="Address can't be Blank.";
			 return false;
	    }
		
	    if( document.addStudentForm.mobile.value=='')
	    {
			 alert( "Please Enter student's Mobile No." );
			 document.addStudentForm.mobile.focus() ;
			 document.getElementById('emobile').innerHTML ="Mobile No. can't be Blank.";
			 return false;
	    }
		
		if( document.addStudentForm.mobile.value.length != 10 )
	    {
			//alert(document.addStudentForm.aadharNo.value.length);
			 alert( "Please Enter Valid Mobile No. of the student." );
			 document.addStudentForm.mobile.focus() ;
			 document.getElementById('emobile').innerHTML ="Invalid Mobile No. - It should be 10 Digit.";
			 return false;
	    }
		
		
		if( document.addStudentForm.email.value != '' )
	    {
		 // Put extra check for data format
			 var ret = validateEmail();
			 if( ret == false )
			 {
				  return false;
			 }
	    }
		/*
		if( document.addStudentForm.bloodGroup.value=='')
	    {
			 alert( "Please Enter student's Blood Group." );
			 document.addStudentForm.bloodGroup.focus() ;
			 document.getElementById('ebloodGroup').innerHTML ="Blood group can't be blank.";
			 return false;
	    }
		
		if( document.addStudentForm.height.value=='')
	    {
			 alert( "Please Enter student's Height." );
			 document.addStudentForm.height.focus() ;
			 document.getElementById('eheight').innerHTML ="Height can't be blank.";
			 return false;
	    }
		
		if( document.addStudentForm.weight.value=='')
	    {
			 alert( "Please Enter student's Weight." );
			 document.addStudentForm.weight.focus() ;
			 document.getElementById('eweight').innerHTML ="Weight can't be blank.";
			 return false;
	    }
		*/
		if( document.addStudentForm.occupation.value != '' && document.addStudentForm.orgName.value == '' )
	    {
				if( document.addStudentForm.occupation.value == 'Student')
				{
					  alert( "Please Enter School/ College Name of the Student." );
					  document.addStudentForm.orgName.focus() ;
					  document.getElementById('eorgName').innerHTML ="Enter School/ College Name";
					   return false;
				}
		
				if( document.addStudentForm.occupation.value == 'Working')
				{
					  alert( "Please Enter Company Name of the Student." );
					  document.addStudentForm.orgName.focus() ;
					  document.getElementById('eorgName').innerHTML ="Enter Company Name";
					   return false;
				}
		
	    }
		
		if( document.addStudentForm.batchPreferene.value=='')
	    {
			 alert( "Please Select batch Preference of the student." );
			 document.addStudentForm.batchPreferene.focus() ;
			 document.getElementById('ebatchPreferene').innerHTML ="Batch Preference can't be None";
			 return false;
	    }
		
		if( document.addStudentForm.disability.value=='')
	    {
			 alert( "Please Select Disability option ." );
			 document.addStudentForm.disability.focus() ;
			 document.getElementById('edisability').innerHTML ="Disability Option can't be None";
			 return false;
	    }
		
		if( document.addStudentForm.disability.value=='Yes' &&  document.addStudentForm.disabilityDetail.value=="")
	    {
			 alert( "Please enter Disability Details ." );
			 document.addStudentForm.disabilityDetail.focus() ;
			 document.getElementById('edisabilityDetail').innerHTML ="Disability Details can't be blank";
			 return false;
	    }
		
	}
</script>		
<?php

// ************FUNCTION USED ****************
//function validateAddStudent()
//function insertDataIntoStudentTable($addStudent)

if(isset($_POST['add_student']))
{	
  $addStudent=array_map('htmlspecialchars',$_POST);
  $addStudent=array_map('trim',$addStudent);
  $addStudent=array_map('addslashes',$addStudent);
  //echo "<pre>";
  //print_r($addStudent);
  
  validateAddStudent($addStudent);
}


function validateAddStudent($addStudent)
{
		
		
		if($addStudent['formNo']== "")
	    {
			 echo "<script>alert('Please Enter Form no.')</script>";
	    }
		
		elseif($addStudent['admDate']== "")
	    {
			 echo "<script>alert( 'Please Enter Admission Date.' )</script>";
	    }
		/*
		elseif($addStudent['karateAdmID']== "")
	    {
			 echo "<script>alert( 'Please Enter Karate Admission ID.' )</script>";
	    }
		
		elseif($addStudent['rollNo']== "")
	    {
			 echo "<script>alert( 'Please Enter Roll No.' )</script>";
	    }
		*/
		elseif($addStudent['name']== "")
	    {
			 echo "<script>alert( 'Please Enter Student's Name.' )</script>";
	    }
		
		elseif($addStudent['dob']== "" )
	    {
			 echo "<script>alert( 'Please enter Student\'s Date of Birth.' )</script>";
	    }
		
		elseif($addStudent['gender']== "" )
	    {
			 echo "<script>alert('Please select Gender of the student.' )</script>";
	    }
		
				
		elseif($addStudent['aadharNo']!= "" && strlen($addStudent['aadharNo']) != 12 )
	    {
			 echo "<script>alert('Please Enter Valid Aadhar No. of the student.')</script>";
	    }
		
		elseif($addStudent['fatherName']=='')
	    {
			 echo "<script>alert('Please Enter student\'s Father\'s Name.' )</script>";
	    }
		
		elseif($addStudent['address']=='')
	    {
			 echo "<script>alert('Please Enter student's Father's Name.')</script>";
	    }
		
	    elseif($addStudent['mobile']=='')
	    {
			 echo "<script>alert('Please Enter student's Mobile No.')</script>";
	    }
		
		elseif(!$result=ereg("^[^@ ]+@[^@ ]+\.[^@ ]+$", $addStudent['email'],$trashed) and $addStudent['email'] != "")
		{
			 echo "<script>alert('Please enter valid Email ID')</script>";
		}
	    /*		
		elseif($addStudent['bloodGroup']=='')
	    {
			 echo "<script>alert('Please Enter student's Blood Group.')</script>";
	    }
		
		elseif($addStudent['height']=='')
	    {
			 echo "<script>alert('Please Enter student's Height.')</script>";
	    }
		
		elseif($addStudent['weight']=='')
	    {
			 echo "<script>alert('Please Enter student's Weight.')</script>";
	    }
		*/
		
		elseif($addStudent['occupation']!= '' &&$addStudent['orgName']== '' )
	    {
				if($addStudent['occupation']== 'Student')
				{
					   echo "<script>alert('Please Enter School/ College Name of the Student.' )</script>";
				}
		
				if($addStudent['occupation']== 'Working')
				{
					   echo "<script>alert('Please Enter Company Name of the Student.')</script>";
				}
	    }
		
		elseif($addStudent['batchPreferene']=='')
	    {
			 echo "<script>alert('Please Select batch Preference of the student.')</script>";
	    }
		
		elseif($addStudent['disability']=='')
	    {
			 echo "<script>alert('Please Select Disability option .')</script>";
	    }
		
		elseif($addStudent['disability']=='Yes' && $addStudent['disabilityDetail']=='')
	    {
			 echo "<script>alert('Please enter Disability Details .')</script>";
	    }
		else
		{
			// Insert data
			insertDataIntoStudentTable($addStudent);
		}
}

function insertDataIntoStudentTable($addStudent)
{
	
	include('files/dbconn.php');
	
	/*
	// CHECK if the formNo already exists in the table
	$sqlInsertStudent="INSERT INTO `student` (`formNo`, `admDate` , `currentBelt`, `gradingFor`, `name`, `dob`, `gender`, `aadharNo`, `whatsapp`, `fatherName`, `address`, `mobile`, `email`, `bloodGroup`, `height`, `weight`, `occupation`, `orgName`, `batchPreferene`, `disability`, `disabilityDetail`, `remark`, `admID`, `createdBy`) 
	SELECT * FROM (SELECT :formNo, :admDate, :currentBelt, :gradingFor, :name, :dob, :gender, :aadharNo, :whatsapp, :fatherName, :address, :mobile, :email, :bloodGroup, :height, :weight, :occupation, :orgName, :batchPreferene, :disability, :disabilityDetail, :remark, :admID, :createdBy)  AS tmp
	WHERE NOT EXISTS (
    SELECT formNo FROM `student` WHERE formNo = :formNo) LIMIT 1;";
	*/
	
	$sqlInsertStudent="INSERT INTO  `student` (`formNo`, `formNoActual`, `admDate` ,  `currentBelt`, `name`, `dob`, `gender`, `aadharNo`, `whatsapp`, `fatherName`, `address`, `mobile`, `email`, `bloodGroup`, `height`, `weight`, `occupation`, `orgName`, `batchPreferene`, `disability`, `disabilityDetail`, `remark`, `admID`, `createdBy`) 
										VALUES (:regNo, :formNo, :admDate, :currentBelt, :name, :dob, :gender, :aadharNo, :whatsapp, :fatherName, :address, :mobile, :email, :bloodGroup, :height, :weight, :occupation, :orgName, :batchPreferene, :disability, :disabilityDetail, :remark, :admID, :createdBy)";	
	
	//$statement = $connection->query($sqlInsertStudent);
	
	$statement = $connection->prepare($sqlInsertStudent);
	//echo $addStudent['formNo'] . "<br>";
	
	$statement->bindParam(':regNo',			$addStudent['regNo']);
	$statement->bindParam(':formNo',	$addStudent['formNo']);
	
	$admDate=short_date($addStudent['admDate']);
	$statement->bindParam(':admDate',		$admDate	);
	$statement->bindParam(':currentBelt',	$addStudent['currentBelt']);
	$statement->bindParam(':name',			$addStudent['name']);

	$dob=short_date($addStudent['dob']);
	$statement->bindParam(':dob',			$dob);
	$statement->bindParam(':gender',		$addStudent['gender']);
	$statement->bindParam(':aadharNo',		$addStudent['aadharNo']);
	$statement->bindParam(':whatsapp',		$addStudent['whatsapp']);
	$statement->bindParam(':fatherName',	$addStudent['fatherName']);
	$statement->bindParam(':address',		$addStudent['address']);
	$statement->bindParam(':mobile',		$addStudent['mobile']);
	$statement->bindParam(':email',			$addStudent['email']);
	$statement->bindParam(':bloodGroup',	$addStudent['bloodGroup']);
	$statement->bindParam(':height',		$addStudent['height']);
	$statement->bindParam(':weight',		$addStudent['weight']);
	$statement->bindParam(':occupation',	$addStudent['occupation']);
	$statement->bindParam(':orgName',		$addStudent['orgName']);
	$statement->bindParam(':batchPreferene',$addStudent['batchPreferene']);
	$statement->bindParam(':disability',	$addStudent['disability']);
	$statement->bindParam(':disabilityDetail',$addStudent['disabilityDetail']);
	$statement->bindParam(':remark', 		$addStudent['remark']);
	$statement->bindParam(':admID',			$addStudent['admID']);
	$statement->bindParam(':createdBy',		$_SESSION['userID']);
	//print_r($statement);
	
	if($statement->execute())
	{
		echo "<script>alert('Student Record saved Successfully')</script>";
		
		//Insert into userLog table******************************************
		$userID=$_SESSION['userID'];
		$time=mktime();
		$tableName='student';	
		$primaryID="admID-" . $addStudent['admID'];
		$action='INSERT';
		$perticular="New Admission Record Entered: Form No. - {$addStudent['formNo']}, Student Name - {$addStudent['name']}";
		// Call the Function insertUserLog() defined in API.php
		insertUserLog($userID, $time, $tableName, $primaryID, $action, $perticular);
		//Insert into userLog table******************************************
		
		//Insert Data in Index Table
		insertIndex($addStudent['admID']);
		echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$addStudent['admID']}'</script>";		
	}
	else
	{
		echo "<script>alert('Form No. {$addStudent['formNo']} already exists.')</script>";
	}
}

function insertIndex($admID)
{
	include('files/dbconn.php');
	
	// Get the studID first
	$sql="SELECT studID from student where admID=:admID";
	$statement=$connection->prepare($sql);
	$statement->bindParam(":admID", $admID);
	$statement->execute();
	if(!$statement->rowCount()) // if row is returned from database/ table
	{
		echo "<script>alert('Form No. {$addStudent['formNo']} already exists.')</script>";
	}
	else
	{
		$studID_DB=$statement->fetch(PDO::FETCH_ASSOC);
		$studID=$studID_DB[studID];
		
		// Second : insert the fetched studID into index table
		
		$sql="INSERT INTO  `index` (`indexID` ,`studID`) VALUES (NULL ,  :studID)";
		$statement=$connection->prepare($sql);
		$statement->bindParam(":studID", $studID);
		if($statement->execute())
		{
			echo "<script>alert('Index Table updated successfully')</script>";
		}
	}
}



?>