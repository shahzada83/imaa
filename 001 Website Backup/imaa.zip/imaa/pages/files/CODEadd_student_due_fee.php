<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<style>
#paymentModeBankService{display:none;}
#paymentModeChequeNoService{display:none;}
#paymentModeTransactionDateService{display:none;}
</style>
<script>


function calculateDuePayment()
{
	var myForm 		= document.formStudentDueFee;
	var duePay 		= myForm.elements['duePayAmount[]'];
	var actualDue 	= myForm.elements['actualDue[]'];
	
	var netTotal=0;
	
	for (var i = 0; i < duePay.length; i++) 
	{
		var DueFieldAmount 		= duePay[i].value;
		var ActualDueAmount 	= actualDue[i].value; // this control is to validate that the fee collected is not more than the actual due amount
		if(parseInt(DueFieldAmount) > parseInt(ActualDueAmount))
		{
			alert('Invalid Due Amount. Fee Collected cannot be greater than Actual Due Amount i.e. Rs. '+ActualDueAmount);
			duePay[i].value='';	
			return false;
		}
		else
		{		
			netTotal= parseFloat(netTotal) + parseFloat(DueFieldAmount);
		}
	}
		if(netTotal<0)
		{
			alert('Invalid Discount Amount!!');
			duePay[i].value='';
		}
		else
		{
			document.getElementById('totalDueReceived').value = netTotal;
		}
}
</script>

<?php
if(isset($_POST[add_student_due_fee]))
{
	$payDate 				= short_date($_POST['payDateService']);
    $New_receiptNo 			= $_POST[receiptNoDue];
    $payMode				= $_POST[payModeDue];
    $bankName 				= $_POST[bankNameDue];
    $chequeNo				= $_POST[chequeNoDue];
    $ChequeDate 			= $_POST[ChequeDateDue];
	$OldReceiptNo_array 	= $_POST[studentfee_receiptNo];
	$remarkDue					= $_POST[remarkDue];
	$totalDueReceived		= $_POST[totalDueReceived];
	$feeID_Studentfee_array 		= $_POST[feeID_Studentfee];
	$studentfee_feeDetailID_array	= $_POST[studentfee_feeDetailID];
	$studentfee_feeForMonth_array	= $_POST[studentfee_feeForMonth];		
	$studentfee_receiptNo_array		= $_POST[studentfee_receiptNo];
	$actualDue_array 				= $_POST[actualDue];
	$duePayAmount_array 			= $_POST[duePayAmount];
	$createdBy		= $_SESSION[userID];
	$createdOn		= mktime();
	
	//echo "<pre>";
	//print_r($feeID_Studentfee_array);
	$sqlCheckReceiptNo="select studID from studentfee where receiptNo='$receiptNo'";
	$stmtCheckReceiptNo=$connection->query($sqlCheckReceiptNo);
	if($stmtCheckReceiptNo->rowCount())
	{	
		 echo "<script>alert('Receipt No. : {$receiptNo} already exists.')</script>";
	}
		
	
	$controlIndex_studentfee=0;
	foreach($feeID_Studentfee_array as $studentfee_feeID)
	{
		if($duePayAmount_array[$controlIndex_studentfee] > 0 )
		{	
			$feeID_SF 			= 	$feeID_Studentfee_array[$controlIndex_studentfee];
			$feeDetailID_SF		=	$studentfee_feeDetailID_array[$controlIndex_studentfee];
			$feeForMonth_SF		=	$studentfee_feeForMonth_array[$controlIndex_studentfee];	
			$Old_receiptNo_SF	=	$studentfee_receiptNo_array[$controlIndex_studentfee];
			$actualDue_SF		=	$actualDue_array[$controlIndex_studentfee];
			$receivedDue_SF		=	$duePayAmount_array[$controlIndex_studentfee];
			$OldReceiptNo		=	$OldReceiptNo_array[$controlIndex_studentfee];
				
			$DueRemark="Received Rs. {$receivedDue_SF} against Old Due of Rs. {$actualDue_SF}, vide Receipt No. : {$New_receiptNo}, as Due Fee Payment on - {$payDate}. ";
			
			$sqlStudentFeeDue="INSERT INTO `studentfee` (`studID`, `feeDetailID`, `feeForMonth`, `receiptNo`, `payDate`, `payMode`, `payModeRemark`, `amount`, `receivedAmount`, `dues`, `remark`, `createdBy`, `createdOn`) 
												 VALUES (:studID,  :feeDetailID, :feeForMonth , :receiptNo,  :payDate,  :payMode,  :payModeRemark,  :amount, :receivedAmount,  :dues, :remark, :createdBy, :createdOn)"; 
															  
			$statementStudentFeeDue=$connection->prepare($sqlStudentFeeDue);
			
			$statementStudentFeeDue -> bindparam(":studID", 		$studID );
			$statementStudentFeeDue -> bindparam(":feeDetailID", 	$feeDetailID_SF ); // Assume feeDetailID 0 
			$statementStudentFeeDue -> bindparam(":receiptNo", 		$New_receiptNo );
			$statementStudentFeeDue -> bindparam(":feeForMonth", 		$feeForMonth_SF );
			$statementStudentFeeDue -> bindparam(":payDate", 		$payDate );
			$statementStudentFeeDue -> bindparam(":payMode", 		$payMode );
			$payModeRemark=$bankName ."-". $chequeNo ."-". $ChequeDate;
			$statementStudentFeeDue -> bindparam(":payModeRemark", 	$payModeRemark );
			$statementStudentFeeDue -> bindparam(":amount",			$receivedDue_SF);
			$statementStudentFeeDue -> bindparam(":receivedAmount",			$receivedDue_SF);
			$new_due=$actualDue_SF - $receivedDue_SF;
			$statementStudentFeeDue -> bindparam(":dues",			$new_due);
			
			$statementStudentFeeDue -> bindparam(":remark", 		$new_due);
			$statementStudentFeeDue -> bindparam(":createdBy", 		$createdBy);
			$statementStudentFeeDue -> bindparam(":createdOn", 		$createdOn);
			
			if($stmt = $statementStudentFeeDue -> execute())
			{
				$sqlUpdateOldReceiptNo="UPDATE studentfee set dues=0, duesRemark='$DueRemark' where feeID='$feeID_SF'";
				if($connection->query($sqlUpdateOldReceiptNo))
				{
						/*echo "<script>alert('Old Receipt No. {$Old_receiptNo_SF} updated Successfully!')</script>";	*/
						$sqlUpdateMonthlyFeeSummery="UPDATE monthlyfeesummery set dues='$new_due' where receiptNo='$Old_receiptNo_SF' and feeDetailID='$feeDetailID_SF'";
						if($connection->query($sqlUpdateMonthlyFeeSummery))
						{
							echo "<script>alert('Due against Receipt No. {$Old_receiptNo_SF} for amount Rs. {$receivedDue_SF}, updated Successfully!')</script>";
						}
				}
			} //if($stmt = $statementStudentFeeDue -> execute())
		} //if($duePayAmount_array[$controlIndex_studentfee] > 0 )
	$controlIndex_studentfee++;		
	}//foreach($feeID_Studentfee_array as $studentfee_feeID)
	file_put_contents('receiptNo',$receiptNo); // Update fee Receipt
	echo "<script>window.open('files/view_receipt.php?rcpt={$receiptNo}', '_blank')</script>";
	echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$admID}'</script>";
} //if(isset($_POST[add_student_due_fee]))
?>
