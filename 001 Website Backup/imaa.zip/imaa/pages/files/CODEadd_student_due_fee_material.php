<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<style>
#paymentModeBankService{display:none;}
#paymentModeChequeNoService{display:none;}
#paymentModeTransactionDateService{display:none;}
</style>
<script>


function calculateDuePaymentItem()
{
	
	var myForm 		= document.formStudentItemDue;
	var duePay 		= myForm.elements['NewPaid[]'];
	var actualDue 	= myForm.elements['oldDues[]'];
	
	var netTotal=0;
	
	for (var i = 0; i < duePay.length; i++) 
	{
		var DueFieldAmount 			= duePay[i].value;
		var ActualDueAmount 		= actualDue[i].value; // this control is to validate that the fee collected is not more than the actual due amount
		
		//alert(DueFieldAmount);
		
		if(parseInt(DueFieldAmount) > parseInt(ActualDueAmount))
		{
			alert('Invalid Due Amount. Fee Collected cannot be greater than Actual Due Amount i.e. Rs. '+ActualDueAmount);
			duePay[i].value='';	
			return false;
		}
		else
		{		
			netTotal= netTotal + parseInt(DueFieldAmount);
			//alert(netTotal);
			
		}
	}
		if(netTotal<0)
		{
			alert('Invalid Discount Amount!!');
			duePay[i].value='';
		}
		else
		{
			
			document.getElementById('totalReceivedItem2').value = netTotal;
		}
	//alert(netTotal)
}
</script>

<?php
if(isset($_POST[add_student_due_fee_item]))
{
	$payDateItem 						= short_date($_POST['payDateItem']);
    $receiptNoItem 						= $_POST[receiptNoItem];
    $payModeitem						= $_POST[payModeitem];
    $bankNameItem 						= $_POST[bankNameItem];
    $chequeNoItem						= $_POST[chequeNoItem];
    $ChequeDateItem 					= short_date($_POST[ChequeDateItem]);
    $remarkItem 						= $_POST[remarkItem];
    $totalReceivedItem 					= $_POST[totalReceivedItem];
	
	//Below are array Control
	
	$oldFeeID 			= $_POST[oldFeeID];
	$feeDetailIDitem	= $_POST[feeDetailIDitem];
	$oldReceiptNo		= $_POST[oldReceiptNo];
	$oldItemName		= $_POST[oldItemName];
	$oldQuality 		= $_POST[oldQuality];
	$oldSize			= $_POST[oldSize];
	$oldDues			= $_POST[oldDues];		
	$oldAmount			= $_POST[oldAmount];		
	$NewPaid			= $_POST[NewPaid];
	
	$saveRecord 		= $_POST[NewPaid];

	//print_r($feeDetailIDitem);
	
	$createdBy		= $_SESSION[userID];
	$createdOn		= mktime();
	
	//echo "<pre>";
	//echo count($saveRecord);
	
	$sqlCheckReceiptNo="select studID from studentfee where receiptNo='$receiptNo'";
	$stmtCheckReceiptNo=$connection->query($sqlCheckReceiptNo);
	if($stmtCheckReceiptNo->rowCount())
	{	
		 echo "<script>alert('Receipt No. : {$receiptNo} already exists.')</script>";
	}
	
	for($index=0; $index < count($saveRecord); $index++)
	{
		if($NewPaid[$index] > 0 )
		{	
			$oldFeeID2 			= $oldFeeID[$index];
			$feeDetailIDitem2	= $feeDetailIDitem[$index];
			$oldReceiptNo2		= $oldReceiptNo[$index];
			$oldItemName2		= $oldItemName[$index];
			$oldQuality2 		= $oldQuality[$index];
			$oldSize2			= $oldSize[$index];
			$oldDues2			= $oldDues[$index];		
			$oldAmount2			= $oldAmount[$index];		
			$NewPaid2			= $NewPaid[$index];
			
			
			
			$DueRemark="Received Rs. {$NewPaid2} against Old Due of Rs. {$oldDues2}, Old Receipt No. : {$oldReceiptNo2}. ";
			
			$sqlStudentFeeDue="INSERT INTO `studentfee` (`studID`, `itemName`, `feeDetailID`, `receiptNo`, `payDate`, `payMode`, `payModeRemark`, `amount`, `receivedAmount`, `dues`,`duesRemark`, `remark`, `createdBy`, `createdOn`) 
												 VALUES (:studID,   :itemName, :feeDetailID, :receiptNo,  :payDate,  :payMode,  :payModeRemark,  :amount, :receivedAmount,  :dues, :duesRemark, :remark, :createdBy, :createdOn)"; 
															  
			$statementStudentFeeDue=$connection->prepare($sqlStudentFeeDue);
			
			$statementStudentFeeDue -> bindparam(":studID", 		$studID );
			$statementStudentFeeDue -> bindparam(":feeDetailID", 	$feeDetailIDitem2 ); // Assume feeDetailID 0 
			$statementStudentFeeDue -> bindparam(":itemName", 		$oldItemName2 );
			$statementStudentFeeDue -> bindparam(":receiptNo", 		$receiptNoItem );
			$statementStudentFeeDue -> bindparam(":payDate", 		$payDateItem );
			$statementStudentFeeDue -> bindparam(":payMode", 		$payModeitem );
			
			$payModeRemark=$bankNameItem ."-". $chequeNoItem ."-".  $ChequeDateItem;
			$statementStudentFeeDue -> bindparam(":payModeRemark", 	$payModeRemark );
			$statementStudentFeeDue -> bindparam(":amount",			$oldAmount2);//*******
			$statementStudentFeeDue -> bindparam(":receivedAmount",	$NewPaid2);
			
			$new_due=$oldDues2 - $NewPaid2;
			$statementStudentFeeDue -> bindparam(":dues",			$new_due);
			$statementStudentFeeDue -> bindparam(":duesRemark",		$DueRemark);
			
			$statementStudentFeeDue -> bindparam(":remark", 		$remarkItem);
			$statementStudentFeeDue -> bindparam(":createdBy", 		$createdBy);
			$statementStudentFeeDue -> bindparam(":createdOn", 		$createdOn);
			
			if($stmt = $statementStudentFeeDue -> execute())
			{
				$DueRemarkOld="Paid Rs. {$NewPaid2} against Old Due of Rs. {$oldDues2}, New Receipt No. : {$receiptNoItem}. ";
				$sqlUpdateOldReceiptNo="UPDATE studentfee set `dues`=0, `duesRemark`='$DueRemarkOld' where `feeID`='$oldFeeID2'";
				if($connection->query($sqlUpdateOldReceiptNo))
				{
						/*echo "<script>alert('Old Receipt No. {$Old_receiptNo_SF} updated Successfully!')</script>";	*/
						$sqlUpdateMonthlyFeeSummery="UPDATE monthlyfeesummery set dues='$new_due' where `receiptNo`='$oldReceiptNo2' and feeDetailID='$feeDetailIDitem2'";
						if($connection->query($sqlUpdateMonthlyFeeSummery))
						{
							echo "<script>alert('Due against Receipt No. {$oldReceiptNo2} for amount Rs. {$NewPaid2}, updated Successfully!')</script>";
						}
				}
			} //if($stmt = $statementStudentFeeDue -> execute())
		} //if($duePayAmount_array[$index] > 0 )
	
	}//foreach($feeID_Studentfee_array as $studentfee_feeID)
	file_put_contents('receiptNo',$receiptNoItem); // Update fee Receipt
	 
		echo "<script>window.open('files/view_receipt_material.php?rcpt={$receiptNoItem}', '_blank')</script>";
		echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$admID}'</script>";
		
} //if(isset($_POST[add_student_due_fee]))
?>
