<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<style>
#paymentModeBankMaterial{display:none;}
#paymentModeChequeNoMaterial{display:none;}
#paymentModeTransactionDateMaterial{display:none;}
</style>
<script>


function calculateMaterial()
{
	var myForm 		= document.formStudentFeeMaterial;
	var discount 	= myForm.elements['discount[]'];
	var dues 		= myForm.elements['dues[]'];
	var totalFee 	= myForm.elements['totalFee[]'];
	var amount		= myForm.elements['amount[]'];
	
	var netTotal=0;
	
	for (var i = 0; i < discount.length; i++) 
	{
		var discountValue 	= discount[i].value;
		var totalFeetValue	= totalFee[i].value;
		var amountValue 	= amount[i].value;
		var duesValue		= dues[i].value;
		
		if(discountValue == '')
		{
			totalFeetValue = '';
		}
		if(discountValue != '' || duesValue != '')
		{
			totalFeetValue = (amountValue - discountValue - duesValue);
			netTotal= parseFloat(netTotal) + parseFloat(totalFeetValue);
			document.getElementById('totalReceived').value = netTotal;
		}
		if(totalFeetValue<0)
		{
			alert('Invalid Discount Amount!!');
			discount[i].value='';
		}
		else
		{
			totalFee[i].value = totalFeetValue;
			document.getElementById('totalReceived').value = netTotal;
		}
	}
}

function showPaymentModeMaterial() // This function is called from select option named paymentMode
{
		if(document.getElementById('payModeMaterial').value != "Cash")
	    {
			 document.getElementById('paymentModeBankMaterial').style.display="block"
			 document.getElementById('paymentModeChequeNoMaterial').style.display="block"
			 document.getElementById('paymentModeTransactionDateMaterial').style.display="block"
	    }
		if(document.getElementById('payModeMaterial').value == "Cash")
	    {
			document.getElementById('paymentModeBankMaterial').style.display="none"
			 document.getElementById('paymentModeChequeNoMaterial').style.display="none"
			 document.getElementById('paymentModeTransactionDateMaterial').style.display="none"
	    }
}

</script>		
<?php

if(isset($_POST['add_studentFeeMaterial']))
{	
  	$payDate 		= short_date($_POST['payDate']);
    $receiptNo 		= $_POST[receiptNo];
    $payMode		= $_POST[payMode];
    $bankName 		= $_POST[bankName];
    $chequeNo		= $_POST[chequeNo];
    $ChequeDate 	= $_POST[ChequeDate];
	
		
    $remark 		= $_POST[remark];
	$createdBy		= $_SESSION[userID];
	$createdOn		= mktime();
	
	$studID; // This value is coming from view_student_profile.php
	
	// Check if receipt No. already exists
	$sqlCheckReceiptNo="select studID from studentfee where receiptNo='$receiptNo'";
	$stmtCheckReceiptNo=$connection->query($sqlCheckReceiptNo);
	if($stmtCheckReceiptNo->rowCount())
	{	
		 echo "<script>alert('Receipt No. : {$receiptNo} already exists.')</script>";
	}
		
	elseif($receiptNo== "")
	{
		 echo "<script>alert('Please Enter Receipt No.')</script>";
	}
	
	elseif($payMode != "Cash" && ($bankName =='' || $chequeNo =='' || $ChequeDate =='dd/mm/yyyy'))
	{
		 echo "<script>alert( 'Please Enter Bank Name, Cheque/ Reference No. and Transaction Date' )</script>";
	}
	else
	{
		
		$saveFeeMaterial=$_POST[saveFeeMaterial];
		//print_r($saveFeeMaterial);
		foreach($saveFeeMaterial as $slNo)
		{
			// fetch the values from temp_MaterialFee
			
			$sql_temp_materialfee="select * from temp_materialfee where slno='$slNo'";
			$stmt_temp_materialfee=$connection->query($sql_temp_materialfee);
			$data_temp_materialfee=$stmt_temp_materialfee->fetch(PDO::FETCH_ASSOC);
			
			$studID_DB		=$data_temp_materialfee[studID];
			$feeDetailID	=$data_temp_materialfee[materialID];
			$itemName		=$data_temp_materialfee[productName];
			$productName	=$data_temp_materialfee[productName];
			$receiptNo		=$_POST[receiptNo];
			$payModeRemark=$bankName ."-". $chequeNo ."-". $ChequeDate;
			$amount			=$data_temp_materialfee[price];
			$receivedAmount	=$data_temp_materialfee[feeCollected];
			$discount		=$data_temp_materialfee[discount];
			$dues			=$data_temp_materialfee[due];
			
			// save record
			
			$sqlStudentFee="INSERT INTO `studentfee` (`studID`, `feeDetailID`, `itemName`, `receiptNo`, `payDate`, `payMode`, `payModeRemark`, `amount`, `receivedAmount`, `discount`, `dues`, `remark`, `createdBy`, `createdOn`) 
											VALUES (:studID,  :feeDetailID, :itemName, :receiptNo,  :payDate,  :payMode,  :payModeRemark,  :amount, :receivedAmount, :discount,  :dues, :remark, :createdBy, :createdOn)"; 
														  
						$statementStudentFee=$connection->prepare($sqlStudentFee);
						
						$statementStudentFee -> bindparam(":studID", 		$studID );
						$statementStudentFee -> bindparam(":feeDetailID", 	$feeDetailID );
						$statementStudentFee -> bindparam(":itemName", 		$itemName );
						$statementStudentFee -> bindparam(":receiptNo", 	$receiptNo );
						$statementStudentFee -> bindparam(":payDate", 		$payDate );
						$statementStudentFee -> bindparam(":payMode", 		$payMode );
						$statementStudentFee -> bindparam(":payModeRemark", $payModeRemark );
						$statementStudentFee -> bindparam(":amount",		$amount);
						$statementStudentFee -> bindparam(":receivedAmount",$receivedAmount);
						$statementStudentFee -> bindparam(":discount",		$discount);
						$statementStudentFee -> bindparam(":dues",			$dues);
						$statementStudentFee -> bindparam(":remark", 		$remark);
						$statementStudentFee -> bindparam(":createdBy", 	$createdBy);
						$statementStudentFee -> bindparam(":createdOn", 	$createdOn);
						
						if($statementStudentFee -> execute())
						{
							echo "<script>alert('{$productName} updated Successfully!')</script>";	
							
							//Update saveToStudentFee field in  temp_materialfee table
							
							$sql_update_saveToStudentFee="UPDATE temp_materialfee SET saveToStudentFee=0 where `slno`='$slNo'";
							$connection->query($sql_update_saveToStudentFee);
							
							// Store the actual data as summery in monthlyfeeSummery table for reference
								$studID				=$studID;	
								$payDate			=short_date($_POST['payDate']);
								$feeDetailID		=$feeDetailID;
								$studentfeeID		=$createdOn;
								$receiptNo			=$receiptNo;
								$feeFrom			="NA";
								$feeTill			="NA";
								$totalMonths		=0;
								$feePerMonth		=$amount;
								$lateFine			=0;
								$discount			=$discount;	
								$dues				=$dues;	
								$totalFeeReceived	=$receivedAmount;
								$createdOn			=$createdOn;
								$createdBy			=$createdBy;
								
								$sqlMonthlyFeeSummery="INSERT INTO `monthlyfeesummery` (`studID`, `payDate`, `feeDetailID`, `studentfeeID`, `receiptNo`, `feeFrom`, `feeTill`, `totalMonths`, `feePerMonth`, `lateFine`, `discount`, `dues`, `totalFeeReceived`, `createdOn`, `createdBy`) 
																				VALUES ('$studID', '$payDate', '$feeDetailID', '$studentfeeID', '$receiptNo', '$feeFrom', '$feeTill', '$totalMonths', '$feePerMonth', '$lateFine', '$discount', '$dues', '$totalFeeReceived', '$createdOn', '$createdBy')";
								
								if($statementMonthlyFeeSummery=$connection->query($sqlMonthlyFeeSummery))
								{
										echo "<script>alert('Fee SUMMERY updated Successfully!')</script>";			
								}		
						}
		
		
		}	//foreach($saveFeeMaterial as $slNo)
		file_put_contents('receiptNo',$receiptNo); // Update fee Receipt
		echo "<script>window.open('files/view_receipt_material.php?rcpt={$receiptNo}', '_blank')</script>";
		echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$admID}'</script>";
	}
} //if(isset($_POST['add_studentFee']))
?>