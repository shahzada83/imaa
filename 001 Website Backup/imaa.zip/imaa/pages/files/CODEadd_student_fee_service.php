<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<style>
#paymentModeBankService{display:none;}
#paymentModeChequeNoService{display:none;}
#paymentModeTransactionDateService{display:none;}
</style>
<script>


function calculateService()
{
	var myForm 		= document.formStudentFeeService;
	var discount 	= myForm.elements['discountService[]'];
	var dues 		= myForm.elements['duesService[]'];
	var totalFee 	= myForm.elements['totalFeeService[]'];
	var amount		= myForm.elements['amountService[]'];
	
	var netTotal=0;
	
	for (var i = 0; i < discount.length; i++) 
	{
		var discountValue 	= discount[i].value;
		var totalFeetValue	= totalFee[i].value;
		var amountValue 	= amount[i].value;
		var duesValue		= dues[i].value;
		var totalMonthlyfee	= document.getElementById('TotalMonthlyFee').value;
		if(discountValue == '')
		{
			totalFeetValue = '';
		}
		if(discountValue != '' || duesValue != '')
		{
			totalFeetValue = (amountValue - discountValue - duesValue);
			netTotal= parseInt(netTotal) + parseInt(totalFeetValue) + parseInt(totalMonthlyfee);
			document.getElementById('totalReceivedService').value = netTotal;
		}
		if(totalFeetValue<0)
		{
			alert('Invalid Discount Amount!!');
			discount[i].value='';
		}
		else
		{
			totalFee[i].value = totalFeetValue;
			document.getElementById('totalReceivedService').value = netTotal;
		}
	}
}

function showPaymentModeService() // This function is called from select option named paymentMode
{
		if(document.getElementById('payModeService').value != "Cash")
	    {
			 document.getElementById('paymentModeBankService').style.display="block"
			 document.getElementById('paymentModeChequeNoService').style.display="block"
			 document.getElementById('paymentModeTransactionDateService').style.display="block"
	    }
		if(document.getElementById('payModeService').value == "Cash")
	    {
			document.getElementById('paymentModeBankService').style.display="none"
			 document.getElementById('paymentModeChequeNoService').style.display="none"
			 document.getElementById('paymentModeTransactionDateService').style.display="none"
	    }
}

function calculateMonthlyFee()
{
	if(document.getElementById("checkHeadMonthlyFee2").checked == true)
	{		//alert();
			var MonthlyFee 			= Number(document.getElementById('monthlyFee').value);
			var TotalMonth 			= Number(document.getElementById('feeTill').selectedIndex + 1);  // Selects option "One"
			var LateFine 			= Number(document.getElementById('lateFine').value);
			var monthlyDiscount 	= Number(document.getElementById('monthlyDiscount').value);
			var monthlyDues 		= Number(document.getElementById('monthlyDues').value);
			//document.getElementById('lateFineNoMonths').innerHTML="("+TotalMonth+")";
			// Code below to calculate Latefine as per the months (feetill) field selected
			// if 2 months fee is only being paid by the student then calculate late fine for ony two month
			// this can be acived by spliting lateFineString value
			//alert(document.getElementById('checkHeadMonthlyFee2').checkedValue);
			if(monthlyDues>=MonthlyFee)
			{
				alert('Dues cannot be Greater than or Equal To - Rs. '+MonthlyFee+' (Monthly Fee).Please Correct the Month.');
				document.getElementById('monthlyDues').value='';
			}
			var str = document.getElementById('lateFineString').value;
			var res = str.split(";");
			//Now get the months selected, i.e. TotalMonth
			// run a loop
			var latefine=0;
			for(var i=0; i<TotalMonth; i++)
			{
				if(res[i])
				{
					latefine += parseFloat(res[i]);
				}
				else
				{
					latefine=0;
				}	
			}
			document.getElementById('lateFine').value=latefine;
			//-----------------------------------------------------------------------------------------------------------
			var NetTotal=MonthlyFee * TotalMonth + LateFine - monthlyDiscount - monthlyDues;
			if(NetTotal<=0)
			{
				alert('Invalid Total Amount.');	
			}
			else
			{
				document.getElementById('TotalMonthlyFee').value =  NetTotal; //TotalMonthlyFee=amount control
			}
			
			//alert("You are about to collect Monthly Fee for : " + TotalMonth + " Months. \n Fee Per Month : Rs. " + MonthlyFee + ".\n Total Fee : Rs. " + TotalMonth*MonthlyFee);
			
			document.getElementById('totFee2').innerHTML = "        (Rs. : " + MonthlyFee * TotalMonth + ")";
			document.getElementById('totalReceivedService').value =  NetTotal;
			document.getElementById('errmsg').innerHTML="";
	}

			else
			{
				document.getElementById('errmsg').innerHTML="<i class='fa  fa-arrow-circle-o-left'></i> Please select Check Box to Save Monthly Fee. ";	
				alert('Please select Check Box to Save Monthly Fee.');
			}
}
</script>		
<?php

if(isset($_POST['add_studentFeeService']))
{	
  	$payDate 		= short_date($_POST['payDateService']);
    $receiptNo 		= $_POST[receiptNoService];
    $payMode		= $_POST[payModeService];
    $bankName 		= $_POST[bankNameService];
    $chequeNo		= $_POST[chequeNoService];
    $ChequeDate 	= $_POST[ChequeDateService];
	
    $feeDetailID 	= $_POST[feeDetailIDService];		// ARRAY
	$checkHead		=$_POST[checkHeadService];			// ARRAY
	$feeHead		= $_POST[feeHeadService];			// ARRAY
    
	
	$amount 		= $_POST[amountService];					// ARRAY
    $discount 		= $_POST[discountService];					// ARRAY
	$dues 			= $_POST[duesService];						// ARRAY
    $totalFee	= $_POST[totalFeeService];					// ARRAY
    
    $remark 		= $_POST[remarkService];
	$createdBy		= $_SESSION[userID];
	$createdOn		= mktime();
	
	$studID; // This value is coming from view_student_profile.php
	
	$sqlCheckReceiptNo="select studID from studentfee where receiptNo='$receiptNo'";
	$stmtCheckReceiptNo=$connection->query($sqlCheckReceiptNo);
	if($stmtCheckReceiptNo->rowCount())
	{	
		 echo "<script>alert('Receipt No. : {$receiptNo} already exists.')</script>";
	}
		
	elseif($receiptNo == "")
	{
		 echo "<script>alert('Please Enter Receipt No.')</script>";
	}
	
	elseif($payMode != "Cash" && ($bankName =='' || $chequeNo =='' || $ChequeDate =='dd/mm/yyyy'))
	{
		 echo "<script>alert( 'Please Enter Bank Name, Cheque/ Reference No. and Transaction Date' )</script>";
	}
	else
	{
		//------------------------------------------------------------------------------------------
		// CODE to save all data except Monthly Fee
		$ControlArrayIndex = 0; 
		foreach($feeDetailID as $feeID)
		{
			
			if($totalFee[$ControlArrayIndex] != 0 && $checkHead[$ControlArrayIndex]=='') // Total has been done, but check box is not selected
			{
				 echo "<script>alert( 'Please select Fee Head to save Record.' )</script>";
			}
			else
			{
				if(($totalFee[$ControlArrayIndex] != '' || $totalFee[$ControlArrayIndex] != 0) && $checkHead[$ControlArrayIndex]=='1') // Insert only those data which are entered by the user i.e. amount is not blank, if amount is blank or 0, that means that perticular fee is not received
				{
					$sqlStudentFee="INSERT INTO `studentfee` (`studID`, `feeDetailID`, `receiptNo`, `payDate`, `payMode`, `payModeRemark`, `amount`, `receivedAmount`, `discount`, `dues`, `remark`, `createdBy`, `createdOn`) 
													  VALUES (:studID,  :feeDetailID,  :receiptNo,  :payDate,  :payMode,  :payModeRemark,  :amount, :receivedAmount, :discount,  :dues, :remark, :createdBy, :createdOn)"; 
													  
					$statementStudentFee=$connection->prepare($sqlStudentFee);
					
					$statementStudentFee -> bindparam(":studID", 		$studID );
					$statementStudentFee -> bindparam(":feeDetailID", 	$feeID );
					$statementStudentFee -> bindparam(":receiptNo", 	$receiptNo );
					$statementStudentFee -> bindparam(":payDate", 		$payDate );
					$statementStudentFee -> bindparam(":payMode", 		$payMode );
					
					$payModeRemark=$bankName ."<br>". $chequeNo ."<br>". $ChequeDate;
					
					$statementStudentFee -> bindparam(":payModeRemark", $payModeRemark );
					$statementStudentFee -> bindparam(":amount",		$amount[$ControlArrayIndex] );
					$statementStudentFee -> bindparam(":receivedAmount",$totalFee[$ControlArrayIndex] );
					$statementStudentFee -> bindparam(":discount",		$discount[$ControlArrayIndex] );
					$statementStudentFee -> bindparam(":dues",			$dues[$ControlArrayIndex] );
					$statementStudentFee -> bindparam(":remark", 		$remark );
					$statementStudentFee -> bindparam(":createdBy", 	$createdBy );
					$statementStudentFee -> bindparam(":createdOn", 	$createdOn );
					
					($statementStudentFee -> execute());
					{
						echo "<script>alert('{$feeHead[$ControlArrayIndex]} updated Successfully!')</script>";	
						if($feeID==6)// ADMISSION FEE : Then allocate batch
						{
							UPDATE_BATCH_ROLL($studID);
							
						}
						if($dues[$ControlArrayIndex]>0) // if there is dues then insert data in monthlyfeesummery
						{
							// After saving Monthly fee
							// Store the actual data as summery in monthlyfeeSummery table for reference
							$studID				=$studID;
							$payDate			=$payDate;
							$feeDetailID		= $feeID;
							$studentfeeID		=$createdOn;
							$receiptNo			=$_POST[receiptNoService];
							$feeFrom			="NA";
							$feeTill			="NA";
							$totalMonths		=0;
							$feePerMonth		=$amount[$ControlArrayIndex];
							$lateFine			=0;
							$discount			=$discount[$ControlArrayIndex];	
							$dues				=$dues[$ControlArrayIndex];	
							$totalFeeReceived	= $totalFee[$ControlArrayIndex];
							$createdOn			=$createdOn;
							$createdBy			=$createdBy;
							
						    $sqlMonthlyFeeSummery="INSERT INTO `monthlyfeesummery` (`payDate`, `studID`, `studentfeeID`, `feeDetailID` ,`receiptNo`, `feeFrom`, `feeTill`, `totalMonths`, `feePerMonth`, `lateFine`, `discount`, `dues`, `totalFeeReceived`, `createdOn`, `createdBy`) 
																					VALUES ('$payDate', '$studID', '$studentfeeID', '$feeDetailID', '$receiptNo', '$feeFrom', '$feeTill', '$totalMonths', '$feePerMonth', '$lateFine', '$discount', '$dues', '$totalFeeReceived', '$createdOn', '$createdBy')";
							
							if($statementMonthlyFeeSummery=$connection->query($sqlMonthlyFeeSummery))
							{
									echo "<script>alert('SUMMERY {$feeHead[$ControlArrayIndex]} updated Successfully!')</script>";			
							}	
						}
					} 
			} // if(($totalFee[$ControlArrayIndex] != '' || $totalFee[$ControlArrayIndex] != 0) && $checkHead[$ControlArrayIndex]=='1')	
			} // else
			//------------------------------------------------------------------------------------------	
		$ControlArrayIndex++;		
		} //foreach($feeDetailID as $feeID)
		//------------------------------------------------------------------------------------------
		
//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx CODE TO SAVE MONTHLY FEE DATA START xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
		$TotalMonthlyFee	=$_POST[TotalMonthlyFee];
		$checkHeadMonthlyFee=$_POST[checkHeadMonthlyFee];
		
		if($checkHeadMonthlyFee==1 && $TotalMonthlyFee>0)
		{
				$feeFrom			=$_POST[feeFrom];
				$feeTill			=$_POST[feeTill];
				$monthlyFee			=$_POST[monthlyFee];
				$lateFine			=$_POST[lateFine];
				$monthlyDiscount	=$_POST[monthlyDiscount];
				
				if($monthlyFee == $lateFine)
				{
					$DiscountEqualsLateFine=true;
				}
				$monthlyDues		=$_POST[monthlyDues];
				$TotalMonthlyFee	=$_POST[TotalMonthlyFee];
				$checkHeadMonthlyFee=$_POST[checkHeadMonthlyFee];
				
				// Before saving monthly fee check if admission fee is paid or not
				// Do not accept monthly fee without admission fee
				
				$sqlAdmissionFee="select `feeID` from `studentfee` where `feeDetailID`=6 and `studID`='$studID'";
				$stmtAdmissionFee = $connection ->query($sqlAdmissionFee);
				if(!$stmtAdmissionFee->rowCount())
				{
					echo "<script>alert('Monthly Fee Can not be Accepted without Accepting Admission Fee')</script>";	
				}
				else
				{
					$monthsArray			= $_POST[months];
					$monthsArray=explode(";", $monthsArray);
					
					//Note: Late fine calculation is stored in hidden control in the form of string
					// it calculates latefine till date
					// say if the due is for 20 months, then latefine is calculated for 20 months in the string
					// But, if the student pay for only 5 months then, the foreach loop will save only 5 months data
					// and 5 months latefine will only be stored
					$lateFineString 		= $_POST[lateFineString];
					$lateFineArray=explode(";", $lateFineString); //**************************
					//print_r($lateFineArray);
					
					 $feeFromIndex=array_search($feeFrom, $monthsArray); // get the index no. in array $monthsArray where $feeFrom  is stored
					 $feeTillIndex=array_search($feeTill, $monthsArray); // get the index no. in array $monthsArray where $feeTill  is stored
					
					// if fee is being paid for say 3 months and discount offered in monthly fee is 300 than,
					// since data is stored month wise, hence discount amount should be divided with 3 (months) and alocate the result i.e. 100 to each months fee
					 $discount		=$monthlyDiscount/($feeTillIndex+1);	
					 //$monthlyDues	=$monthlyDues/($feeTillIndex+1);
					 //$TotalMonthlyFee=$TotalMonthlyFee/($feeTillIndex+1);
					if($monthlyDiscount == $lateFine)
					{
						$DiscountEqualsLateFine=1;
					}
						
					for($i=0; $i<=$feeTillIndex; $i++) // Loop from index from - index Till
					{	
						//echo $feeForMonth;
						$sqlStudentFee="INSERT INTO `studentfee` (`studID`, `feeDetailID`, `receiptNo`, `payDate`, `feeForMonth`, `payMode`, `payModeRemark`, `amount`, `receivedAmount`, `discount`,`dues`, `lateFine`, `remark`, `createdBy`, `createdOn`) 
														  VALUES (:studID,  :feeDetailID,  :receiptNo,  :payDate,  :feeForMonth ,:payMode,  :payModeRemark,  :amount,  :receivedAmount, :discount, :dues, :lateFine, :remark, :createdBy, :createdOn)"; 
														  
						$statementStudentFee=$connection->prepare($sqlStudentFee);
						
						$statementStudentFee -> bindparam(":studID", 		$studID );
						$feeID=9; // Monthly fee
						$statementStudentFee -> bindparam(":feeDetailID", 	$feeID );
						$statementStudentFee -> bindparam(":receiptNo", 	$receiptNo );
						$statementStudentFee -> bindparam(":payDate", 		$payDate );
						
						$feeForMonth=$monthsArray[$i];
						$statementStudentFee -> bindparam(":feeForMonth", 	$feeForMonth);
						$statementStudentFee -> bindparam(":payMode", 		$payMode );
						
						$payModeRemark=$bankName ."-". $chequeNo ."-". $ChequeDate;
						
						$statementStudentFee -> bindparam(":payModeRemark", $payModeRemark );
						$statementStudentFee -> bindparam(":amount",		$monthlyFee);
						
						$lateFine=($lateFineArray[$i])?$lateFineArray[$i]:0;
						$statementStudentFee -> bindparam(":lateFine",		$lateFine );
						
						if($DiscountEqualsLateFine==1) // if discount is equal to late fine then discount should be as per latefine per month
						{
							$discountGiven = $lateFine;	
						}
						else
						{
							$discountGiven = $discount;
						}
						
						
						if($i == $feeTillIndex)
						{
							$monthlyDues=$_POST[monthlyDues];
							$ReceivedAmount=$TotalMonthlyFee; 
						}
						else
						{
							$monthlyDues=0;
							$ReceivedAmount=$monthlyFee + ($lateFine-$discountGiven);
							$TotalMonthlyFee=$TotalMonthlyFee-$ReceivedAmount;
						}
						$statementStudentFee -> bindparam(":discount",		$discountGiven);	
						$statementStudentFee -> bindparam(":dues",			$monthlyDues);
						$statementStudentFee -> bindparam(":receivedAmount",$ReceivedAmount);
						$statementStudentFee -> bindparam(":remark", 		$remark );
						$statementStudentFee -> bindparam(":createdBy", 	$createdBy );
						$statementStudentFee -> bindparam(":createdOn", 	$createdOn );
						
						if($feeForMonth!='')// Protect Blank Data, which will occur due to $monthsArray=explode(";", $monthsArray); statement
						{
							if($statementStudentFee -> execute())
							{
									echo "<script>alert('Monthly Fee for the month of {$feeForMonth} updated Successfully!')</script>";	
							}
						}
					} //for($i=0; $i<=$feeTillIndex; $i++)
					
					//-------------------------CODE TO SAVE MONTHLY FEE DATA END----------------------------------------------
		
					// After saving Monthly fee
					// Store the actual data as summery in monthlyfeeSummery table for reference
					$studID				=$studID;
					$payDate			=$payDate;	
					$studentfeeID		=$createdOn;
					$feeDetailID		= 9;
					$receiptNo			=$_POST[receiptNoService];
					$feeFrom			=$_POST[feeFrom];
					$feeTill			=$_POST[feeTill];
					$totalMonths		=$feeTillIndex+1;
					$feePerMonth		=$_POST[monthlyFee];
					$lateFine			=$_POST[lateFine];
					$discount			=$_POST[monthlyDiscount];	
					$dues				=$_POST[monthlyDues];	
					$totalFeeReceived	=$_POST[TotalMonthlyFee];
					$createdOn			=$createdOn;
					$createdBy			=$createdBy;
					
					$sqlMonthlyFeeSummery="INSERT INTO `monthlyfeesummery` (`payDate`, `studID`, `feeDetailID`, `studentfeeID`, `receiptNo`, `feeFrom`, `feeTill`, `totalMonths`, `feePerMonth`, `lateFine`, `discount`, `dues`, `totalFeeReceived`, `createdOn`, `createdBy`) 
																			VALUES ('$payDate', '$studID', '9', '$studentfeeID', '$receiptNo', '$feeFrom', '$feeTill', '$totalMonths', '$feePerMonth', '$lateFine', '$discount', '$dues', '$totalFeeReceived', '$createdOn', '$createdBy')";
					
					if($statementMonthlyFeeSummery=$connection->query($sqlMonthlyFeeSummery))
					{
							echo "<script>alert('SUMMERY Monthly updated Successfully!')</script>";			
					}
					//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*---*-*-*-*-*-*-*-*-*-*-*-	
				} //else Line 220
		} //if($checkHeadMonthlyFee==1 && $TotalMonthlyFee>0)
		else
		{
				if($checkHeadMonthlyFee==1) // MONTHLY FEE
				{
					if($TotalMonthlyFee == '' || $TotalMonthlyFee <= 0)
					{
						echo "<script>alert( 'Please calculate the Monthly Fee to Get the Total.' )</script>";
					}
				}
				elseif($checkHeadMonthlyFee !=1)
				{
					if($TotalMonthlyFee != '' || !$TotalMonthlyFee <= 0)	
					{
						echo "<script>alert( 'Please select Fee Head to save Record.' )</script>";
					}
				}
		} // else Line 325
		
		file_put_contents('receiptNo',$receiptNo); // Update fee Receipt
		
		echo "<script>window.open('files/view_receipt.php?rcpt={$receiptNo}', '_blank')</script>";
		echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$admID}'</script>";
	}
} //if(isset($_POST['add_studentFee']))


?>