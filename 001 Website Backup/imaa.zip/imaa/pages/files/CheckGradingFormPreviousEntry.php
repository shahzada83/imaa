<?php

	include('database.php');

	 $studID	=	$_GET['studID'];
	 $formNo	=	$_GET['formNo'];
	 $examMonth	=	$_GET['examMonth'];

	if($examMonth!='')
	{
		$sql="SELECT * from `exam` where `FormNo`='$formNo' and `examMonth`='$examMonth'";
	}
	else
	{
		$sql="SELECT * from `exam` where `FormNo`='$formNo'";
	}
	
	$data=Select(connectDB(), $sql);
	if($data[FormNo]!='')
	{
		$sqlStudentName = "select name from student where studID='$data[studID]'";	
		$dataStudent=Select(connectDB(),$sqlStudentName);
		
		$msg =  "Form No. : $formNo, already filled by " . $dataStudent[name] . " Against Exam Month " . $data[examMonth];
		
		echo "<div class='alert alert-danger alert-dismissible'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
					<h5><i class='icon fa fa-ban'></i> Note :  $msg</h5>
					
				  </div>";
	}

?>