<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php
include('dbconn.php');

if(isset($_POST))
{	
  $addStock=array_map('htmlspecialchars',$_POST);
  $addStock=array_map('trim',$addStock);
  $addStock=array_map('addslashes',$addStock);
 
  //echo "<pre>";
  //print_r($addStock);
  //[billDate] => 28/01/2018 [billNo] => 141 [materialID] => Track Suit [quality] => High [size] => 26 [quantity] => 10 [costPrice] => 120 [rowTotal] => 1200

	 	$string=explode("/",$addStock[billDate]);
		$billDate=	$string[2]."-".$string[1]."-".$string[0];
 
 $sqlInsertStock="INSERT INTO `stockentry` (`itemName`, `BillNo`, `BillDate`, `quality`, `size`, `receivedQty`, `costPrice`,`materialDetailUpdate`)
 								  VALUES   ('$addStock[materialID]', '$addStock[billNo]', '$billDate', '$addStock[quality]', '$addStock[size]', '$addStock[quantity]', '$addStock[costPrice]','1')";
										 
					
		if($connection->query($sqlInsertStock))
		{
			echo "
				<div class='alert alert-success alert-dismissable'>
                    <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                    <h4>	<i class='icon fa fa-check'></i> Success !</h4>
                    The record saved successfully.
                </div>
			";
		}
		else
		{
			echo "OOPs!! Some thing went wrong.";
		}
 
}

?>