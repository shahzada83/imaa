<?php //error_reporting(0); ?>
<style>
	.errorMsg
	{
		color:#FFFF33;
	}
</style>

<form action="" method="post" name="formAddCourses" style="color:#000">
<div id="gradingForm" class="modal fade modal-primary" role="dialog">
  <div class="modal-dialog" style="width:800px">

    <!-- Modal content-->
    <div class="modal-content" style="width:800px">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Grading Form</h4>
      </div>
      <div class="modal-body">
	  <input type="hidden" class="form-control" id="txtStudentID" name="txtStudentID"  />
	 
	  
<!-- /.box-header -------------------------------------------------------------------------------------------------------------------------->
	
	<div class="box-body">
		<div id="show_msg_grading"></div>
		<div class="row">
			
			<div class="col-lg-3 col-md-3  col-xs-6">
				<div class="form-group">
					<label class="small">* Date</label>
					<?php $admDate=date("d/m/Y"); ?>
					<input name="date" type="text" class="form-control input-sm" id="adm_date" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo $admDate; ?>"  onChange="document.getElementById('show_msg_grading').innerHTML ='';">
					
					<span class="error" id="eAdmDate"></span>
				</div>
			</div>
			
			<div class="col-lg-3 col-md-3  col-xs-6">
				<div class="form-group">
					<?php
						$receiptNo = file_get_contents('receiptNo')+1;
					?>	
                  <label class="small">* Receipt No.</label>
					<input type="text" class="form-control input-sm" name="receipt_no" id="receipt_no" value="<?php echo $receiptNo; ?>" readonly>
				  <p id="err_examFormNo" class="errorMsg"></p>
                </div>
			</div>
			
			<div class="col-lg-3 col-md-3  col-xs-6">
				<div class="form-group">
                  <label class="small">* Exam Form No</label>
					<input type="text" class="form-control input-sm" name="examFormNo" id="examFormNo" maxlength="5" onKeyPress="return isNumberKey(event)" onChange="document.getElementById('show_msg_grading').innerHTML ='';" onblur=" checkPreviousRecord(document.getElementById('examFormNo').value);">
				  <p id="err_examFormNo" class="errorMsg"></p>
                </div>
			</div>
			
			<div class="col-lg-3 col-md-3  col-xs-6">
				<div class="form-group">
                  <label class="small"><i class="fa fa-calendar"></i> * Exam Month</label>
				  
				  <select name="examMonth" id="examMonth" class="form-control input-sm" onChange="document.getElementById('show_msg_grading').innerHTML =''; checkPreviousRecord(document.getElementById('examFormNo').value);">
					<option></option>
					<option value="Apr - <?php echo date('Y'); ?>">	Apr - <?php echo date('Y'); ?>	</option>
					<option value="Aug - <?php echo date('Y'); ?>">	Aug - <?php echo date('Y'); ?>	</option>
					<option value="Dec - <?php echo date('Y'); ?>">	Dec - <?php echo date('Y'); ?>	</option>
				  </select>
				   <p id="examMonth" class="errorMsg"></p>
                </div>
			</div>
		</div>

		<div class="row">	
			<div class="col-md-3">
				<div class="form-group">
                  <label class="small">Current Belt</label>
					<select class="form-control input-sm" name="gradingFrom" id="gradingFrom">
					
					</select>
				  <p id="err_currentBelt" class="errorMsg"></p>
				</div>
				
			</div>
		
			<div class="col-md-3">
				<div class="form-group">
				  <label class="small">Grading For</label>
					<select class="form-control input-sm" name="gradingTo" id="gradingTo" onChange="showFee()">
					
					</select>
				  <p id="err_gradingFor" class="errorMsg"></p>
				</div>
				 
			</div>
			
			
		</div>
		<div class="row">	
			
			<div class="col-md-3">
				<div class="form-group">
						<label class="label_font">(<i class="fa fa-rupee"></i>) Fee </label>
						<div id='control'>
							<select class="form-control input-sm" name="fee" id="fee">
						
							</select>
						</div>
						 <p id="err_fee" class="errorMsg"></p>
				</div>
			</div>
			
			<div class="col-md-3">
				<div class="form-group">
                  <label for="exampleInputEmail1" class="small">* Late Fine</label>
                  <input type="text" class="form-control input-sm" name="lateFine" id="lateFine" onkeyUp="calculateFee();" onfocus="calculateFee();"  onChange="document.getElementById('show_msg_grading').innerHTML ='';">
				  <p id="Error_lateFine" class="errorMsg"></p>
                </div>
			</div>
			
			<div class="col-md-3">
				<div class="form-group">
                  <label for="exampleInputEmail1" class="small" id="total">* Paid</label>
				  <b>
					<input type="text" class="form-control input-sm" name="paid" id="paid" onkeyUp="calculateFee();" onfocus="calculateFee();"  onChange="document.getElementById('show_msg_grading').innerHTML ='';">
				  </b>
				  <p id="Error_dues" class="errorMsg"></p>
                </div>
			</div>
			
			<div class="col-md-3 pull-right">
				<div class="form-group">
                  <label class="small">Dues</label>
                  <input type="text" class="form-control input-sm" name="due" id="due"  readonly>
				  <p id="Error_currentBelt" class="errorMsg"></p>
				</div> 
				
			</div>
		</div>
	</div>
	<!-- /.box-body -->
</div>

</div>
      <div class="modal-footer">
		<button type="button" name="add_gradingFee" class="btn btn-primary" onClick="saveGradingData();">Submit</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</form>

<script>
// This function is used to save data
function saveGradingData()
{
	//alert();
	event.preventDefault();
	$.ajax({
	url: "files/code_add_gradingFee.php",
	method: "post",
	data: $('form').serialize(),
	dataType: "text",
		success: function (strDate)
		{
			$('#show_msg_grading').html(strDate);
		}
	})
}
//this function is to calculate fee
function calculateFee()
{
	if(document.getElementById('fee').value=='0')
	{
		var fee			=	document.getElementById('fee2').value; 
	}
	else
	{
		var fee			=	document.getElementById('fee').value; 
	}
	var lateFine	=	document.getElementById('lateFine').value; 
	
	document.getElementById('total').innerHTML = "*Paid ( TOTAL : " + (parseFloat(fee) + parseFloat(lateFine)) + ")";
	
	var paid		=	document.getElementById('paid').value; 
	document.getElementById('due').value = (parseFloat(fee) + parseFloat(lateFine)) - parseFloat(paid);
}

// this function is used to check previous entry
function checkPreviousRecord(formNo)
{
		//alert(formNo);
		  
		  var studID=document.getElementById("txtStudentID").value;
		  var examMonth=document.getElementById("examMonth").value;
		  
		  var xhttp;    
		  if (formNo == "") {
			document.getElementById("show_msg_grading").innerHTML = "";
			
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			  document.getElementById("show_msg_grading").innerHTML = this.responseText;
			}
		  };
		  xhttp.open("GET", "files/CheckGradingFormPreviousEntry.php?studID="+studID+"&formNo="+formNo+"&examMonth="+examMonth, true);
		  xhttp.send();
		
}

function showFee()
{
	//document.getElementById('fee').selectedIndex = document.getElementById('gradingTo').selectedIndex
	//if(document.getElementById('gradingTo').value=='Black')
	//{
	//	document.getElementById('control').innerHTML="<input type='text' class='form-control input-sm' name='feeText' id='feeText' onkeyUp='calculateFee()'>"
	//}
	
	  var studID=document.getElementById("txtStudentID").value;
	  var examMonth=document.getElementById("examMonth").value;
	  
	  var xhttp;    
	  if (formNo == "") {
		document.getElementById("show_msg_grading").innerHTML = "";
		
		return;
	  }
	  xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
		  document.getElementById("show_msg_grading").innerHTML = this.responseText;
		}
	  };
	  xhttp.open("GET", "files/CheckGradingFormPreviousEntry.php?studID="+studID+"&formNo="+formNo+"&examMonth="+examMonth, true);
	  xhttp.send();
}
</script>