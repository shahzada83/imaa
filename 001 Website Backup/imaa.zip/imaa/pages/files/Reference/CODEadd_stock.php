<script>
function calculateStockRowTotal()
{
	//alert();
	var myForm 		= document.formAddStock;
	
	var Quantity 		= myForm.elements['qty[]'];
	var CostPrice 		= myForm.elements['costPrice[]'];
	var RowTotal		= myForm.elements['rowTotal[]'];
	
	
	var netTotal=0;
	for (var i = 0; i < Quantity.length; i++) 
	{
		var Quantity2 	= Quantity[i].value;
		var CostPrice2	= CostPrice[i].value;
		var RowTotal2 	= RowTotal[i].value;
		
		
		if(Quantity2 == '' || CostPrice2 =='')
		{
			RowTotal[i].value=0
		}
		else
		{
			RowTotal[i].value = parseFloat(Quantity2) * parseFloat(CostPrice2);	
			netTotal += parseFloat(RowTotal[i].value);	
		}
	}
	if(document.getElementById('billNo').value=='')
	{
		alert('Please enter Bill No.');	
		document.getElementById('billNo').focus();
	}
	document.getElementById('billTotal').value= netTotal;
}
</script>

<?php

if(isset($_POST[add_stock]))
{
	
	
			$billDate	=$_POST[billDate];
			$billNo		=trim($_POST[billNo]);
			$billTotal	=$_POST[billTotal];
		
		// check if bill no already exists in stockbill table
		$sqlBillNo="select billNo from stockbill where billNo='$billNo'";
		$stmtBillNo=$connection->query($sqlBillNo);
		if($stmtBillNo->rowCount())
		{
			echo "<script>alert('Bill No. : {$billNo} already exists in Record.')</script>";
		}
		elseif($billDate=='dd/mm/yyyy')
		{
			echo "<script>alert('Please enter Bill date.')</script>";
		}
		elseif($billNo=='')
		{
				echo "<script>alert('Please enter Bill No.')</script>";	
		}
		else
		{	
			$itemID 	= $_POST[itemID]; 		//Array
			$quality 	= $_POST[quality];		//Array
			$qty 		= $_POST[qty];			//Array
			$price		= $_POST[costPrice];	//Array
			$rowTotal 	= $_POST[rowTotal];		//Array
			$itemName 	= $_POST[itemName];		//Array
			
			$stockBillID=mktime();
			$controlArrayIndex=0;
			foreach($itemID as $feeDetailID)
			{
				$feeDetailID;
				$stockBillID;
				$VAR_quality 	=$quality[$controlArrayIndex];
				$VAR_qty		=$qty [$controlArrayIndex];
				$VAR_price		=$price[$controlArrayIndex];
				$VAR_rowTotal	=$rowTotal[$controlArrayIndex];
				$VAR_itemName	=$itemName[$controlArrayIndex];
							
				if($VAR_qty !='' || $VAR_price !='') // if row is blank than dont save record
				{
					$sqlInsertStock="INSERT INTO `stock`	(`feeDetailID`, `stockBillID`, `quality`, `qty`, `purchasePrice`) 
													VALUES  (:feeDetailID, :stockBillID, :quality, :qty, :purchasePrice)";
					$statementInsertStock=$connection->prepare($sqlInsertStock);	
					$statementInsertStock->bindParam(":feeDetailID",	$feeDetailID);
					$statementInsertStock->bindParam(":stockBillID",	$stockBillID);
					$statementInsertStock->bindParam(":quality",		$VAR_quality);
					$statementInsertStock->bindParam(":qty",			$VAR_qty);
					$statementInsertStock->bindParam(":purchasePrice",	$VAR_price);
					
					if($statementInsertStock->execute())
					{
						/*echo "<script>alert('Stock Record Saved for {$VAR_itemName}')</script>";*/
						
						$stockItem=true;
						
						// Once the record is saved set savetoStockBill variable to true so that Bill details can be saved
						$SaveToStockBill=true;
						
						$sqlStockSummery="insert into stocksummery(	`feeDetailID`, `quality`, `receivedQty`) 
															VALUES('$feeDetailID', '$VAR_quality', '$VAR_qty')
										   					on duplicate key update
       												 		receivedQty = $VAR_qty + receivedQty";
						if($stmtStockSummery=$connection->query($sqlStockSummery))
						{
							$saveStockSummery=true;
							/*echo "<script>alert('Stock Status Updated Successfully.')</script>";*/
						}
						else
						{
							$saveStockSummery=false;
						}
					}
					else
					{
						$SaveToStockBill=false;	
						$stockItem=false;
					}						
				}	
			$controlArrayIndex++;
			} //foreach($itemID as $feeDetailID)
			if($SaveToStockBill==true)//finally when loop end and save all the record in stock table save the bill details in the StockBill table
			{
				$stockBillID;
				$billDate=short_date($billDate);
				$billNo;
				$billTotal;
				$sqlInsertStockBill="INSERT INTO `stockbill` (`stockBillID`, `billDate`, `billNo`, `billTotal`) 
													 VALUES  (:stockBillID, :billDate, :billNo, :billTotal) ";
													 
					$statementInsertStockBill=$connection->prepare($sqlInsertStockBill);	
					$statementInsertStockBill->bindParam(":stockBillID",	$stockBillID);
					$statementInsertStockBill->bindParam(":billDate",		$billDate);
					$statementInsertStockBill->bindParam(":billNo",			$billNo);	
					$statementInsertStockBill->bindParam(":billTotal",		$billTotal);	
				
					if($statementInsertStockBill->execute())
					{
						echo "<script>alert('Bill Record Saved Successfully.')</script>";
						if($saveStockSummery==true)
						{
							echo "<script>alert('Stock Status Updated Successfully.')</script>";
							if($stockItem==true)
							{
								echo "<script>alert('Stock Items added Successfully.')</script>";
							}

						}
					}										 
			}
			else
			{
				echo "<script>alert('No Record Saved.')</script>";
			}
			/*echo "<script>document.location.href='main.php?pg=add stock'</script>";*/
		}//else
}
?>