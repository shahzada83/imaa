<style>
#paymentModeBank{display:none;}
#paymentModeChequeNo{display:none;}
#paymentModeTransactionDate{display:none;}
</style>
<script>

function calculateMonthlyFee()
{
	//alert();
	var MonthlyFee 			= document.getElementById('monthlyFee').value;
	var TotalMonth 			= document.getElementById('feeTill').selectedIndex + 1;  // Selects option "One"
	var LateFine 			= Number(document.getElementById('lateFine').value);
	var monthlyDiscount 	= Number(document.getElementById('monthlyDiscount').value);
	document.getElementById('TotalMonthlyFee').value = MonthlyFee * TotalMonth + LateFine - monthlyDiscount; //TotalMonthlyFee=amount control
	document.getElementById('monthlyTotal').value =Number(document.getElementById('TotalMonthlyFee').value);
	document.getElementById('totFee').innerHTML = "    (Rs. : " + MonthlyFee * TotalMonth + ")";
}

function calculate()
{
	var myForm 		= document.formStudentFee1;
	var discount 	= myForm.elements['discount[]'];
	
	var totalFee 	= myForm.elements['totalFee[]'];
	var amount		= myForm.elements['amount[]'];
	
	for (var i = 0; i < discount.length; i++) 
	{
		var discountValue 	= discount[i].value;
		var totalFeetValue	= totalFee[i].value;
		var amountValue 	= amount[i].value;
		
		if(discountValue != '')
		{
			totalFeetValue = (amountValue - discountValue);
		}
		if(totalFeetValue<0)
		{
			alert('Invalid Discount Amount!!');
			discount[i].value='';
		}
		else
		{
			totalFee[i].value = totalFeetValue;
		}
	}
}

function showPaymentMode() // This function is called from select option named paymentMode
{
		if(document.getElementById('payMode').value != "Cash")
	    {
			 document.getElementById('paymentModeBank').style.display="block"
			 document.getElementById('paymentModeChequeNo').style.display="block"
			 document.getElementById('paymentModeTransactionDate').style.display="block"
	    }
		if(document.getElementById('payMode').value == "Cash")
	    {
			document.getElementById('paymentModeBank').style.display="none"
			 document.getElementById('paymentModeChequeNo').style.display="none"
			 document.getElementById('paymentModeTransactionDate').style.display="none"
	    }
}
function validate(e)
	{
		//alert('');
		
		if( document.addStudentFeeForm.admDate.value == "")
	    {
			 alert( "Please Enter Admission Date." );
			 document.addStudentFeeForm.admDate.focus() ;
			 document.getElementById('eAdmDate').innerHTML ="Admission Date. can't be Blank";
			 return false;
	    }
	}
</script>		
<?php

if(isset($_POST['add_studentFee']))
{	
  	$payDate 		= short_date($_POST['payDate']);
    $receiptNo 		= $_POST[receiptNo];
    $payMode		= $_POST[payMode];
    $bankName 		= $_POST[bankName];
    $chequeNo		= $_POST[chequeNo];
    $ChequeDate 	= $_POST[ChequeDate];
	
    $feeDetailID 	= $_POST[feeDetailID];			// ARRAY
	$checkHead		=$_POST[checkHead];
	$feeHead		= $_POST[feeHead];			// ARRAY
    $amount 		= $_POST[amount];			// ARRAY
	
    $discount 		= $_POST[discount];			// ARRAY
    $totalFee 		= $_POST[totalFee];			// ARRAY
    
    $remark 		= $_POST[remark];
	$createdBy		= $_SESSION[userID];
	$createdOn		= mktime();
	
	$studID; // This value is coming from view_student_profile.php
	if($receiptNo== "")
	{
		 echo "<script>alert('Please Enter Receipt No.')</script>";
	}
	elseif($payMode != "Cash" && ($bankName =='' || $chequeNo =='' || $ChequeDate =='dd/mm/yyyy'))
	{
		 echo "<script>alert( 'Please Enter Bank Name, Cheque/ Reference No. and Transaction Date' )</script>";
	}
	else
	{
		$ControlArrayIndex = 0; 
		foreach($feeDetailID as $feeID)
		{
				// CODE BELOW TO SAVE ALL RECORDS EXCEPT MONTHLY FEE *******************************************
				if($feeID != 9 ) // If the row is not for monthly fee  feeID=9 for Monthly Fee
				{
					//echo $feeID . "<br>";	
					if($totalFee[$ControlArrayIndex] != 0 && $checkHead[$ControlArrayIndex]=='') // Total has been done, but check box is not selected
					{
						 echo "<script>alert( 'Please select Fee Head to save Record.' )</script>";
					}
					else
					{
						if(($totalFee[$ControlArrayIndex] != '' || $totalFee[$ControlArrayIndex] != 0) && $checkHead[$ControlArrayIndex]=='1') // Insert only those data which are entered by the user i.e. amount is not blank, if amount is blank or 0, that means that perticular fee is not received
						{
						$sqlStudentFee="INSERT INTO `studentfee` (`studID`, `feeDetailID`, `receiptNo`, `payDate`, `payMode`, `payModeRemark`, `amount`, `discount`, `remark`, `createdBy`, `createdOn`) 
														  VALUES (:studID,  :feeDetailID,  :receiptNo,  :payDate,  :payMode,  :payModeRemark,  :amount,  :discount,  :remark, :createdBy, :createdOn)"; 
														  
						$statementStudentFee=$connection->prepare($sqlStudentFee);
						
						$statementStudentFee -> bindparam(":studID", 		$studID );
						$statementStudentFee -> bindparam(":feeDetailID", 	$feeID );
						$statementStudentFee -> bindparam(":receiptNo", 	$receiptNo );
						$statementStudentFee -> bindparam(":payDate", 		$payDate );
						$statementStudentFee -> bindparam(":payMode", 		$payMode );
						
						$payModeRemark=$bankName ."<br>". $chequeNo ."<br>". $ChequeDate;
						
						$statementStudentFee -> bindparam(":payModeRemark", $payModeRemark );
						$statementStudentFee -> bindparam(":amount",		$amount[$ControlArrayIndex] );
						$statementStudentFee -> bindparam(":discount",		$discount[$ControlArrayIndex] );
						$statementStudentFee -> bindparam(":remark", 		$remark );
						$statementStudentFee -> bindparam(":createdBy", 	$createdBy );
						$statementStudentFee -> bindparam(":createdOn", 	$createdOn );
						
						if($statementStudentFee -> execute())
						{
							if($feeHead[$ControlArrayIndex]=='Admission Fee')
							{
								UPDATE_BATCH_ROLL($studID); // This function is defined in API.php
							}
							echo "<script>alert('{$feeHead[$ControlArrayIndex]} updated Successfully!')</script>";	
						} 
						
					} // if($amount[$i] != '' || $amount[$i] != 0)
					}
				} //if($feeID != 9)
				
				// CODE BELOW TO SAVE ONLY MONTHLY FEE *******************************************
				elseif($feeID == 9 && ($totalFee[$ControlArrayIndex] != '' || $totalFee[$ControlArrayIndex] != 0)) // If the row is for monthly fee  feeID=9 for Monthly Fee
				{
					if($totalFee[$ControlArrayIndex] != 0 && $checkHead[$ControlArrayIndex]=='') // Total has been done, but check box is not selected
					{
						 echo "<script>alert( 'Please select Fee Head to save Record.' )</script>";
					}
					else
					{
						// Before saving monthly fee check if admission fee is paid or not
						// Do not accept monthly fee without admission fee
						
						$sqlAdmissionFee="select `feeID` from `studentfee` where `feeDetailID`=6 and `studID`='$studID'";
						$stmtAdmissionFee = $connection ->query($sqlAdmissionFee);
						if(!$stmtAdmissionFee->rowCount())
						{
							echo "<script>alert('Monthly Fee Can not be Accepted without Accepting Admission Fee')</script>";	
						}
						else
						{
							$feeFrom 		= $_POST[feeFrom];
							 $feeTill 		= $_POST[feeTill];
							 $monthsArray	= $_POST[months];
							 $lateFine 		= $_POST[lateFine];			
							 
							$monthsArray=explode(";", $monthsArray);
							
							//print_r($monthsArray);
							
							 $feeFromIndex=array_search($feeFrom, $monthsArray); // get the index no. in array $monthsArray where $feeFrom  is stored
							 $feeTillIndex=array_search($feeTill, $monthsArray); // get the index no. in array $monthsArray where $feeTill  is stored
							
							// if fee is being paid for say 3 months and discount offered in monthly fee is 300 than,
							// since data is stored month wise, hence discount amount should be divided with 3 (months) and alocate the result i.e. 100 to each months fee
							 $discount=$discount[$ControlArrayIndex]/($feeTillIndex+1);	
							 $amount  =$amount[$ControlArrayIndex]/($feeTillIndex+1);
							 $lateFine =$lateFine/($feeTillIndex+1);	
							for($i=0; $i<=$feeTillIndex; $i++) // Loop from index from - index Till
							{	
								//echo $feeForMonth;
								
								
								 
								$sqlStudentFee="INSERT INTO `studentfee` (`studID`, `feeDetailID`, `receiptNo`, `payDate`, `feeForMonth`, `payMode`, `payModeRemark`, `amount`, `discount`, `lateFine`, `remark`, `createdBy`, `createdOn`) 
																  VALUES (:studID,  :feeDetailID,  :receiptNo,  :payDate,  :feeForMonth ,:payMode,  :payModeRemark,  :amount,  :discount,  :lateFine, :remark, :createdBy, :createdOn)"; 
																  
								$statementStudentFee=$connection->prepare($sqlStudentFee);
								
								$statementStudentFee -> bindparam(":studID", 		$studID );
								$statementStudentFee -> bindparam(":feeDetailID", 	$feeID );
								$statementStudentFee -> bindparam(":receiptNo", 	$receiptNo );
								$statementStudentFee -> bindparam(":payDate", 		$payDate );
								
								$feeForMonth=$monthsArray[$i];
								$statementStudentFee -> bindparam(":feeForMonth", 	$feeForMonth);
								$statementStudentFee -> bindparam(":payMode", 		$payMode );
								
								$payModeRemark=$bankName ."-". $chequeNo ."-". $ChequeDate;
								
								$statementStudentFee -> bindparam(":payModeRemark", $payModeRemark );
								$statementStudentFee -> bindparam(":amount",		$amount);
								$statementStudentFee -> bindparam(":discount",		$discount);
								$statementStudentFee -> bindparam(":lateFine",		$lateFine );
								$statementStudentFee -> bindparam(":remark", 		$remark );
								$statementStudentFee -> bindparam(":createdBy", 	$createdBy );
								$statementStudentFee -> bindparam(":createdOn", 	$createdOn );
								
								if($feeForMonth!='')// Protect Blank Data, which will occur due to $monthsArray=explode(";", $monthsArray); statement
								{
									if($statementStudentFee -> execute())
									{
										
											echo "<script>alert('{$feeHead[$ControlArrayIndex]} for the month of {$feeForMonth} updated Successfully!')</script>";	
									}
								}
							} // Closing For
						}
					}
				} //elseif($feeID == 9)
		$ControlArrayIndex++;		
		} //foreach($feeDetailID as $feeID)
		file_put_contents('receiptNo',$receiptNo); // Update fee Receipt
		echo "<script>document.location.href='main.php?pg=profile&admID={$admID}'</script>";
	}
} //if(isset($_POST['add_studentFee']))


?>