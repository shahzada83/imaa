<?php
if(isset($_POST['searchReport']))
{	
  $searchReport=array_map('htmlspecialchars',$_POST);
  $searchReport=array_map('trim',$searchReport);
  $searchReport=array_map('addslashes',$searchReport);
  //echo "<pre>";
  //print_r($searchReport);
  
  $case=$searchReport['case'];
  $field=$searchReport['field'];
	
  prepareQuery($searchReport);
}

function prepareQuery($searchReport)
{
	$case=$searchReport['case'];
	$field=$searchReport['field'];
	/* -- REFERENECE --
	
	<select name="case" class="form-control input-sm">
		<option value="1">Pending</option>
		<option value="0">Non - Pending</option>
	</select>

	*/
	if($case==1)
	{
		/* -- REFERENECE --
		
		<select name="field" class="form-control input-sm">
			<option value="MF">Monthly Fee</option>
			<option value="ID">ID Card</option>
			<option value="KD">Karate Dress</option>
			<option value="TS">Track Suite</option>
		</select>
		
		*/
		switch($field)
		{
			case 'MF':
				$sqlReport="";
			break;
			
			case 'ID':
			break;
			
			case 'KD':
			break;
			
			case 'TS':
			break;
			
		}
	}
}
?>
