<?php
$sqlHead="SELECT `head` from `feedetail` where `feeDetailID`='$field'";
$stmtHead=$connection->query($sqlHead);
$dataHead=$stmtHead->fetch(PDO::FETCH_ASSOC);
$headName = $dataHead[head];
?>
<div class="box box-primary box-solid">
		<div class="box-header">
		  <h3 class="box-title"><?php echo ($field==6)?'ID CARD' : $headName; ?> Due's Detail</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		  <table id="example1" class="table table-bordered table-striped table-responsive">
			<thead>
			  <tr>
				<th>Photo</th>
				<th>Roll No</th>
				<th>Name</th>
				<th><?php echo ($field==6)?'ID CARD' : $headName; ?></th>
				
				<th align="center">Action</th>
			  </tr>
			</thead>
			<tbody>
<?php
//***********************************************************************************************************************************************//
$sqlSTUDENT="SELECT student.*, feeDetailID from student, `studentfee` where student.`studID`=studentfee.studID and studentfee.`feeDetailID` ={$field} and studentfee.stockIssueID=0"; // 9 for Monthly Fee, from feedetail Table

$statementSTUDENT = $connection->query($sqlSTUDENT);
while($dataSTUDENT=$statementSTUDENT->fetch(PDO::FETCH_ASSOC))
{
	
//***********************************************************************************************************************************************//	
?>
			  <tr>
				<td width="80px">
					<?php
						$profileImage=($dataSTUDENT[photo] != '')?$dataSTUDENT[photo]:'no_image.png';
					?>
			<img src="001_student_photo/<?php echo $profileImage; ?>" height="80px" width="80px" class="img-circle" />
				</td>
				<td>
					<strong>
						Reg. No. : <?php echo $dataSTUDENT['formNo'];?>/<?php echo date("my",strtotime($dataSTUDENT['admDate']));?> <br />
						Roll No. : <?php echo $dataSTUDENT['rollNo'];?><br>
						Batch : <?php echo $dataSTUDENT['batchPreferene'];?><br />
						Belt :<?php echo $dataSTUDENT['currentBelt']; ?>
					</strong>
				</td>
				
				<td>
					<strong>
					<?php
						echo ($dataSTUDENT['gender']=='Male')?"Mr. " : "Miss. ";
						echo ucwords(strtolower($dataSTUDENT['name']));
					?>
					</strong><br />	
					<i class="fa fa-phone"></i>&nbsp;&nbsp;  <?php echo $dataSTUDENT['mobile'];	?><br />
					<i class="fa fa-whatsapp"></i>&nbsp;&nbsp; <?php echo ($dataSTUDENT['whatsapp']=='')?"NA":$dataSTUDENT['whatsapp'];	?>
				</td>
				
				<td>
					PENDING
					 
				</td>
				
				<td align="center">
				<a href="main.php?pg=profile&admID=<?php echo $dataSTUDENT[admID];?>" class="btn btn-warning"><i class="fa fa-search" style="color:#FFFFFF"></i> View Profile</a>
				</td>
				
			  </tr>
<?php
	
//***********************************************************************************************************************************************//	
}	
//***********************************************************************************************************************************************//	
?>                      
			</tbody>
			<tfoot>
			   <tr>
				<th>Photo</th>
				<th>Roll No</th>
				<th>Name</th>
				<th>Mobile No.</th>
				<th>Applied for Belt</th>
				<th align="center">Action</th>
			  </tr>
			</tfoot>
		  </table>
		</div><!-- /.box-body -->
	  </div>




