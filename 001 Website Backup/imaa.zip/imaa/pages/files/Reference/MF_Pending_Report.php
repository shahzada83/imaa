<div class="box box-primary box-solid">
		<div class="box-header">
		  <h3 class="box-title">Monthly Fee Due's Detail</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		  <table id="example1" class="table table-bordered table-striped table-responsive">
			<thead>
			  <tr>
				<th>Photo</th>
				<th>Roll No</th>
				<th>Name</th>
				<th>Total Months as on - <?php echo date("M-Y"); ?></th>
				<th>Paid (Months)</th>
				<th>DUE (Months)</th>
				<th align="center">Action</th>
			  </tr>
			</thead>
			<tbody>
<?php
//***********************************************************************************************************************************************//
$sqlSTUDENT="SELECT * from student WHERE dropout=0 and deleted=0 and passout=0";

$statementSTUDENT = $connection->query($sqlSTUDENT);
while($dataSTUDENT=$statementSTUDENT->fetch(PDO::FETCH_ASSOC))
{
	// Then find out admission fee date of the student from studentfee Table
	// This will help to determine the no. of monthy fee to be paid by the student till date
	
	$studID=$dataSTUDENT[studID];
	$sqlAdmDate="SELECT COUNT(feeForMonth) as TotalMonthPaid from `studentfee` where `studID`='$studID' and feeDetailID='9'"; // 9 for Monthly Fee, from feedetail Table
	$statementAdmDate=$connection->query($sqlAdmDate);
	$dataAdmDate=$statementAdmDate->fetch(PDO::FETCH_ASSOC);
	$TotalMonthPaid=$dataAdmDate[TotalMonthPaid]-1;
	
	$AdmissionDate = $dataSTUDENT[admDate];
	$thisMonth=date("Y-m-d");
	$TotalMonthExpected= month_difference($AdmissionDate, $thisMonth);
	
	if(($TotalMonthPaid -$TotalMonthExpected)==0 && $searchReport['case']=='1')
	{
		continue;
	}
	//elseif(($TotalMonthPaid -$TotalMonthExpected)>0 && $searchReport['case']=='0')
	{
//***********************************************************************************************************************************************//	
?>
			  <tr>
				<td width="80px">
					<?php
						$profileImage=($dataSTUDENT[photo] != '')?$dataSTUDENT[photo]:'no_image.png';
					?>
			<img src="001_student_photo/<?php echo $profileImage; ?>" height="80px" width="80px" class="img-circle" />
				</td>
				<td>
					<strong>
						Reg. No. : <?php echo $dataSTUDENT['formNo'];?>/<?php echo date("my",strtotime($dataSTUDENT['admDate']));?> <br />
						Roll No. : <?php echo $dataSTUDENT['rollNo'];?><br>
						Batch : <?php echo $dataSTUDENT['batchPreferene'];?><br />
						Belt :<?php echo $dataSTUDENT['currentBelt']; ?>
					</strong>
				</td>
				
				<td>
					<strong>
					<?php
						echo ($dataSTUDENT['gender']=='Male')?"Mr. " : "Miss. ";
						echo ucwords(strtolower($dataSTUDENT['name']));
					?>
					</strong><br />	
					<i class="fa fa-phone"></i>&nbsp;&nbsp;  <?php echo $dataSTUDENT['mobile'];	?><br />
					<i class="fa fa-whatsapp"></i>&nbsp;&nbsp; <?php echo ($dataSTUDENT['whatsapp']=='')?"NA":$dataSTUDENT['whatsapp'];	?>
				</td>
				
				<td>
					<h3>
						<?php echo $TotalMonthExpected; ?>
					</h3>
					Adm. Date: <?php echo format_date($dataSTUDENT['admDate']); ?>
					 
				</td>
				
				<td>
					<h3 style="color:#009933">
						<?php echo $TotalMonthPaid; ?> 
					</h3>
				</td>
				<td>
					
					<h3 style="color:#FF0000">
						<?php echo $dueMonths =$TotalMonthExpected - ($TotalMonthPaid); ?> 
					</h3>
					
				</td>
				
				<td align="center">
				<a href="main.php?pg=profile&admID=<?php echo $dataSTUDENT[admID];?>" class="btn btn-warning"><i class="fa fa-search" style="color:#FFFFFF"></i> View Profile</a>
				</td>
				
			  </tr>
<?php
	}
//***********************************************************************************************************************************************//	
}	
//***********************************************************************************************************************************************//	
?>                      
			</tbody>
			<tfoot>
			   <tr>
				<th>Photo</th>
				<th>Roll No</th>
				<th>Name</th>
				<th>Mobile No.</th>
				<th>Applied for Belt</th>
				<th align="center">Action</th>
			  </tr>
			</tfoot>
		  </table>
		</div><!-- /.box-body -->
	  </div>




