<?php  //********** Code to extract the form element into variable

if(isset($_POST['addJobBtn']))
{
	$newpost = array_map ( 'htmlspecialchars' , $_POST );
	$newpost = array_map ('trim',$newpost);
	$newpost = array_map ('addslashes',$newpost);
	
	//extract($newpost, EXTR_PREFIX_ALL, "form1");
	echo "<pre>";
	print_r($newpost);
	
	//extract($_POST, EXTR_PREFIX_ALL, "form1");
	echo $newpost['source'];
}


?>

<?php  //********** Connection to database using PDO


try
{
	$connection = new PDO("mysql:host=localhost; dbname=imaa", "root", "");
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
	$connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
	//echo "Connected";
}
catch(PDOException $e)
{
	die("Connection Failed".$e->getmessage());
}
?>

<?php   //********* Insert Query

$connection->query("insert into table values('','abc','xyz','abc@gmail.com', '1233')");
?>

<?php  //********** Delete Query

$connection->query("Delete From table where email='abc@gmail.com'");
?>

<?php  //********** UPDATE Query

$connection->query("UPDATE table set email='xyz@gmail.com' where email='abc@gmail.com'");
?>

<?php  //********** PRINT SINGLE ROW SELECT ****//
// SELECT Query 
$result = $connection->query("select * from tableName");
//$row = $result->fetch(); // Show data in associative array form as well as numeric index form
	//**** PRINT SINGLE ROW ****//
	$row = $result->fetch(PDO::FETCH_ASSOC); // Show data in associative array form 
//$row = $result->fetch(PDO::FETCH_NUM); // Show data in numeric index array form 
//$row = $result->fetch(PDO::FETCH_OBJ); // Show data in object form 
	echo "<pre>";
	print_r($row);
?>

<?php  //********** fetch() **************//

// SELECT Query //**** PRINT MULTIPLE ROW ****//
$result = $connection->query("select * from tableName");
//$row = $result->fetch(); // Show data in associative array form as well as numeric index form
	echo "<pre>";
	while($row = $result->fetch(PDO::FETCH_ASSOC)) // Show data in associative array form 
	{
			print_r($row);
	}
//$row = $result->fetch(PDO::FETCH_NUM); // Show data in numeric index array form 
//$row = $result->fetch(PDO::FETCH_OBJ); // Show data in object form 
?>

<?php  //********** fetchAll() **************//

// fetch data without loop
$result=$connection->query("select * from tableName");
echo "<pre>";
$rows=$result->fetchAll(PDO::FETCH_ASSOC);
print_r($rows); // will fetch all data from table withou using a loop
?>

<?php  //********** setFetchMode() **************//

class abc{}

$result=$connection->query("select * from tableName");
echo "<pre>";
$result->setFetchMode(PDO::FETCH_CLASS,"abc");
while($rows=$result->fetch())
{
	echo $row->name; // Will display all names
}
?>

<?php  //********** setFetchMode() **************//

class abc
{
	public $name;
	public $email;
	public $data;
	
	public function __construct()
	{
		$this->data = $this->name . " - " . $this->email;
	}
}

$result=$connection->query("select * from tableName");
echo "<pre>";
$result->setFetchMode(PDO::FETCH_CLASS,"abc");
while($rows=$result->fetch())
{
	echo $row->data; // call the constructor function within abc class
}
?>

<?php  //********** prepare statement **************//

extract($_POST);
if(isset($submit))
{
	$statement=$connection->prepare("select * from tableName where email=:email and password=:password");
	//$statement->execute(array("email"=>$_POST['FieldValue']));
	$statement->execute(array("email"=>$email, "password"=>$password));
	if($statement->rowCount()) // if row is returned from database/ table
	{
		echo "Record Found";
	}
	else
	{
		echo "SORRY!! No Record Found";
	}
}
?>

<?php  //********** prepare statement using bindParam statement **************//

extract($_POST);
if(isset($submit))
{
	$statement=$connection->prepare("select * from tableName where email=:email and password=:password"); // We can use DELETE, INSERT and UPDATE QUERY as usual
	$statement->bindParam(":email", $userInput_1);
	$statement->bindParam(":password", $userInput_2);
	$statement->execute();
	if($statement->rowCount()) // if row is returned from database/ table
	{
		echo "Record Found";
	}
	else
	{
		echo "SORRY!! No Record Found";
	}
}
?>

<?php  //********** Fetch data using prepare statement and using bindParam statement **************//

extract($_POST);
if(isset($submit))
{
	$statement=$connection->prepare("select * from tableName where email=:email and password=:password"); // We can use DELETE, INSERT and UPDATE QUERY as usual
	$statement->bindParam(":email", $userInput_1);
	$statement->bindParam(":password", $userInput_2);
	$statement->execute();
	while($data = $statement->fetch(PDO::FETCH_ASSOC)) // if row is returned from database/ table
	{
		print_r($data);
	}
	
}
?>
