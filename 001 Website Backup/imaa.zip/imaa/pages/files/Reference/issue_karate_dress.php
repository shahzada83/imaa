<?php 
	// $material;  the value for $material is specified in view_student_status.php, from where the button is clicked
	//error_reporting(0);
	if(isset($_POST['issueMaterial']))
	{	
	  $issueMaterial=array_map('htmlspecialchars',$_POST);
	  $issueMaterial=array_map('trim',$issueMaterial);
	  $issueMaterial=array_map('addslashes',$issueMaterial);
	  //echo "<pre>";
	  //print_r($addStudent);
	  
	  validateIssueMaterialKD($issueMaterial);
	}
	
	function  validateIssueMaterialKD($issueMaterial)
	{
		if($issueMaterial[issuedTo]=='')
		{ 
			echo "<script>alert('Enter the NAME of the person to whom the {$issueMaterial[material]} is being issued')</script>"; 
		}
		elseif($issueMaterial[regSL]=='')
		{ 
			echo "<script>alert('Enter the {$issueMaterial[material]} REGISTER SERIAL No.')</script>"; 
		}
		elseif($issueMaterial[issueDate]=='dd/mm/yyyy')
		{ 
			echo "<script>alert('Enter Valid ISSUE DATE {$issueMaterial[material]} REGISTER SERIAL No.')</script>"; 
		}
		elseif($issueMaterial[issuedBy]=='')
		{ 
			echo "<script>alert('Enter the NAME of the person BY WHOM the {$issueMaterial[material]} is being issued'}</script>"; 
		}
		else
		{
			saveRecordKD($issueMaterial);
		}
			
	}
	
	function saveRecordKD($issueMaterial)
	{
		include('files/dbconn.php');
		
		$sqlMaterial ="INSERT INTO `materialissue` (`materialID`, `studID`, `material`, `regSL`, `issueDate`, `issuedTo`, `issuedBy`, `remark`) 
							VALUES 				   (:materialID, :studID, :material, :regSL, :issueDate, :issuedTo, :issuedBy, :remark)";
							
		$statementMaterial=$connection->prepare($sqlMaterial);	
		$statementMaterial->bindParam(":materialID", 	$issueMaterial[materialID]); // Hidden textbox	
		$statementMaterial->bindParam(":studID", 		$issueMaterial[studID]);	 // Hidden textbox
		$statementMaterial->bindParam(":material", 		$issueMaterial[material]);	 // Hidden textbox
		$statementMaterial->bindParam(":regSL", 		$issueMaterial[regSL]);	
		
		
		$string=explode("/",$issueMaterial[issueDate]);
		$issueDate=	$string[2]."-".$string[1]."-".$string[0];


		
		$statementMaterial->bindParam(":issueDate", 	$issueDate	);	
		$statementMaterial->bindParam(":issuedTo", 		$issueMaterial[issuedTo]);	
		$statementMaterial->bindParam(":issuedBy", 		$issueMaterial[issuedBy]);				
		$statementMaterial->bindParam(":remark",	 	$issueMaterial[remark]);			
		
		if($statementMaterial->execute())
		{
				echo "<script>alert( '{$issueMaterial[material]} Record Updated Successfully.' )</script>";
				// Next Update stockIssueID in studentfee Table
				$feeID = $issueMaterial[feeID]; 	// Hidden textbox
				$stockIssueID = $issueMaterial[regSL];	
				
				$sqlStudentFee="UPDATE `studentfee` SET stockIssueID=:stockIssueID where feeID=:feeID";
				$statementStudentFee=$connection->prepare($sqlStudentFee);	
				$statementStudentFee->bindParam(":stockIssueID", 	$stockIssueID); // Hidden textbox	
				$statementStudentFee->bindParam(":feeID", 			$feeID);	 // Hidden textbox
				if($statementStudentFee->execute())
				{
					echo "<script>alert( 'Fee Record Updated Successfully.' )</script>";
				}
				else
				{
					echo "<script>alert( 'Sorry Something went Wrong while updating Fee Record. Please contact Administrator.' )</script>";	
				}
		} 
		else
		{
			echo "<script>alert( 'Sorry Something went Wrong. Please contact Administrator.' )</script>";	
		}
		$admID=$issueMaterial[admID];
		echo "<script>document.location.href='main.php?pg=profile&admID={$admID}'</script>";
	}

	
?>
<form action="" method="post" onsubmit="validateMaterial()" name="formIssueMaterial">


			<input type="hidden" value="<?php echo $studID; ?>" name="studID" />
			<input type="hidden" value="<?php echo $admID; ?>" name="admID" />
			<input type="hidden" value="<?php echo $feeID; ?>" name="feeID" />
			<input type="hidden" value="<?php echo $product; ?>" name="material" />
			<?php 
			if($product=='ID Card')
			{ $materialID=1;}
			elseif($product=='KARATE DRESS')
			{ $materialID=2;}
			elseif($product=='TRACK SUITE')
			{ $materialID=3;}
			?>
			<input type="hidden" value="<?php echo $materialID; ?>" name="materialID" />	 <?php ?>
			
			
	<div class="row">
		<div class="col-lg-12">
			<div class="form-group">
				<label class="small">Issued To</label>
				<input class="form-control input-sm" type="text" name="issuedTo" id="issuedTo" value="<?php echo $studName; ?>"  placeholder="छात्र / छात्रा का नाम " onkeyup="document.getElementById('eissuedTo').innerHTML ='';">
				<span class="error" id="eissuedTo"></span>
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-lg-6">
			<div class="form-group">
				<label class="small">* Register SL.No.</label>
				<input class="form-control input-sm" type="text" name="regSL" value="<?php echo $issueMaterial['regSL']; ?>"  onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="4">
				<span class="error" id="eregSL"></span>
			</div>	
		</div>
	
		<div class="col-lg-6">
			<div class="form-group">
				<label class="small">* Issue Date</label>
				<?php $admDate=date("d/m/Y"); ?>
				<input name="issueDate" type="text" class="form-control input-sm" id="issueDate" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo $admDate; ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
				<span class="error" id="eissueDate"></span>
			</div>
		</div>
	</div>
	
	<div class="row">
		<div class="col-lg-12">
			<div class="">
				<label class="small">Issued By</label>
				
				<input class="form-control input-sm" type="text" name="issuedBy" value="<?php echo $_SESSION['sessionUserName']; ?>" onkeyup="document.getElementById('issuedBy').innerHTML ='';">
				<span class="error" id="eissuedBy"></span>
			</div>
		</div>
	</div>
	<br />
	<div class="row">
		<div class="col-lg-12">
			<div class="form-group">
				<label class="small">Remark:</label>
				
				<input class="form-control input-sm" type="text" name="remark" value="">
				
			</div>
		</div>
	</div>
	
	<div class="footer">
			<input class="btn btn-primary" type="submit" name="issueMaterial" value="Save Record" onmouseover="validateMaterial();">
	</div>
</form>
    <script src="plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
    <!-- date-range-picker -->
    <!-- Page script -->
    <script type="text/javascript">
      $(function () {
        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
        //Datemask2 mm/dd/yyyy
        $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
        //Money Euro
        $("[data-mask]").inputmask();

        //Date range picker
        $('#reservation').daterangepicker();
        //Date range picker with time picker
        $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
        //Date range as a button
        

      });
    </script>
	
	<script language="javascript">

	function validateMaterial(e)
	{
		//alert('');
		if(document.getElementById('issuedTo').value == "")
	    {
			 alert( "Please Enter Student Name." );
			 //document.formIssueMaterial.issuedTo.focus() ;
			 document.getElementById('eissuedTo').innerHTML ="Field can't be Blank";
			 return false;
	    }
				if( document.issueMaterial.regSL.value == "")
	    {
			 alert( "Please Enter Register SL.No." );
			 document.issueMaterial.regSL.focus() ;
			 document.getElementById('eregSL').innerHTML ="Field can't be Blank";
			 return false;
	    }

		if( document.issueMaterial.issueDate.value == "dd/mm/yyyy")
	    {
			 alert( "Please Enter Issue Date" );
			 document.issueMaterial.issueDate.focus() ;
			 document.getElementById('eissueDate').innerHTML ="Field can't be Blank";
			 return false;
	    }
		
		if( document.addStudentForm.issuedBy.value == "" )
	    {
			 alert( "Please enter Issued By Name." );
			 document.addStudentForm.issuedBy.focus() ;
			 document.getElementById('eissuedBy').innerHTML ="Field can't be Blank";
			 return false;
	    }
		
	}
</script>	


