-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 06, 2018 at 10:21 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `imaa`
--

-- --------------------------------------------------------

--
-- Table structure for table `monthlyfeesummery`
--

CREATE TABLE IF NOT EXISTS `monthlyfeesummery` (
  `mfsID` int(11) NOT NULL AUTO_INCREMENT,
  `studID` int(11) NOT NULL,
  `studentfeeID` varchar(1023) NOT NULL COMMENT 'timestamp from studentfee Table',
  `receiptNo` varchar(1023) NOT NULL,
  `feeFrom` varchar(1023) NOT NULL,
  `feeTill` varchar(1023) NOT NULL,
  `totalMonths` int(11) NOT NULL,
  `feePerMonth` int(11) NOT NULL,
  `lateFine` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `dues` int(11) NOT NULL,
  `totalFeeReceived` int(11) NOT NULL,
  `createdOn` varchar(1023) NOT NULL,
  `createdBy` varchar(1023) NOT NULL,
  PRIMARY KEY (`mfsID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
