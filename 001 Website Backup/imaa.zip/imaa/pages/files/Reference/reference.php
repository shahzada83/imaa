<section class="content" style="font-size:8px">

	  <div class="box box-solid box-warning">
		<div class="box-header">
		  <h3 class="box-title">Student Profile</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		
		</div><!-- /.box-body -->
	  </div><!-- /.box -->

</section>