<?php include('files/CODEsearch_student_report.php')?>
<form name="formSearchReport" action="" method="post">
<div class="box box-solid box-warning">
<div class="box-header">
  <h3 class="box-title">Student Report Search</h3>
</div><!-- /.box-header -->
<div class="box-body">
	<div class="row">
		<div class="col-md-3">
			<div class="form-group">
				<label class="">Case</label>
			
				<select name="case" class="form-control input-sm">
					<option value="1" <?php if($case==1){?> selected="selected" <?php } ?>>Pending</option>
					<option value="0" <?php if($case==0){?> selected="selected" <?php } ?>>Non - Pending</option>
				</select>
				<span class="error" id="eFormNo"></span>
			</div>	
		</div>
		
		<div class="col-md-3">
			<div class="form-group">
				<label class="">Field</label>
				<select name="field" class="form-control input-sm">
				<?php
				$sqlMaterial="select feeDetailID, head from feedetail";
				$statementMaterial=$connection->query($sqlMaterial);
				while($dataMaterial=$statementMaterial->fetch(PDO::FETCH_ASSOC))
				{
				?>
					<option value="<?php echo $dataMaterial[feeDetailID]; ?>" <?php if($field==$dataMaterial[feeDetailID]){?> selected="selected" <?php } ?>><?php echo ($dataMaterial[feeDetailID]==6)?'ID CARD':$dataMaterial[head]; ?></option>
				<?php
				}
				?>	
				</select>
				<span class="error" id="eFormNo"></span>
			</div>	
		</div>
		
		<div class="col-md-3">
			<div class="form-group">
				<label class=""></label>
				
				<span class="error" id="eFormNo"></span>
			</div>	
		</div>
		
		<div class="col-md-3">
			<br />
			<input type="submit" name="searchReport" value="Search Record" class="btn btn-success" />
		</div>
	</div>
</div><!-- /.box-body -->
</div><!-- /.box -->
</form>

