	 
       
    [currentBelt] => Yellow
    [gradingFor] => None
	[batchPreferene] => Evening
    
    [photo] => 
    
    
    
    [aadharPhoto] => 
    
    
    [bloodGroup] => A +
    [height] => 5.6"
    [weight] => 75 Kg
    [occupation] => Working
    [orgName] => Company
    
    [disability] => 0
    [disabilityDetail] => specify disability
    [remark] => Remark / Note
    
	[passout] => 0
    [dropout] => 0
    [deleted] => 0

<?php
	$studSlno=$_GET['stud_slno'];
	$statement=$connection->prepare("select * from student where studSlno=:studSlno"); // We can use DELETE, INSERT and UPDATE QUERY as usual
	$statement->bindParam(":studSlno", $studSlno);
	$statement->execute();
	$data = $statement->fetch(PDO::FETCH_ASSOC); // if row is returned from database/ table
	
	//echo "<pre>";
	//print_r($data);
?>

<div class="box">
<div class="box-header">
  <h3 class="box-title">Condensed Full Width Table</h3>
</div><!-- /.box-header -->
<div class="box-body no-padding">
  <table class="table table-condensed">
	<tr>
	  <th style="width: 10px">#</th>
	  <th>ID's </th>
	  <th>Progress</th>
	  <th style="width: 40px">Label</th>
	</tr>
	<tr>
	  <td></td>
	  <td>Update software</td>
	  <td>
		<div class="progress progress-xs">
		  <div class="progress-bar progress-bar-danger" style="width: 55%"></div>
		</div>
	  </td>
	  <td><span class="badge bg-red">55%</span></td>
	</tr>
	
  </table>
</div><!-- /.box-body -->
</div>
			  
			  
<style>
.data-head
{
	font-size:12px;
}
.data
{
	color:blue;
	font-weight:bold;
}
</style>	
<div class="row">
	<div class="col-lg-2">
		<img src="" height="150px" width="100px" style="border:1px solid #000; padding:2px" class="img-responsive">
	</div>

	<div class="col-lg-10">
			<div class="col-lg-2 data-head">
				<h4>Code's </h4><hr>
				<strong>Roll No. : </strong><span class="data"><?php echo $data['rollNo']; ?></span><br>
				<strong>Adm Date : </strong><span class="data"><?php echo format_date($data['admDate']); ?></span><br>
				<strong>Form No. : </strong><span class="data"><?php echo $data['formNo']; ?></span><br>
				<strong>Adm ID : </strong><span class="data"><?php echo $data['admID']; ?></span><br>
				<strong>Karate Adm ID : </strong><span class="data"><?php echo $data['karateAdmID']; ?></span>
			</div>
			
			<div class="col-lg-3 data-head">
				<h4>Student Data</h4><hr>
				<strong>Name : </strong><span class="data"><?php echo ($data['gender']=="Male")?'Mr. ':'Ms. '; echo $data['name']; ?></span><br>
				<strong>Aadhar ID : </strong><span class="data"><?php echo $data['aadharNo']; ?></span><br>
				<strong>DOB : </strong><span class="data"><?php echo format_date($data['dob']); ?></span><br>
				<strong>Father Name : </strong><span class="data"><?php echo $data['fatherName']; ?></span><br>
			</div>
			
			<div class="col-lg-3 data-head">
				<h4>Contact Details</h4><hr>
				<strong>Mobile : </strong><span class="data"><?php echo $data['mobile']; ?></span><br>
				<strong>Email : </strong><span class="data"><?php echo $data['email']; ?></span><br>
				<strong>Address : </strong><span class="data"><?php echo $data['address']; ?></span><br>
				<strong>Father Name : </strong><span class="data"><?php echo $data['fatherName']; ?></span><br>
			</div>
	</div>

</div>