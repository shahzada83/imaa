<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php
	
	include('dbconn.php');
 	$task=$_GET['tsk'];
	$page=$task;
 	$stud_slno=$_GET['slno'];
 
	switch($task)
	{
		case "del": // Pass Out
			$task="DELETED";
			$query="UPDATE `student` SET `deleted`=1 where `studID`='$stud_slno'";
		break;
		
		case "do": // Pass Out
			$task="DROP OUT";
			$query="UPDATE student SET `dropout`=1 where studID='$stud_slno'";
		break;
		
		case "rdo": // Pass Out
			$task="Marked as Regular Student";
			$query="UPDATE student SET `dropout`=0 where studID='$stud_slno'";
		break;
		
		case "delMaterial": // Drop Material
			$task=" Material Deleted ";
			$query="DELETE from materialdetail where  materialID='$stud_slno'";
			$goto="../main.php?pg=" . base64_encode('add product');
		break;
		
		case "delStock": // Drop Material
			$task=" Stock Deleted ";
			$query="DELETE from stockentry where  stockID='$stud_slno'";
			$goto="../main.php?pg=" . base64_encode('add stock');
		break;
		//-----------------------------------------------------------------------
	}
	
if($connection->query($query))
{
	
	if($page=='dw')
	{
		echo "<script>document.location.href='../main.php?pg=walk-In'</script>";
	}
	elseif($page=='delMaterial')
	{
		echo "<script>document.location.href='{$goto}'</script>";
	}
	elseif($page=='delStock')
	{
		echo "<script>alert('$task successfully.')</script>";
		echo "<script>document.location.href='{$goto}'</script>";
	}
	else
	{
		echo "<script>alert('The student has been $task successfully.')</script>";
	}
	echo "<script>window.close();</script>";
}
?>