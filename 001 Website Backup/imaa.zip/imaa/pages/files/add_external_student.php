 <?php //error_reporting(0); ?>
<style>
	.errorMsg
	{
		color:#FFFF33;
	}
</style>

<form action="" method="post" name="formAddCourses" style="color:#000">
<div id="externalStudent" class="modal fade modal-warning" role="dialog">
  <div class="modal-dialog" style="width:900px">

    <!-- Modal content-->
    <div class="modal-content" style="width:900px">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><i class="fa fa-users"></i> Add External Student</h4>
      </div>
      <div class="modal-body">
	  
	  
	  
<!-- /.box-header -------------------------------------------------------------------------------------------------------------------------->
	<div id="show_msg_course"></div>
		<div class="box-body">
			<div class="row">
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">* Form No.</label>
							<input class="form-control input-sm" type="text" name="formNo" value="<?php echo $addStudent['formNo']; ?>"  placeholder="फॉर्म नंबर " onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="4">
							<span class="error" id="eFormNo"></span>
						</div>	
					</div>
					
					<div class="col-lg-2 col-md-2  col-xs-6">
						<div class="form-group">
							<label class="small">* Admission Date</label>
							<?php $admDate=date("d/m/Y"); ?>
							<input name="admDate" type="text" class="form-control input-sm" id="adm_date" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo $admDate; ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
							
							<span class="error" id="eAdmDate"></span>
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2  col-xs-6">
						<div class="form-group">
							<label class="small">* Reg. No.</label>
							<?php 
							$sqlRegNo="select MAX(formNo) as regNo from student";
							$stmtRegNo = $connection->query($sqlRegNo);
							$dataRegNo=$stmtRegNo->fetch(PDO::FETCH_ASSOC); 
							$newAdmID=$dataRegNo[regNo]+1;
							 ?>
							<input name="regNo" type="text" readonly="readonly" class="form-control input-sm"  data-mask value="<?php echo $newAdmID; ?>">
							
							<span class="error" id="eAdmDate"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-2 col-xs-6 hidden">
						<div class="form-group">
							<label class="small">* Admission ID</label>
							<?php $admID=mktime(); ?>
							<input class="form-control input-sm" type="text" name="admID" value="<?php echo $admID; ?>"  placeholder="एडमिशन आई डी" readonly="true">
						</div>
					</div>
					<!--
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">Karate Admission ID</label>
							<input class="form-control input-sm" type="text" name="karateAdmID" value="<?php echo $addStudent['karateAdmID']; ?>"  placeholder="कराटे एडमिशन आई डी" onkeyup="document.getElementById('ekarateAdmID').innerHTML ='';" onKeyPress="return isNumberKey(event)">
							<span class="error" id="ekarateAdmID"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-2 col-xs-12">
						<div class="form-group">
							<label class="small"> Roll No. </label>
							<input class="form-control input-sm" type="text" name="rollNo" value="<?php echo $addStudent['rollNo']; ?>"  placeholder="क्रमांक संख्या " onkeyup="document.getElementById('erollNo').innerHTML ='';" onKeyPress="return isNumberKey(event)">
							<span class="error" id="erollNo"></span>
						</div>
					</div>
					-->
				</div>
				
				
				<div class="row">
					<div class="col-lg-4  col-md-4 col-xs-6">
						<div class="form-group">
							<label class="small">* Name</label>
							<input class="form-control input-sm" type="text" name="name" value="<?php echo $addStudent['name']; ?>"  placeholder="छात्र / छात्रा का नाम " onkeyup="document.getElementById('ename').innerHTML ='';">
							<span class="error" id="ename"></span>
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2  col-xs-6">
						<div class="form-group">
							<label class="small">* Date of Birth</label>
							<input name="dob" type="text" class="form-control input-sm" id="dob" data-inputmask="'alias': 'dd/mm/yyyy'"  value="<?php echo $addStudent['dob']; ?>"  data-mask  onChange="document.getElementById('edob').innerHTML ='';">

							<span class="error" id="edob"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">* Gender</label>
							<select class="form-control input-sm" type="text" name="gender" onChange="document.getElementById('egender').innerHTML ='';">
							<option value='' 		<?php if($addStudent['gender']==''){?> selected="selected" <?php } ?>>None</option>
							<option value="Male" 	<?php if($addStudent['gender']=='Male'){?> selected="selected" <?php } ?>>Male</option>
							<option value="Female" 	<?php if($addStudent['gender']=='Female'){?> selected="selected" <?php } ?>>Female</option>
							</select>
							<span class="error" id="egender"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-4 col-xs-6">
						<div class="form-group">
							<label class="small">Aadhar No. </label>
							<input class="form-control input-sm" type="text" name="aadharNo" value="<?php echo $addStudent['aadharNo']; ?>"  placeholder="आधार संख्या " onkeyup="document.getElementById('eaadharNo').innerHTML ='';" maxlength="12" onKeyPress="return isNumberKey(event)">
							
							<span class="error" id="eaadharNo"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-4 col-xs-6">
						<div class="form-group">
							<label class="small"><i class="fa fa-whatsapp"></i>&nbsp;&nbsp; WhatsApp No.</label>
							<input class="form-control input-sm" type="text" name="whatsapp" value="<?php echo $addStudent['whatsapp']; ?>"  placeholder="आधार संख्या " onkeyup="document.getElementById('eaadharNo').innerHTML ='';" maxlength="12" onKeyPress="return isNumberKey(event)">
							
							<span class="error" id="eaadharNo"></span>
						</div>
					</div>
					
				</div> <!-- Close Row 1 -->	
				
				<div class="row">
					<div class="col-lg-4  col-md-4 col-xs-6">
						<div class="form-group">
							<label class="small">* Father's Name</label>
							<input class="form-control input-sm" type="text" name="fatherName" value="<?php echo $addStudent['fatherName']; ?>"  placeholder="पिता का नाम " onkeyup="document.getElementById('efatherName').innerHTML ='';">
							<span class="error" id="efatherName"></span>
						</div>
					</div>
					
					<div class="col-lg-4  col-md-4 col-xs-6">
						<div class="form-group">
							<label class="small">* Present Address</label>
							<input class="form-control input-sm" type="text" name="address" value="<?php echo $addStudent['address']; ?>"  placeholder="घर का पूरा पता  " onkeyup="document.getElementById('eaddress').innerHTML ='';">
							<span class="error" id="eaddress"></span>
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2  col-xs-6">
						<div class="form-group">
							<label class="small">* Mobile No</label>
							<input class="form-control input-sm" type="text" name="mobile" value="<?php echo $addStudent['mobile']; ?>"  placeholder="मोबाइल संख्या " onkeyup="document.getElementById('emobile').innerHTML ='';"maxlength="10" onKeyPress="return isNumberKey(event)">

							<span class="error" id="emobile"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">Email</label>
							<input class="form-control input-sm" type="text" name="email" value="<?php echo $addStudent['email']; ?>"  placeholder="ईमेल" onkeyup="document.getElementById('eemail').innerHTML ='';">
							<span class="error" id="eemail"></span>
						</div>
					</div>
					
				</div> <!-- Close Row 1 -->	
				
				<div class="row">
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">Blood Group</label>
							<select class="form-control input-sm" type="text" name="bloodGroup" placeholder="एडमिशन आई डी" onChange="document.getElementById('ebloodGroup').innerHTML ='';">
								<option value=''>None</option>
								<option value='A +' 	<?php if($addStudent['bloodGroup']=='A +'){?> selected="selected" <?php } ?>>A - POSITIVE</option>
								<option value='A -' 	<?php if($addStudent['bloodGroup']=='A -'){?> selected="selected" <?php } ?>>A - NEGATIVE</option>
								<option value='B +' 	<?php if($addStudent['bloodGroup']=='B +'){?> selected="selected" <?php } ?>>B - POSITIVE</option>
								<option value='B -' 	<?php if($addStudent['bloodGroup']=='B -'){?> selected="selected" <?php } ?>>B - NEGATIVE</option>
								<option value='AB +' 	<?php if($addStudent['bloodGroup']=='AB +'){?> selected="selected" <?php } ?>>AB - POSITIVE</option>
								<option value='AB -' 	<?php if($addStudent['bloodGroup']=='AB -'){?> selected="selected" <?php } ?>>AB - NEGATIVE</option>
								<option value='O +' 	<?php if($addStudent['bloodGroup']=='O +'){?> selected="selected" <?php } ?>>O - POSITIVE</option>
								<option value='O -' 	<?php if($addStudent['bloodGroup']=='O -'){?> selected="selected" <?php } ?>>O - NEGATIVE</option>
								<option value='HH Group' <?php if($addStudent['bloodGroup']=='HH Group'){?> selected="selected" <?php } ?>>HH/ Bombay Group </option>
							</select>
							<span class="error" id="ebloodGroup"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">Height</label>
							<input class="form-control input-sm" type="text" name="height" value="<?php echo $addStudent['height']; ?>"  placeholder="लम्बाई " onkeyup="document.getElementById('eheight').innerHTML ='';">
							<span class="error" id="eheight"></span>
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2  col-xs-6">
						<div class="form-group">
							<label class="small">Weight</label>
							<input class="form-control input-sm" type="text" name="weight" value="<?php echo $addStudent['weight']; ?>"  placeholder="वज़न " onkeyup="document.getElementById('eweight').innerHTML ='';">
							<span class="error" id="eweight"></span>
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2  col-xs-6">
						<div class="form-group">
							<label class="small">* Occupation</label>
							<select class="form-control input-sm" type="text" name="occupation" onChange="document.getElementById('eoccupation').innerHTML ='';">
								<option value='Student' <?php if($addStudent['occupation']=='Student'){?> selected="selected" <?php } ?>>Student</option>
								<option value='Working' <?php if($addStudent['occupation']=='Working'){?> selected="selected" <?php } ?>>Working</option>
								<option value='' 		<?php if($addStudent['occupation']==''){?> selected="selected" <?php } ?>>None</option>
							</select>
							<span class="error" id="eoccupation"></span>
						</div>
					</div>
					
					<div class="col-lg-4 col-md-4  col-xs-6">
						<div class="form-group">
							<label class="small">*Company/ School/ College Name</label>
							<input class="form-control input-sm" type="text" name="orgName" value="<?php echo $addStudent['orgName']; ?>"  placeholder="कंपनी / स्कूल या कॉलेज का नाम " onkeyup="document.getElementById('eorgName').innerHTML ='';">
							<span class="error" id="eorgName"></span>
						</div>
					</div>
									
				</div> <!-- Close Row 1 -->	
				
				<div class="row">
					
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">* Batch Preference</label>
							<select class="form-control input-sm" type="text" name="batchPreferene" onChange="document.getElementById('ebatchPreferene').innerHTML ='';">
								<option value='' 					<?php if($addStudent['batchPreferene']=='')					{?> selected="selected" <?php } ?>>None</option>
								<?php
								$sqlBatch="SELECT distinct(`batchNo`) from `studentbatch` where `active`=0";
								$stmtBatch=$connection->query($sqlBatch);
								while($dataBatch=$stmtBatch->fetch(PDO::FETCH_ASSOC))
								{
								?>
								<option value="<?php echo $dataBatch[batchNo];?>" <?php if($addStudent['batchPreferene']==$dataBatch['batchNo']){?> selected="selected" <?php } ?>><?php echo $dataBatch[batchNo];?></option>
								<?php
								}
								?>
								
							</select>
							<span class="error" id="ebatchPreferene"></span>
						</div>
					</div>
					
					<div class="col-lg-2  col-md-2 col-xs-6">
						<div class="form-group">
							<label class="small">* Any Disability</label>
							<select class="form-control input-sm" type="text" name="disability" onChange="document.getElementById('edisability').innerHTML ='';">
								<option value='' 	<?php if($addStudent['disability']==''){?> selected="selected" <?php } ?>>None</option>
								<option value='0' 	<?php if($addStudent['disability']=='0'){?> selected="selected" <?php } ?>>No</option>
								<option value='1' <?php if($addStudent['disability']=='1'){?> selected="selected" <?php } ?>>Yes</option>
							</select>
							<span class="error" id="edisability"></span>
						</div>
					</div>
					
					<div class="col-lg-4  col-md-4 col-xs-6">
						<div class="form-group">
							<label class="small">Specify Disability</label>
							<input class="form-control input-sm" type="text" name="disabilityDetail" value="<?php echo $addStudent['disabilityDetail']; ?>"  placeholder="अछमता के बारे में बताये  " onkeyup="document.getElementById('edisabilityDetail').innerHTML ='';">
							<span class="error" id="edisabilityDetail"></span>
						</div>
					</div>
				
					<div class="col-lg-2  col-md-2 col-xs-12">
						<div class="form-group">
							<label class="small">* Admission for Belt </label>
							<select class="form-control input-sm" type="text" name="currentBelt" value="<?php echo $addStudent['noPostSc']; ?>"  placeholder="एडमिशन आई डी">
								<option value='White' <?php if($addStudent['gradingForBelt']=='White'){?> selected="selected" <?php } ?>>White</option>
								<option value='Yellow' style="background:yellow; color:black;" <?php if($addStudent['currentBelt']=='Yellow'){?> selected="selected" <?php } ?>>Yellow</option>
								
								<option value='Orange' style="background:orange; color:black;" <?php if($addStudent['currentBelt']=='Orange'){?> selected="selected" <?php } ?>>Orange</option>
                                
								<option value='Green' style="background:green; color:white;" 	<?php if($addStudent['currentBelt']=='Green'){?> selected="selected" <?php } ?>>Green</option>
                                
								<option value='Blue' style="background:blue; color:white;" 	<?php if($addStudent['currentBelt']=='Blue'){?> selected="selected" <?php } ?>>Blue</option>
                                
								<option value='Purple' style="background:purple; color:white;" <?php if($addStudent['currentBelt']=='Purple'){?> selected="selected" <?php } ?>>Purple</option>
                                
								<option value='Brown IV' style="background:brown; color:white;" 	<?php if($addStudent['currentBelt']=='Brown IV'){?> selected="selected" <?php } ?>>Brown IV</option>
								<option value='Brown III' style="background:brown; color:white;" 	<?php if($addStudent['currentBelt']=='Brown III'){?> selected="selected" <?php } ?>>Brown III</option>
								<option value='Brown II' style="background:brown; color:white;" 	<?php if($addStudent['currentBelt']=='Brown II'){?> selected="selected" <?php } ?>>Brown II</option>
								<option value='Brown I' style="background:brown; color:white;" 	<?php if($addStudent['currentBelt']=='Brown I'){?> selected="selected" <?php } ?>>Brown I</option>
								
								<option value='Black' style="background:black; color:white;" 	<?php if($addStudent['currentBelt']=='Black'){?> selected="selected" <?php } ?>>Black </option>
							</select>
							
						</div>
					</div>
					
					<div class="col-lg-2  col-md-2 col-xs-12 hidden">
						<div class="form-group">
							<label class="small">* Grading For Belt </label>
							<select class="form-control input-sm" type="text" name="gradingForBelt">
								<option value='' <?php if($addStudent['gradingForBelt']==''){?> selected="selected" <?php } ?>>NONE</option>
								<option value='White' <?php if($addStudent['gradingForBelt']=='White'){?> selected="selected" <?php } ?>>White</option>
								<option value='Yellow' style="background:yellow; color:black;" <?php if($addStudent['gradingForBelt']=='Yellow'){?> selected="selected" <?php } ?>>Yellow</option>
								
								<option value='Orange' style="background:orange; color:black;" <?php if($addStudent['gradingForBelt']=='Orange'){?> selected="selected" <?php } ?>>Orange</option>
                                
								<option value='Green' style="background:green; color:white;" 	<?php if($addStudent['gradingForBelt']=='Green'){?> selected="selected" <?php } ?>>Green</option>
                                
								<option value='Blue' style="background:blue; color:white;" 	<?php if($addStudent['gradingForBelt']=='Blue'){?> selected="selected" <?php } ?>>Blue</option>
                                
								<option value='Purple' style="background:purple; color:white;" <?php if($addStudent['gradingForBelt']=='Purple'){?> selected="selected" <?php } ?>>Purple</option>
                                
								<option value='Brown IV' style="background:brown; color:white;" 	<?php if($addStudent['gradingForBelt']=='Brown IV'){?> selected="selected" <?php } ?>>Brown IV</option>
                                
								<option value='Brown III' style="background:brown; color:white;" 	<?php if($addStudent['gradingForBelt']=='Brown III'){?> selected="selected" <?php } ?>>Brown III</option>
                                
								<option value='Brown II' style="background:brown; color:white;" 	<?php if($addStudent['gradingForBelt']=='Brown II'){?> selected="selected" <?php } ?>>Brown II</option>
                                
								<option value='Brown I' style="background:brown; color:white;" 	<?php if($addStudent['gradingForBelt']=='Brown I'){?> selected="selected" <?php } ?>>Brown I</option>
                                
								
								<option value='Black' style="background:black; color:white;" 	<?php if($addStudent['gradingForBelt']=='Black'){?> selected="selected" <?php } ?>>Black </option>
							</select>
							<span class="error" id="egradingForBelt"></span>
						</div>
					</div>
				</div> <!-- Close Row 1 -->	
				
				<div class="row">	
					<div class="col-lg-12  col-md-12 col-xs-12">
						<div class="form-group">
							<label class="small">Remark</label>
							<input class="form-control input-sm" type="text" name="remark" value="<?php echo $addStudent['remark']; ?>"  placeholder="">
							
						</div>
					</div>
				</div>	
				
		</div>
		<!-- /.box-body -->
	</div>
<?php
/*
The code to process this form data is done through ajax, which is called through submit button named "add_courses", 
which is present in the view_university_profile.php file under model div having id="addCourses"
*/
?>
</div>
      <div class="modal-footer">
		<button type="button" name="add_courses" class="btn btn-warning" onClick="validate_add_courses();">Submit</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</form>

<script>
function validate_add_courses()
{
	//alert();
	if(document.getElementById('mode').value=='')
	{
		document.getElementById('Error_mode').innerHTML="<i class='fa fa-exclamation-triangle'></i> Required!";
		document.getElementById('mode').focus();
	}
	else if(document.getElementById('faculty').value=='')
	{
		document.getElementById('Error_faculty').innerHTML="<i class='fa fa-exclamation-triangle'></i> Please Select Faculty For The Course";
		document.getElementById('faculty').focus();
	}
	else if(document.getElementById('code').value=='')
	{
		document.getElementById('Error_code').innerHTML="<i class='fa fa-exclamation-triangle'></i> Required!";
		document.getElementById('code').focus();
	}
	else if(document.getElementById('name').value=='')
	{
		document.getElementById('Error_name').innerHTML="<i class='fa fa-exclamation-triangle'></i> Please Enter Course Name";
		document.getElementById('name').focus();
	}
	else if(document.getElementById('duration').value=='')
	{
		document.getElementById('Error_duration').innerHTML="<i class='fa fa-exclamation-triangle'></i> Required!";
		document.getElementById('duration').focus();
	}
	else if(document.getElementById('eligibility').value=='')
	{
		document.getElementById('Error_eligibility').innerHTML="<i class='fa fa-exclamation-triangle'></i> Please Enter Eligibility";
		document.getElementById('eligibility').focus();
	}
	else if(document.getElementById('specialization').value=='')
	{
		document.getElementById('Error_branch').innerHTML="<i class='fa fa-exclamation-triangle'></i> Required!";
		document.getElementById('specialization').focus();
	}
	else
	{
		saveCourseData();
	}
}


function saveCourseData()
{
	//alert();
	event.preventDefault();
	$.ajax({
	url: "files/code_add_courses.php",
	method: "post",
	data: $('form').serialize(),
	dataType: "text",
		success: function (strDate)
		{
			$('#show_msg_course').html(strDate);
		}
	})
}
</script>