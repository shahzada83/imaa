<?php

		/*********************SESSION VARIABLE*********************/
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php 

include('CODEadd_stock.php'); 
if(isset($_REQUEST[add_stock]))
{
	$stockIDCheckBox=$_REQUEST['stockIDCheckBox']; // Coming from viewStockEntry.php	
	
	foreach ($stockIDCheckBox as $stockIDtoUpdate)
	{
		$sqlStockEntryData="select * from stockentry where stockID='$stockIDtoUpdate'";
		$stmtStockEntryData=$connection->query($sqlStockEntryData);
		$dataStockEntryData=$stmtStockEntryData->fetch(PDO::FETCH_ASSOC);
		
		$itemName 		= 	$dataStockEntryData[itemName];
		$quality 		=	$dataStockEntryData[quality];
		$size			=	$dataStockEntryData[size];
		$receivedQty	=	$dataStockEntryData[receivedQty];
		
		$sqlUpdateMaterialDetail = "UPDATE `materialdetail` SET `StockReceived`=StockReceived + $receivedQty WHERE
									itemName = '$itemName' and size='$size' and quality='$quality'";
		
		if($stmtUpdateMaterialDetail=$connection->query($sqlUpdateMaterialDetail))
		{
			$sqlUpdateStockEntry="UPDATE stockentry SET materialDetailUpdate=0 where stockID='$stockIDtoUpdate'";
			if($connection->query($sqlUpdateStockEntry))
			{
				$AllSaved=true;	
			}	
		}
		else
		{
				echo "<script>alert('Sorry!! The stock could not be updated. No such Product Exists.')</script>";	
		}
	}
	
	if($AllSaved==true)
	{
		echo "<script>alert('Stock Updated Successfullly.')</script>";
		echo "<script><document.location.href='main.php?pg=". base64_encode("add stock")."'</script>";
	}
}
?>

<span  id="show_msg"></span>
<form action="" method="post" name="formAddStock">
<div class="box box-solid box-primary">
	<div class="box-header">
	  <h3 class="box-title">Add Stock</h3>
	</div><!-- /.box-header -->
	<div class="box-body">
	
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Bill Date</label>
					<input name="billDate" type="text" class="form-control input-sm" id="billDate" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>">
					<span class="error" id="efeedate"></span>
				</div>
			</div>
			
			<div class="col-md-2" id="paymentModeChequeNoMaterial">
				<div class="form-group">
					<label class="label_font">Bill No.</label>
					<input class="form-control input-sm" type="text" name="billNo" id="billNo" value="<?php echo $billNo; ?>" onblur="showTableData(this.value)" list="bill" >
					<datalist id="bill">
						<?php
						$sqlPendingBills="SELECT distinct(BillNo) as billNo from stockentry where materialDetailUpdate=1";
						$stmtPendingBills=$connection->query($sqlPendingBills);
						while($dataPendingBills=$stmtPendingBills->fetch(PDO::FETCH_ASSOC))
						{
						?>
							<option><?php echo $dataPendingBills[billNo]; ?></option>
						<?php
						}
						?>
					</datalist>
					<span class="error" id="eIDcardFee"></span>
				</div>
			</div>
			
			<div class="col-md-2" id="paymentModeChequeNoMaterial">
				<div class="form-group">
					<label class="label_font"></label><br /><br />
					<a href="main.php?pg=<?php echo base64_encode('add product'); ?>"  class="form-control input-sm btn-danger"><i class="fa fa-plus"></i> Add Product</a>
					<span class="error" id="eIDcardFee"></span>
				</div>
			</div>
		</div> <!-- row 1-->
		
	<table class="table table-bordered">
                    <tr class="info">
					  <th>Product</th>	
                      <th style="width: 10px">Quality</th>
                      <th>Size</th>
					  
                      <th>Quantity</th>
                      <th style="width: 40px">Cost Price</th>
					  <!--<th>Sale Price</th>-->
					  <th>Row Total</th>
					  <th></th>
                    </tr>
		<!----------------------------------------------------------------------------------------------------------------------------------------->
		
		<tr class="info">
			<td>
				<select name="materialID" id="materialID" class="form-control input-sm" onchange="getQuality(this.value)">
					<option value=""></option>
				<?php
				$sqlMaterialID="select distinct(itemName) as itemName from materialdetail";
				$stmtMaterialID=$connection->query($sqlMaterialID);
				while($dataMaterialDetail=$stmtMaterialID->fetch(PDO::FETCH_ASSOC))
				{
				?>
					<option><?php echo $dataMaterialDetail[itemName];?></option>
				<?php
				}
				?>
				</select>
			</td>
			
			<td class="">
				<select id="tdQuality" class='form-control input-sm' name="quality" onchange="getSize(this.value)">
				
				</select>
			</td>
			<td>
				<select id="tdSize" class='form-control input-sm' name='size'>
			
				</select>
			</td>
			
				
			
			<td>
				<input class="form-control input-sm no-border" type="text" name="quantity" id=="quantity"  placeholder="Quantity" onKeyPress="return isNumberKey(event)" maxlength="4">
			</td>
			
			<td>
				<input class="form-control input-sm no-border" type="text" name="costPrice" id="costPrice"  placeholder="Purchase Price"  onKeyPress="return isNumberKey(event)" maxlength="5">
			</td>
			<!--
			<td>
				<input class="form-control input-sm no-border" type="text" name="salePrice[]" value=""  placeholder="Sale Price"  onKeyUp="calculateStockRowTotal();"  onKeyPress="return isNumberKey(event)" maxlength="5">
			</td>
			-->
			<td>
				<input class="form-control input-sm no-border" readonly="readonly" type="text" name="rowTotal" id="rowTotal"  placeholder="Row Total" onKeyPress="return isNumberKey(event)" maxlength="5">
			</td>
			
			<td>
				<a href="#" id="addStock" class="form-control input-sm btn-info" onclick="calculateStockRowTotal()"><i class="fa fa-plus"></i> Add More Stock</a>
			</td>
		
		</tr>
		
		
			<tr>
				<table id="divTable" class="table table-bordered table-striped table-responsive">
		
				</table>
			</tr>	
	
		<!----------------------------------------------------------------------------------------------------------------------------------------->
		</table>
		
		
	</div><!-- /.box-body -->
	
		<div class="panel-footer" id="">
			<input class="btn btn-warning" type="submit" name="add_stock" value="Final!! Update Stock Record" onMouseOver="validate();" onClick="return confirm_action('Are you sure you want to update the Stock?')">
		</div>
		
</div><!-- /.box -->
</form>

<script src="files/AjaxFeeMaterial/js/jquery-3.2.1.js" type="text/javascript"></script>

<script>
function showTableData(BillNo) {
	//alert(item);
  var xhttp;    
  if (BillNo == "") {
    document.getElementById("divTable").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("divTable").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "files/AjaxFeeMaterial/viewStockEntry.php?billNo="+BillNo, true);
  xhttp.send();
  
}
</script>

<script>
function getQuality(item) {
	//alert(item);
  var xhttp;    
  if (item == "") {
    document.getElementById("tdQuality").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("tdQuality").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "files/AjaxFeeMaterial/getQuality.php?itm="+item, true);
  xhttp.send();
}
</script>

<script>
function getSize(qty) {
	//alert(qty);
  var xhttp; 
  var materialID=document.getElementById('materialID').value;   
  if (qty == "") {
    document.getElementById("tdSize").innerHTML = "";
    return;
  }
  if (materialID == "") {
    document.getElementById("tdSize").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("tdSize").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "files/AjaxFeeMaterial/getSize.php?itm="+materialID+"&qty="+qty, true);
  xhttp.send();
}
</script>

<script type="text/javascript">
	
		function InsertStockData()
		{
			event.preventDefault();
				$.ajax({
				url: "files/CodeAddStock.php",
				method: "post",
				data: $('form').serialize(),
				dataType: "text",
					success: function (strDate)
					{
						$('#show_msg').html(strDate)
					}
				})
				
				showTableData(document.getElementById('billNo').value);
				showTableData(document.getElementById('billNo').value);
				document.getElementById('billNo').focus();
		}
		
</script>
<script>
function calculateStockRowTotal()
{
	if(document.getElementById('billNo').value=='')
	{
		alert('Please enter Bill No.');	
		document.getElementById('billNo').focus();
		return false;
	}
	if(document.getElementById('materialID').value=='')
	{
		alert('Please Select material.');	
		document.getElementById('materialID').focus();
		return false;
	}
	if(document.getElementById('tdQuality').value=='')
	{
		alert('Please Select Quality of Product.');	
		document.getElementById('tdQuality').focus();
		return false;
	}
	if(document.getElementById('tdSize').value=='')
	{
		alert('Please Select Size of Product.');	
		document.getElementById('tdSize').focus();
		return false;
	}
	if(document.formAddStock.quantity.value=='')
	{
		alert('Please Enter Quantity of Product.');	
		document.getElementById('quantity').focus();
		return false;
	}
	if(document.formAddStock.costPrice.value=='')
	{
		alert('Please Enter Cost Price of Product.');	
		document.getElementById('costPrice').focus();
		return false;
	}
	else
	{	
		var myForm 		= document.formAddStock;
		var Quantity 			= myForm.quantity.value;
		var CostPrice			= myForm.costPrice.value;
		myForm.rowTotal.value	=parseFloat(Quantity) * parseFloat(CostPrice)
		
		InsertStockData(); // Call function to save data AJAX
	}
}
</script>

<script type="text/javascript">
   function DeleteStockRow(StockRow)
    {
		  if(confirm('Are you sure to remove this record ?'))
        	{
					 //alert(StockRow);
					 var xhttp; 
					 //var StockRow=document.getElementById('deleteStockRow').value;   
					  
					  xhttp = new XMLHttpRequest();
					  xhttp.onreadystatechange = function() 
					  {
						if (this.readyState == 4 && this.status == 200) 
						{
						  document.getElementById("divTable").innerHTML = this.responseText;
						}
					  };
					  xhttp.open("GET", "files/AjaxFeeMaterial/deleteStockRow.php?StockRowID="+StockRow, true);
					  xhttp.send();
			}
			showTableData(document.getElementById('billNo').value);
	}
</script>