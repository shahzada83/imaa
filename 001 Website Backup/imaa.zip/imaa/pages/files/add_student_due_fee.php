<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php include('files/CODEadd_student_due_fee.php'); ?>
<style>
.label_font
{
	font-size:12px;
}
#formDue
{
	display:none;
}
</style>

<form action="" method="post" name="formStudentDueFee" id="formDue">
<div class="box box-solid box-success">
	<div class="box-header">
	<?php 
	$studentName = ($studentTable['gender']=="Male")?'Mr. ':'Miss. ';
	$studentName .= ucwords(strtolower($studentTable['name']));
	?>
	  <h3 class="box-title">Due Fee payment of <?php echo $studentName; ?> </h3>
	  <div class="box-tools pull-right">
		<button class="btn btn-box-tool" data-widget=""><i class="fa fa-times" onclick="document.getElementById('formService').style.display=='none'"></i></button>
	  </div><!-- /.box-tools -->
	</div><!-- /.box-header -->
	
	<div class="box-body">
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Date</label>
					<input name="payDateService" type="text" class="form-control input-sm" id="payDateService" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="efeedate"></span>
				</div>
			</div>
		
			<div class="col-md-2">
				<div class="form-group">
					<?php
					$receiptNo = file_get_contents('receiptNo')+1;
					
					?>
					<label class="label_font">Receipt No.</label>
					<input class="form-control input-sm" type="text" name="receiptNoDue"  readonly="readonly" value="<?php echo $receiptNo; ?>" >
					<span class="error" id="ereceiptNo"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Payment Mode</label>
					<select class="form-control input-sm" name="payModeDue" id="payModeService" onChange="showPaymentModeService()">
						<option value='Cash' 		<?php if($addStudentFee['paymentMode']=='Cash')			{?> selected="selected" <?php } ?>>Cash</option>
						<option value='Cheque' 		<?php if($addStudentFee['paymentMode']=='Cheque')		{?> selected="selected" <?php } ?>>Cheque</option>
						<option value='NEFT/ RTGS' 	<?php if($addStudentFee['paymentMode']=='NEFT/ RTGS')	{?> selected="selected" <?php } ?>>NEFT/ RTGS</option>
					</select>
					<span class="error" id="epaymentMode"></span>
				</div>
			</div>	
			
			<div class="col-md-2" id="paymentModeBankService">
				<div class="form-group">
					<label class="label_font">Bank Name</label>
					<select class="form-control input-sm" type="text" name="bankNameDue" onChange="document.getElementById('egender').innerHTML ='';">
						<option value='' 		<?php if($addStudentFee['bankName']=='')			{?> selected="selected" <?php } ?>>--- SELECT BANK NAME ---</option>
						<?php
						foreach($banks as $bank) // Getting $banks value from API.php
						{
						?>
							<option value='<?php echo $bank; ?>' <?php if($addStudentFee['bankName']==$bank){?> selected="selected" <?php } ?>><?php echo $bank; ?></option>
						<?php
						}
						?>
						
					</select>
					<span class="error" id="eadmissionFee"></span>
				</div>
			</div>
			
			<div class="col-md-2" id="paymentModeChequeNoService">
				<div class="form-group">
					<label class="label_font">Cheque No./ Ref. No.</label>
					<input class="form-control input-sm" type="text" name="chequeNoDue" value="<?php echo $addStudentFee['chequeNo']; ?>"  placeholder="" onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="4">
					<span class="error" id="eIDcardFee"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group" id="paymentModeTransactionDateService">
					<label class="label_font">Cheque/ Trans. Date</label>
					<input name="ChequeDateService" type="text" class="form-control input-sm" id="ChequeDateDue" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="eChequeDate"></span>
				</div>
			</div>
			
		
		</div>
		<table class="table table-condensed">
									<tr>
									  <th style="width: 10px">SL.No</th>
									  <th>Date</th>
									  <th>Receipt No.</th>
									  <th>Fee Head</th>
									  <th>Month</th>
									  <th>Amount</th>
									  <th>Discount</th>
									  <th>Dues</th>
									  <th>Late Fine</th>
									  <th>Paid</th>
									</tr>
									<?php
									$sqlDues="SELECT studentfee.*,	`feedetail`.head
												from studentfee, feedetail
												where 
												(feedetail.feeDetailID=studentfee.feeDetailID) and studentfee.dues!=0 and studentfee.studID='$studID'";
									$statementDue=$connection->query($sqlDues);
									while($dataDue=$statementDue->fetch(PDO::FETCH_ASSOC))
									{
										++$slnoDue;
									?>
									<tr>
									  <td><?php echo $slnoDue; ?><input type="hidden" name="feeID_Studentfee[]" value="<?php echo $dataDue[feeID]; ?>" /></td>
									  <td><?php echo format_date($dataDue[payDate]); ?></td>
									  <td><?php echo $dataDue[receiptNo]; ?><input type="hidden" name="studentfee_receiptNo[]" value="<?php echo $dataDue[receiptNo]; ?>" /></td>
									  <td>
											<?php echo $ID = $dataDue[feeDetailID]; ?>
											<input type="hidden" name="studentfee_feeDetailID[]" value="<?php echo $dataDue[feeDetailID]; ?>" />
										</td>
									  <td><?php echo $dataDue[feeForMonth]; ?>
											<input type="hidden" name="studentfee_feeForMonth[]" value="<?php echo $dataDue[feeForMonth]; ?>" />
									  </td>
									  <td><?php echo $dataDue[amount]; $amountTotal += $dataDue[amount];?></td>
									  <td><?php echo $dataDue[discount]; $discount += $dataDue[discount];?></td>
									  <td style="color:#C00"><b><?php echo $dataDue[dues]; $dues += $dataDue[dues]; ?><input type="hidden" name="actualDue[]" value="<?php echo $dataDue[dues]; ?>" /></b></td>
									  <td><?php echo $dataDue[lateFine]; $lateFine += $dataDue[lateFine];?></td>
									  <td><input class="form-control input-sm" type="text" name="duePayAmount[]" value="<?php echo $dataDue[dues];?>" onfocus="calculateDuePayment();"  onkeyup="calculateDuePayment();"  onKeyPress="return isNumberKey(event)" maxlength="4" style="width:60px"></td>
									  
									</tr>
									<?php
									}
									?>
									<tr>
									  <td colspan="5" align="right"><b>TOTAL : </b></td>
									  
									  <td><b><?php echo $amountTotal;?></b></td>
									  <td><b><?php echo $discount;?></b></td>
									  <td><b><?php echo $dues; ?> <input type="hidden" name="actualDue[]" value="0" /> </b></td>
									  <td><b><?php echo $lateFine;?></b></td>
									  <td><input class="form-control input-sm" type="hidden" name="duePayAmount[]" value="0" onfocus="calculateDuePayment();"  onKeyPress="return isNumberKey(event)" maxlength="4" style="width:60px"></td>
									</tr>
								  </table>
		<!-- ***************************************************** THIS EXTRA 4 lines are of no use, this is only for the javascript function to calculateService() *-->
		<input type="hidden" name="amountService[]" />
		<input type="hidden" name="discountService[]" />
		<input type="hidden" name="duesService[]" />
		<input type="hidden" name="totalFeeService[]" />
		<!-- ******************************************************
		<!-- These two fields will be saved in the monthlyFee Table in the database -->
		<div class="row">	
			<div class="col-md-10">
				<div class="form-group">
					<label class="label_font">Remark</label>
					<input class="form-control input-sm" type="text" name="remarkDue" value=" "  placeholder="">
					<span class="error" id="eremark"></span>
				</div>
			</div>
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">NET TOTAL</label>
					<b><input class="form-control input-sm" type="text" name="totalDueReceived" id="totalDueReceived" readonly="readonly" style="background-color:#033; color:#FFF"></b>
					<span class="error" id="eremark"></span>
				</div>
			</div>
		</div>
		<!-- ******************************************************
		<!-- The above two fields will be saved in the monthlyFee Table in the database -->
		<div class="panel-footer">
				<input class="btn btn-primary" type="submit" name="add_student_due_fee" value="Save Record" onmouseover="validate();" onclick="return confirm_action('Are you sure you want to save Record? \n\n Total Received Amount is Rs. :' + document.getElementById('totalDueReceived').value)">
		</div>
	</div><!-- /.box-body -->
</div><!-- /.box -->
</form>