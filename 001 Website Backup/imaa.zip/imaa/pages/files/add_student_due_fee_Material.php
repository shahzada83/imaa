<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php 
	include('files/CODEadd_student_due_fee_material.php'); 
?>
	<style>
	.label_font
	{
		font-size:12px;
	}
	#formStudentItemDue
	{
		display:none;
	}
	</style>

<form action="" method="post" name="formStudentItemDue" id="formStudentItemDue">
<div class="box box-solid box-success">
	<div class="box-header">
	<?php 
	$studentName = ($studentTable['gender']=="Male")?'Mr. ':'Miss. ';
	$studentName .= ucwords(strtolower($studentTable['name']));
	?>
	  <h3 class="box-title">Due Fee payment of <?php echo $studentName; ?> </h3>
	  <div class="box-tools pull-right">
		<button class="btn btn-box-tool" data-widget=""><i class="fa fa-times" onclick="document.getElementById('formService').style.display=='none'"></i></button>
	  </div><!-- /.box-tools -->
	</div><!-- /.box-header -->
	
	<div class="box-body">
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Date</label>
					<input name="payDateItem" type="text" class="form-control input-sm" id="payDateItem" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="efeedate"></span>
				</div>
			</div>
			<div class="col-md-2">
				<div class="form-group">
					<?php
					$receiptNo = file_get_contents('receiptNo')+1;
					
					?>
					<label class="label_font">Receipt No.</label>
					<input class="form-control input-sm" type="text" name="receiptNoItem"  readonly="readonly" value="<?php echo $receiptNo; ?>" >
					<span class="error" id="ereceiptNo"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Payment Mode</label>
					<select class="form-control input-sm" name="payModeitem" id="payModeitem" onChange="showPaymentModeService()">
						<option value='Cash' 		<?php if($addStudentFee['paymentMode']=='Cash')			{?> selected="selected" <?php } ?>>Cash</option>
						<option value='Cheque' 		<?php if($addStudentFee['paymentMode']=='Cheque')		{?> selected="selected" <?php } ?>>Cheque</option>
						<option value='NEFT/ RTGS' 	<?php if($addStudentFee['paymentMode']=='NEFT/ RTGS')	{?> selected="selected" <?php } ?>>NEFT/ RTGS</option>
					</select>
					<span class="error" id="epaymentMode"></span>
				</div>
			</div>	
			
			<div class="col-md-2" id="paymentModeBankService">
				<div class="form-group">
					<label class="label_font">Bank Name</label>
					<select class="form-control input-sm" type="text" name="bankNameItem" onChange="document.getElementById('egender').innerHTML ='';">
						<option value='' 		<?php if($addStudentFee['bankName']=='')			{?> selected="selected" <?php } ?>>--- SELECT BANK NAME ---</option>
						<?php
						foreach($banks as $bank) // Getting $banks value from API.php
						{
						?>
							<option value='<?php echo $bank; ?>' <?php if($addStudentFee['bankName']==$bank){?> selected="selected" <?php } ?>><?php echo $bank; ?></option>
						<?php
						}
						?>
						
					</select>
					<span class="error" id="eadmissionFee"></span>
				</div>
			</div>
			
			<div class="col-md-2" id="paymentModeChequeNoService">
				<div class="form-group">
					<label class="label_font">Cheque No./ Ref. No.</label>
					<input class="form-control input-sm" type="text" name="chequeNoItem" value="<?php echo $addStudentFee['chequeNo']; ?>"  placeholder="" onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="4">
					<span class="error" id="eIDcardFee"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group" id="paymentModeTransactionDateService">
					<label class="label_font">Cheque/ Trans. Date</label>
					<input name="ChequeDateService" type="text" class="form-control input-sm" id="ChequeDateItem" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="eChequeDate"></span>
				</div>
			</div>
			
		
		</div>
		<table class="table table-condensed">
									<tr>
									  <th style="width: 10px">SL.No</th>
									  <th>Date</th>
									  <th>Receipt No.</th>
									  <th>Product</th>
									  <th>Quality</th>
									  <th>Size</th>
									  <th>Price</th>
									  <th>Discount</th>
									  <th>Dues</th>
									  
									  <th>Paid</th>
									</tr>
									<?php
									$sqlDues="SELECT studentfee.*, materialdetail.* from studentfee, materialdetail where materialdetail.materialID=studentfee.feeDetailID and studentfee.dues!=0 and studentfee.studID='$studID'";
									$statementDue=$connection->query($sqlDues);
									while($dataDue=$statementDue->fetch(PDO::FETCH_ASSOC))
									{
										++$slnoDue;
									?>
									<tr>
									  <td><?php echo $slnoDue; ?><input type="hidden" name="oldFeeID[]" value="<?php echo $dataDue[feeID]; ?>" /></td>
									  <td><?php echo format_date($dataDue[payDate]); ?></td>
									  <td><?php echo $dataDue[receiptNo]; ?><input type="hidden" name="oldReceiptNo[]" value="<?php echo $dataDue[receiptNo]; ?>" /></td>
									  <td><?php echo $dataDue[itemName]; ?><input type="hidden" name="oldItemName[]" value="<?php echo $dataDue[itemName]; ?>" /></td>
									  <td><?php echo $dataDue[quality]; ?><input type="hidden" name="oldQuality[]" value="<?php echo $dataDue[quality]; ?>" /></td>
									  <td><?php echo $dataDue[size];?><input type="hidden" name="oldSize[]" value="<?php echo $dataDue[size]; ?>" /></td>
									   <td><?php echo $dataDue[amount]; $amountTotal += $dataDue[amount];?><input type="hidden" name="oldAmount[]" value="<?php echo $dataDue[amount]; ?>" /></td>
									  <td><?php echo $dataDue[discount]; $discount += $dataDue[discount];?></td>
									  <td style="color:#C00"><b><?php echo $dataDue[dues]; $dues += $dataDue[dues]; ?>
									  	<input type="hidden" name="oldDues[]" value="<?php echo $dataDue[dues]; ?>" /></b>
									  </td>
									  
									  <td><input class="form-control input-sm" type="text" name="NewPaid[]" value="<?php echo $dataDue[dues];?>" onFocus="calculateDuePaymentItem();"  onKeyPress="return isNumberKey(event)" maxlength="4" style="width:60px"></td>
									  <td>
										<input type="hidden" name="feeDetailIDitem[]" class="flat-green" value="<?php echo $dataDue[feeDetailID]; ?>" />
									  </td>
									</tr>
									<?php
									}
									?>
									<tr>
									  <td colspan="6" align="right"><b>TOTAL : </b></td>
									  <td><b><?php echo $amountTotal;?></b></td>
									  <td><b><?php echo $discount;?></b></td>
									  <td colspan="2"><b><?php echo $dues; ?></td>
									</tr>
								  </table>
		<!-- ***************************************************** THIS EXTRA 4 lines are of no use, this is only for the javascript function to calculateService() *-->
		<input type="hidden" name="oldDues[]" value="0" />
		<input type="hidden" name="NewPaid[]" value="0" />
		
		<!-- ******************************************************
		<!-- These two fields will be saved in the monthlyFee Table in the database -->
		<div class="row">	
			<div class="col-md-10">
				<div class="form-group">
					<label class="label_font">Remark</label>
					<input class="form-control input-sm" type="text" name="remarkItem" value=" "  placeholder="">
					<span class="error" id="eremark"></span>
				</div>
			</div>
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">NET TOTAL</label>
					<b><input class="form-control input-sm" type="text" name="totalReceivedItem" id="totalReceivedItem2" readonly="readonly" style="background-color:#033; color:#FFF"></b>
					<span class="error" id="eremark"></span>
				</div>
			</div>
		</div>
		<!-- ******************************************************
		<!-- The above two fields will be saved in the monthlyFee Table in the database -->
		<div class="panel-footer">
				<input class="btn btn-primary" type="submit" name="add_student_due_fee_item" value="Save Record" onmouseover="validate();" onclick="return confirm_action('Are you sure you want to save Record? \n\n Total Received Amount is Rs. :' + document.getElementById('totalReceivedItem2').value)">
		</div>
	</div><!-- /.box-body -->
</div><!-- /.box -->
</form>