<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php include('files/CODEadd_student_fee_service.php'); ?>
<style>
.label_font
{
	font-size:12px;
}
#formService
{
	display:none;
}
</style>

<form action="" method="post" name="formStudentFeeService" id="formService">
<div class="box box-solid box-danger">
	<div class="box-header">
	<?php 
	$studentName = ($studentTable['gender']=="Male")?'Mr. ':'Miss. ';
	$studentName .= ucwords(strtolower($studentTable['name']));
	?>
	  <h3 class="box-title">Add Admission/ Monthly Fee Details of <?php echo $studentName; ?> </h3>
	  <div class="box-tools pull-right">
		<button class="btn btn-box-tool" data-widget=""><i class="fa fa-times" onclick="document.getElementById('formService').style.display=='none'"></i></button>
	  </div><!-- /.box-tools -->
	</div><!-- /.box-header -->
	
	<div class="box-body">
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Date</label>
					<input name="payDateService" type="text" class="form-control input-sm" id="payDateService" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="efeedate"></span>
				</div>
			</div>
		
			<div class="col-md-2">
				<div class="form-group">
					<?php
					$receiptNo = file_get_contents('receiptNo')+1;
					
					?>
					<label class="label_font">Receipt No.</label>
					<input class="form-control input-sm" type="text" name="receiptNoService" readonly="readonly" value="<?php echo $receiptNo; ?>" >
					<span class="error" id="ereceiptNo"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Payment Mode</label>
					<select class="form-control input-sm" name="payModeService" id="payModeService" onChange="showPaymentModeService()">
						<option value='Cash' 		<?php if($addStudentFee['paymentMode']=='Cash')			{?> selected="selected" <?php } ?>>Cash</option>
						<option value='Cheque' 		<?php if($addStudentFee['paymentMode']=='Cheque')		{?> selected="selected" <?php } ?>>Cheque</option>
						<option value='NEFT/ RTGS' 	<?php if($addStudentFee['paymentMode']=='NEFT/ RTGS')	{?> selected="selected" <?php } ?>>NEFT/ RTGS</option>
					</select>
					<span class="error" id="epaymentMode"></span>
				</div>
			</div>	
			
			<div class="col-md-2" id="paymentModeBankService">
				<div class="form-group">
					<label class="label_font">Bank Name</label>
					<select class="form-control input-sm" type="text" name="bankNameService" onChange="document.getElementById('egender').innerHTML ='';">
						<option value='' 		<?php if($addStudentFee['bankName']=='')			{?> selected="selected" <?php } ?>>--- SELECT BANK NAME ---</option>
						<?php
						foreach($banks as $bank) // Getting $banks value from API.php
						{
						?>
							<option value='<?php echo $bank; ?>' <?php if($addStudentFee['bankName']==$bank){?> selected="selected" <?php } ?>><?php echo $bank; ?></option>
						<?php
						}
						?>
						
					</select>
					<span class="error" id="eadmissionFee"></span>
				</div>
			</div>
			
			<div class="col-md-2" id="paymentModeChequeNoService">
				<div class="form-group">
					<label class="label_font">Cheque No./ Ref. No.</label>
					<input class="form-control input-sm" type="text" name="chequeNoService" value="<?php echo $addStudentFee['chequeNo']; ?>"  placeholder="" onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="4">
					<span class="error" id="eIDcardFee"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group" id="paymentModeTransactionDateService">
					<label class="label_font">Cheque/ Trans. Date</label>
					<input name="ChequeDateService" type="text" class="form-control input-sm" id="ChequeDateService" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo date("d/m/Y"); ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					<span class="error" id="eChequeDate"></span>
				</div>
			</div>
			
		
		</div>
		<?php
		// ************************************************** LOOP BEGINS **************************************************
		// Show all those Fee Head whose payment has not been paid by the student
		$sqlfeeDetail="SELECT `feeDetailID`, `head`, amount FROM `feedetail` FD WHERE NOT EXISTS (SELECT  `feeDetailID`, `feeForMonth`  FROM `studentfee` SF WHERE FD.`feeDetailID` = SF.`feeDetailID` AND SF.`studID`='$studID' ORDER BY SF.`feeID` DESC) AND `FD`.`type`='Service' AND FD.`feeDetailID` !=9";
		
		$statementFeeDetail=$connection->query($sqlfeeDetail);
		$statementFeeDetail->execute();
	
		while($fieldFeeDetail=$statementFeeDetail->fetch(PDO::FETCH_ASSOC))
		{
		?>
			
		
		<div class="row">
			<div class="col-md-2">
				<div class="form-group">
					<br />
						<!-- Control to hold feeDetailID -->
						<input class="form-control input-sm" type="hidden" name="feeDetailIDService[]" value="<?php echo $fieldFeeDetail[feeDetailID]; ?>">
						<input class="form-control input-sm" type="hidden" name="feeHeadService[]" value="<?php echo $fieldFeeDetail[head]; ?>">
						
						<h5 style="color:#000"><pre class="small" style="background:#000; color:#FFF"><input type="checkbox" class="minimal-red" name="checkHeadService[]" value="1"/>  <?php echo $fieldFeeDetail[head]; ?></pre></h5>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
						<label class="label_font">(<i class="fa fa-rupee"></i>) Amount </label>
						<select class="form-control input-sm" name="amountService[]">
						<?php
						$amt=explode(",",$fieldFeeDetail[amount]);
						foreach($amt as $amount)
						{
						?>
							<option><?php echo $amount; ?></option>
						<?php
						}
						?>	
						</select>
						
						
				</div>
			</div>
			
			
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">(<i class="fa fa-rupee"></i>) Discount </label>
					<input class="form-control input-sm" type="text" name="discountService[]" value="" onkeyup="calculateService();"  onKeyPress="return isNumberKey(event)" maxlength="6">
					<span class="error" id="ediscount"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font" style="color:#C00">(<i class="fa fa-rupee"></i>) Due's </label>
					<input class="form-control input-sm" type="text" name="duesService[]" onkeyup="calculateService();"  onKeyPress="return isNumberKey(event)" maxlength="6" style="background-color:#FC9; color:#000; font-weight:600;">
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">(<i class="fa fa-rupee"></i>) Total Fee Received </label>
					<input class="form-control input-sm" type="text" name="totalFeeService[]"  readonly="readonly">TotalMonthlyFee
					<span class="error" id="etotalFee"></span>
				</div>
			</div>
			<?php
			// If row is for Admission Fee then show Roll No
			if($fieldFeeDetail[feeDetailID]==16)
			{
			?>
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Avl. Roll No </label>
					
					<select class="form-control input-sm" >
					<option></option>
					<?php
					$batch=$studentTable['batchPreferene'];
					$sqlRollNo="select rollNo from student where batchPreferene='$batch' and deleted=0 and dropout=0 ORDER By rollNo";
					$stmtRollNo=$connection->query($sqlRollNo);
					$rollNoCheck = 1;
					while($dataRollNo = $stmtRollNo->fetch(PDO::FETCH_ASSOC))
					{
						if( !in_array($rollNoCheck, $dataRollNo))
						{
					?>
						<option><?php echo $rollNoCheck; ?></option>
					<?php
							break;
						}
					$rollNoCheck++;
					}
					?>
					</select>		
					<span class="error" id="etotalFee"></span>
				</div>
			</div>
			<?php
			}
			?>
			
		</div>
		<?php
		}
		include('files/monthly_fee.php');
		?>	
		<!-- ***************************************************** THIS EXTRA 4 lines are of no use, this is only for the javascript function to calculateService() *-->
		<input type="hidden" name="amountService[]" />
		<input type="hidden" name="discountService[]" />
		<input type="hidden" name="duesService[]" />
		<input type="hidden" name="totalFeeService[]" />
		<!-- ******************************************************
		<!-- These two fields will be saved in the monthlyFee Table in the database -->
		<div class="row">	
			<div class="col-md-10">
				<div class="form-group">
					<label class="label_font">Remark</label>
					<input class="form-control input-sm" type="text" name="remarkService" value="<?php echo $addStudentFee['remark']; ?>"  placeholder="">
					<span class="error" id="eremark"></span>
				</div>
			</div>
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">NET TOTAL</label>
					<input class="form-control input-sm" type="text" name="totalReceivedService" id="totalReceivedService" readonly="readonly" style="background-color:#033; color:#FFF">
					<span class="error" id="eremark"></span>
				</div>
			</div>
		</div>
		<!-- ******************************************************
		<!-- The above two fields will be saved in the monthlyFee Table in the database -->
		<div class="panel-footer">
				<input class="btn btn-primary" type="submit" name="add_studentFeeService" value="Save Record" onmouseover="validate();" onclick="return confirm_action('Are you sure you want to save Record? \n\n Total Received Amount is Rs. :' + document.getElementById('totalReceivedService').value)">
		</div>
	</div><!-- /.box-body -->
</div><!-- /.box -->
</form>