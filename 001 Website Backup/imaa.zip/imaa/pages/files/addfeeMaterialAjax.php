
<?php 

$payDate=date("d/m/Y");
$receiptNo = file_get_contents('receiptNo')+1;
?>


<span  id="show_msg"></span>
				

<form action="" method="post" name="formAddMaterialFee">

<input type="hidden" name="studID" id="studID" value="<?php echo $studID; ?>" />
<input type="hidden" name="payDate" id="payDate" value="<?php echo $payDate; ?>" />
<input type="hidden" name="receiptNo" id="receiptNo" value="<?php echo $receiptNo; ?>" />

<div class="box box-solid box-primary">
	
	<div class="box-body">
	
		
	<table class="table table-bordered">
                    <tr class="danger"  onmouseover="showTableData(document.getElementById('studID').value)">
					  <th>Product</th>	
                      <th style="width: 10px">Quality</th>
                      <th>Size</th>
					  
                      <th>Price</th>
                      <th style="width: 40px">Discount</th>
					  <!--<th>Sale Price</th>-->
					  <th>Due</th>
					  <th>Total Fee<br /> To Collect</th>
					  <th></th>
                    </tr>
		<!----------------------------------------------------------------------------------------------------------------------------------------->
		
		<tr class="danger"  onmouseover="showTableData(document.getElementById('studID').value)">
			<td>
				<select name="materialID" id="materialID" class="form-control input-sm" onchange="getQuality(this.value)">
					<option value=""></option>
				<?php
				$sqlMaterialID="select distinct(itemName) as itemName from materialdetail";
				$stmtMaterialID=$connection->query($sqlMaterialID);
				while($dataMaterialDetail=$stmtMaterialID->fetch(PDO::FETCH_ASSOC))
				{
				?>
					<option><?php echo $dataMaterialDetail[itemName];?></option>
				<?php
				}
				?>
				</select>
			</td>
			
			<td class="">
				<select id="tdQuality" class='form-control input-sm' name="quality" onchange="getSize(this.value)">
				
				</select>
			</td>
			<td>
				<select id="tdSize" class='form-control input-sm' name='size'  onchange="getSellingPrice(this.value)">
			
				</select>
			</td>
			
				
			
			<td>
				<input class="form-control input-sm no-border" type="text" name="price" id="price"  placeholder="Price" readonly="readonly" style="font-size:14; font-weight:bold; color:#090">
			</td>
			
			<td>
				<input class="form-control input-sm no-border" type="text" name="discount" id="discount"  placeholder="Discount Amount"  onKeyPress="return isNumberKey(event)" maxlength="5" onkeyup="calculateRowTotal();">
			</td>
			<!--
			<td>
				<input class="form-control input-sm no-border" type="text" name="salePrice[]" value=""  placeholder="Sale Price"  onKeyUp="calculateStockRowTotal();"  onKeyPress="return isNumberKey(event)" maxlength="5">
			</td>
			-->
			<td>
				<input class="form-control input-sm no-border" type="text" name="due" id="due"  placeholder="Due Amount" onKeyPress="return isNumberKey(event)" maxlength="5" onkeyup="calculateRowTotal();"+
				>
			</td>
			
			<td>
				<input class="form-control input-sm no-border" type="text" name="rowTotal" id="rowTotal" readonly="readonly" onblur="calculateRowTotal();">
			</td>
			
			<td>
				<a href="#" id="addStock" class="form-control input-sm btn-info" onclick="ValidateAndInsert()"><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp; Add Product</a>
			</td>
		
		</tr>
		<tr>
			<td colspan="8"></td>
		</tr>
		
			<tr>
				<table id="divTable" class="table table-bordered table-striped table-responsive">
		
				</table>
			</tr>	
	
		<!----------------------------------------------------------------------------------------------------------------------------------------->
		</table>
		
		
	</div><!-- /.box-body -->
	
		
		
</div><!-- /.box -->
</form>

<script src="files/AjaxFeeMaterial/js/jquery-3.2.1.js" type="text/javascript"></script>

<script>
function calculateRowTotal()
{
		var price 		=  parseFloat(document.getElementById('price').value);
		var discount 	=  parseFloat(document.getElementById('discount').value);
		var due 		=  parseFloat(document.getElementById('due').value);
		var rowTotal 	=  (price - discount) - due;
		document.getElementById('rowTotal').value = rowTotal;
}


function showTableData(studID) {
	//alert(item);
  var xhttp;    
 
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("divTable").innerHTML = this.responseText;
	  //document.getElementById("divTableAddStudentFeeMaterial").innerHTML = this.responseText;
    }
  };
  //alert("files/AjaxFeeMaterial/viewtemp_MaterialFee.php?studID="+<?php echo $studID; ?>);
  xhttp.open("GET", "files/AjaxFeeMaterial/viewtemp_MaterialFee.php?studID="+studID, true);
  xhttp.send();
}
</script>

<script>
function getQuality(item) {
	//alert(item);
  var xhttp;    
  if (item == "") {
    document.getElementById("tdQuality").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("tdQuality").innerHTML = this.responseText;
    }
  };
  //alert("files/AjaxFeeMaterial/getQuality.php?itm="+item);
  xhttp.open("GET", "files/AjaxFeeMaterial/getQuality.php?itm="+item, true);
  xhttp.send();
}
</script>

<script>
function getSize(qty) {
	//alert(qty);
  var xhttp; 
  var materialID=document.getElementById('materialID').value;   
  if (qty == "") {
    document.getElementById("tdSize").innerHTML = "";
    return;
  }
  if (materialID == "") {
    document.getElementById("tdSize").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("tdSize").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "files/AjaxFeeMaterial/getSize.php?itm="+materialID+"&qty="+qty, true);
  xhttp.send();
}
</script>

<script>
function getSellingPrice(item) {
 
  
 //alert(document.getElementById('tdQuality').value);
 
  var materialName	=	document.getElementById('materialID').value; 
  var quality		=	document.getElementById('tdQuality').value; 

  var xhttp;   
  
  if (materialName == "") {
   document.getElementById("price").value = "";
    return;
  }
  
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     	document.getElementById("price").value = this.responseText;
    }
  };
  //alert("files/AjaxFeeMaterial/getSellingPrice.php?itm="+materialName+"&quality="+quality+"&size="+item);
  
  xhttp.open("GET", "files/AjaxFeeMaterial/getSellingPrice.php?itm="+materialName+"&quality="+quality+"&size="+item, true);
  xhttp.send();
}
</script>

<script type="text/javascript">
	
		function Insert_tempMaterialFee()
		{
			event.preventDefault();
				$.ajax({
				url: "files/AjaxFeeMaterial/CodeAdd_tempMaterialFee.php",
				method: "post",
				data: $('form').serialize(),
				dataType: "text",
					success: function (strDate)
					{
						$('#show_msg').html(strDate)
					}
				})
				
				showTableData(document.getElementById('studID').value);
		}
		
</script>
<script>
function ValidateAndInsert()
{
	
	if(document.getElementById('materialID').value=='')
	{
		alert('Please Select Product.');	
		document.getElementById('materialID').focus();
		return false;
	}
	if(document.getElementById('tdQuality').value=='')
	{
		alert('Please Select Quality of Product.');	
		document.getElementById('tdQuality').focus();
		return false;
	}
	if(document.getElementById('tdSize').value=='')
	{
		alert('Please Select Size of Product.');	
		document.getElementById('tdSize').focus();
		return false;
	}
	else
	{	
		Insert_tempMaterialFee(); // Call function to save data AJAX
	}
}
</script>

<script type="text/javascript">
   function DeleteMaterialRow(materialID)
    {
		  if(confirm('Are you sure to remove this record ?'))
        	{
					 //alert(materialID);
					 var xhttp; 
					 //var StockRow=document.getElementById('deleteStockRow').value;   
					  
					  xhttp = new XMLHttpRequest();
					  xhttp.onreadystatechange = function() 
					  {
						if (this.readyState == 4 && this.status == 200) 
						{
						  document.getElementById("divTable").innerHTML = this.responseText;
						}
					  };
					  xhttp.open("GET", "files/AjaxFeeMaterial/deleteMaterialID.php?materialID="+materialID, true);
					  
					  xhttp.send();
					 
			}
			showTableData(document.getElementById('billNo').value);
	}
</script>