<?php
include('../dbconn.php');

$products=array(
		'Karate Dress',
		'Track Suit',
		'Karate Kit',
		'Gloves',
		'Shin Guard',
		'Body Armour',
		'Head Gear',
		'Karate Belt'
);

$quality=array(
				'High',
				'Medium',
				'Low'
			);

foreach($products as $prod)
{
		foreach($quality as $qty)
		{
			for($size=26; $size<=44; $size++)
			{
				$sql="INSERT INTO `materialdetail` (`itemName`, `size`, `quality`)
											VALUES ('$prod', '$size', '$qty')";
				$connection->query($sql);							
			}	
		}
		
}
?>