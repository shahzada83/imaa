<?php
if(isset($_POST['createBatch']))
{

  $studentBatch=array_map('htmlspecialchars',$_POST);
  $studentBatch=array_map('trim',$studentBatch);
  $studentBatch=array_map('addslashes',$studentBatch);
  //echo "<pre>";
  //print_r($studentBatch);
  
  validateStudentBatchFunction($studentBatch);
}


function validateStudentBatchFunction($studentBatch)
{
    if($studentBatch[batchNo]=='')
	{
		echo "<script>alert('Batch Name can not be Blank.')</script>";
	}
	elseif($studentBatch[preference]=='')
	{
		echo "<script>alert('Batch preference can not be None. Please select one.')</script>";
	}
	elseif(strtotime($studentBatch[batchStartTime]) == strtotime($studentBatch[batchEndTime]))
	{
		echo "<script>alert('Batch Start and End Time can not be same.')</script>";
	}
	elseif(strtotime($studentBatch[batchStartTime]) > strtotime($studentBatch[batchEndTime]))
	{
		echo "<script>alert('Batch Start Time can not be greated than the End Time can not be same.')</script>";
	}
    elseif($studentBatch[day]=='')
	{
		echo "<script>alert('Batch Day can not be None.')</script>";
	}
    elseif($studentBatch[trainerName]=='')
	{
		echo "<script>alert('Please select Trainer Name.')</script>";
	}
	else
	{
		InsertDataInStudentBatch_TableFunction($studentBatch);
	}
}

function InsertDataInStudentBatch_TableFunction($studentBatch)
{
	include('files/dbconn.php');
	
	$sqlInsertBatchStudent="INSERT INTO `studentbatch` (`batchNo`,`preference`, `time`, `day`, `studID`, `startDate`, `duration`, `createdOn`, `createdBy`) 
							  VALUES (:batchNo, :preference, :time, :day, :studID, :startDate, :duration, :createdOn, :createdBy)";
							  
							 /*
							 Array
								(
									[preference] => Morning
									[batchStartTime] => 07:00 PM
									[batchEndTime] => 08:00 PM
									[day] => Monday
									[trainerName] => 10
									[startDate] => 
									[createBatch] => 
								)
							 */
							 
							  $batchNo		=	$studentBatch[batchNo]; 
							  $preference	=	$studentBatch[preference]; 
							  $time			=	$studentBatch[batchStartTime] . " - " . $studentBatch[batchEndTime];
							  $day			=	$studentBatch[day];
							  $studID		=	$studentBatch[trainerName]; 
							  $startDate	=	short_date($studentBatch[startDate]);
							  $duration		=	"3 - Years";
							  $createdOn	=	mktime();
							  $createdBy	=	$_SESSION['userID'];
							  
	$insertBatchStudent	= $connection -> prepare($sqlInsertBatchStudent);
	
	$insertBatchStudent -> bindParam(":batchNo", 		$batchNo);
	$insertBatchStudent -> bindParam(":preference", 	$preference);
	$insertBatchStudent -> bindParam(":time", 			$time);
	$insertBatchStudent -> bindParam(":day", 			$day);
	$insertBatchStudent -> bindParam(":studID", 		$studID);
	$insertBatchStudent -> bindParam(":startDate", 		$startDate);
	$insertBatchStudent -> bindParam(":duration", 		$duration);
	$insertBatchStudent -> bindParam(":createdOn", 		$createdOn);
	$insertBatchStudent -> bindParam(":createdBy", 		$createdBy);
	
	if($insertBatchStudent -> execute())
	{
		echo "<script>alert('Batch Timing Updated Successfully.')</script>";
		echo "<script>document.location.href='main.php?pg=create/ modify batch'</script>";
	}						  
}
?>