<?php
if(isset($_POST['createHead']))
{	
  $addMaterialDetail=array_map('htmlspecialchars',$_POST);
  $addMaterialDetail=array_map('trim',$addMaterialDetail);
  $addMaterialDetail=array_map('addslashes',$addMaterialDetail);
  //echo "<pre>";
  //print_r($addStudent);
  
  validateAddaddMaterialDetailFunction($addMaterialDetail);
}

//Function to validate for data 
function validateAddaddMaterialDetailFunction($addMaterialDetail)
{
	if($addMaterialDetail[itemName]=='')
	{
		 echo "<script>alert('Please Enter Item Name.')</script>";
	}
	elseif($addMaterialDetail[size]=='')
	{
		 echo "<script>alert('Please Specify Product Size.')</script>";
	}
	elseif($addMaterialDetail[quality]=='')
	{
		 echo "<script>alert('Please Specify Product Quality.')</script>";
	}
	elseif($addMaterialDetail[sellingPrice]=='')
	{
		 echo "<script>alert('Please Enter Selling Price.')</script>";
	}
	else
	{
		insertFeeDetailFunction($addMaterialDetail);	
	}
}

//Function to insert data in FeeDetail Table
function insertFeeDetailFunction($addMaterialDetail)
{
	include('files/dbconn.php');
	$sqlProductDetail="INSERT INTO `materialdetail` (`itemName`, `size`, `quality`, `sellingPrice`) 
											VALUES (:itemName, :size, :quality, :sellingPrice)
											on duplicate key update
       												 		`itemName`		= :itemName,
															`size`			= :size	,
															`quality`		= :quality,	
															`sellingPrice`	= :sellingPrice
											";
	
	//$sqlFeeDetail="INSERT INTO `feeDetail` (`head`, `amount`, `createdBy`, `createdOn`)
	//	VALUES (:head, :amount, :createdBy, :createdOn)	
	// 	WHERE NOT EXISTS (SELECT name FROM `feeDetail` WHERE `head`=':head' and active=:active)";
	
	$statementProductDetail= $connection -> prepare($sqlProductDetail);
	
	//$active=0;
	//$statementProductDetail->bindParam(":active", 		$active);
	
	$statementProductDetail->bindParam(":itemName", 	$addMaterialDetail[itemName]);
	$statementProductDetail->bindParam(":size", 		$addMaterialDetail[size]);
	$statementProductDetail->bindParam(":quality", 		$addMaterialDetail[quality]);
	$statementProductDetail->bindParam(":sellingPrice", $addMaterialDetail[sellingPrice]);
	
	if($statementProductDetail->execute())
	{
		 echo "<script>alert('Product Updated successfully.')</script>";
		 echo "<script>document.location.href='main.php?pg=add product';</script>";
	}
	
		
}
?>
<div class="box box-solid box-primary">
		<div class="box-header">
		  <h3 class="box-title">Add Product</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		<form action="" method="post" name="formHead">
		<div class="row">
			
			
			<div class="col-lg-2">
				<label class="small"> * Product Name</label>
				<select name="itemName" class="form-control input-sm" >
					<option>Karate Dress</option>
					<option>Track Suit</option>
					<option>Karate Kit</option>
					<option>Gloves</option>
					<option>Shin Guard</option>
					<option>Body Armour</option>
					<option>Head Gear</option>
					<option>Karate Belt</option>
				</select>
				<span class="error" id="eheadname"></span>
			</div>
			
			<div class="col-lg-2">
				<label class="small"> Quality/ Size</label>
				<select name="quality" class="form-control input-sm">
					<option value="" <?php if($addMaterialDetail['quality']==""){?> selected="selected" <?php } ?>></option>
					<option value="General" <?php if($addMaterialDetail['quality']=="General"){?> selected="selected" <?php } ?> disabled>----------SIZE-------------</option>
					<option value="SIZE - SMALL" <?php if($addMaterialDetail['quality']=="SIZE - SMALL"){?> selected="selected" <?php } ?>>SMALL</option>
					<option value="SIZE - MEDIUM" <?php if($addMaterialDetail['quality']=="SIZE - MEDIUM"){?> selected="selected" <?php } ?>>MEDIUM</option>
					<option value="SIZE - LARGE" <?php if($addMaterialDetail['quality']=="SIZE - LARGE"){?> selected="selected" <?php } ?>>LARGE</option>
					
					
					<option value="General" <?php if($addMaterialDetail['quality']=="General"){?> selected="selected" <?php } ?> disabled>----------QUALITY----------</option>
					<option value="High" <?php if($addMaterialDetail['quality']=="High"){?> selected="selected" <?php } ?>>High</option>
					<option value="Medium" <?php if($addMaterialDetail['quality']=="Medium"){?> selected="selected" <?php } ?>>Medium</option>
					<option value="Low" <?php if($addMaterialDetail['quality']=="Low"){?> selected="selected" <?php } ?>>Low</option>
				</select>
				<span class="error" id="eheadname"></span>
			</div>
			
			<div class="col-lg-2">
				<label class="small"> Size "</label>
				<select name="size" class="form-control input-sm">
				<option value="" <?php if($addMaterialDetail['size']==""){?> selected="selected" <?php } ?>>Select Size</option>
				<option value="Free" <?php if($addMaterialDetail['size']=="Free"){?> selected="selected" <?php } ?>>Free Size</option>
				<?php
				for($size=24; $size <= 44; $size +=2 )
				{
				?>
					<option value="<?php echo $size; ?>" <?php if($addMaterialDetail['size']==$size){?> selected="selected" <?php } ?>><?php echo $size; ?></option>
				<?php
				}
				?>	
				</select>
				<span class="error" id="eheadname"></span>
			</div>
			
			
			
			<div class="col-lg-2">
				<div class="form-group">
					<label class="small">Selling Price (<i class="fa fa-inr"></i>)</label>
					<input class="form-control input-sm" type="text" name="sellingPrice" value="<?php echo $addMaterialDetail['sellingPrice']; ?>"  placeholder="Selling Price" onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="5">
					<span class="error" id="eFormNo"></span>
				</div>	
			</div>		
			
			<div class="col-lg-2">
				<div class="form-group">
					<br>
					<label   class="control-label" for="exampleInputFile"></label>
					<button type="submit" name="createHead" class="btn btn-primary">Add Product</button>
				</div>
			</div>
		</div>	
		</form>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->
	  
	  	<?php 
	  
	  		// code to view the feeDetail Data 
	  		include('files/admin/view_MaterialDetail.php');
		?>