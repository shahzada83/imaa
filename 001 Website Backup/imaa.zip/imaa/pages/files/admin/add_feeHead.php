<?php
if(isset($_POST['createHead']))
{	
  $addFeeDetail=array_map('htmlspecialchars',$_POST);
  $addFeeDetail=array_map('trim',$addFeeDetail);
  $addFeeDetail=array_map('addslashes',$addFeeDetail);
  //echo "<pre>";
  //print_r($addStudent);
  
  validateAddaddFeeDetailFunction($addFeeDetail);
}

//Function to validate for data 
function validateAddaddFeeDetailFunction($addFeeDetail)
{
	if($addFeeDetail[head]=='')
	{
		 echo "<script>alert('Please Enter Fee Head Name.')</script>";
	}
	elseif($addFeeDetail[amount]=='')
	{
		 echo "<script>alert('Please Enter Amount against - Fee Head Name.')</script>";
	}
	else
	{
		insertFeeDetailFunction($addFeeDetail);	
	}
}

//Function to insert data in FeeDetail Table
function insertFeeDetailFunction($addFeeDetail)
{
	include('files/dbconn.php');
	$sqlFeeDetail="INSERT INTO `feeDetail`(`type`, `head`, `amount`, `createdBy`, `createdOn`) VALUES (:type, :head, :amount, :createdBy, :createdOn)";
	
	//$sqlFeeDetail="INSERT INTO `feeDetail` (`head`, `amount`, `createdBy`, `createdOn`)
	//	VALUES (:head, :amount, :createdBy, :createdOn)	
	// 	WHERE NOT EXISTS (SELECT name FROM `feeDetail` WHERE `head`=':head' and active=:active)";
	
	$statementFeeDetail= $connection -> prepare($sqlFeeDetail);
	
	//$active=0;
	//$statementFeeDetail->bindParam(":active", 		$active);
	
	$statementFeeDetail->bindParam(":type", 		$addFeeDetail[type]);
	$statementFeeDetail->bindParam(":head", 		$addFeeDetail[head]);
	$statementFeeDetail->bindParam(":amount", 		$addFeeDetail[amount]);

	$createdBy=$_SESSION[userID];
	$statementFeeDetail->bindParam(":createdBy",	$createdBy);
	
	$createdOn=mktime();
	$statementFeeDetail->bindParam(":createdOn", 	$createdOn);
	
	if($statementFeeDetail->execute())
	{
		 echo "<script>alert('Fee Head Created successully.')</script>";
		 echo "<script>document.location.href='main.php?pg=add fee head';</script>";
	}
	
		
}
?>
<div class="box box-solid box-primary">
		<div class="box-header">
		  <h3 class="box-title">Update Fee Structure</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		<form action="" method="post" name="formHead">
		<div class="row">
			<div class="col-lg-3">
				<label class="small"> Head Type</label>
				<select name="type" class="form-control input-sm">
					<option value="Service" <?php if($addFeeDetail['head']=="Service"){?> selected="selected" <?php } ?>>Service</option>
				</select>
				<span class="error" id="eheadname"></span>
			</div>
			
			<div class="col-lg-3">
				<label class="small"> * Fee Head Name</label>
				<input name="head" class="form-control input-sm"  value="<?php echo $addFeeDetail['head']; ?>" list="head"  placeholder="Enter Fee Head">
				<datalist id="head">
					<option>Admission Fee</option>
					<option>Monthly Fee</option>
					<option>ID Card</option>
					<option>Form</option>
					<option>Track Suit</option>
					<option>Karate Dress</option>
					<option>Examination</option>
					<option>Championship</option>
					<option>Late Fine</option>
				</datalist>
				<span class="error" id="eheadname"></span>
			</div>
			
			<div class="col-lg-3">
				<div class="form-group">
					<label class="small">* Amount (<i class="fa fa-inr"></i>)</label>
					<input class="form-control input-sm" type="text" name="amount" value="<?php echo $addStudent['formNo']; ?>"  placeholder="Amount" onkeyup="document.getElementById('eFormNo').innerHTML ='';" onKeyPress="return isNumberKey(event)" maxlength="4">
					<span class="error" id="eFormNo"></span>
				</div>	
			</div>		
			
			<div class="col-lg-3">
				<div class="form-group">
					<br>
					<label   class="control-label" for="exampleInputFile"></label>
					<button type="submit" name="createHead" class="btn btn-primary">Update Fee Head</button>
				</div>
			</div>
		</div>	
		</form>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->
	  
	  	<?php 
	  
	  		// code to view the feeDetail Data 
	  		include('files/admin/view_feeDetail.php');
		?>