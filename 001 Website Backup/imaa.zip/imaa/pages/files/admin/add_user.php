<?php

if(isset($_REQUEST['submit']))
{
		//slno
		 $usertype=$_REQUEST['usertype'];
		 $username=$_REQUEST['username'];
		 $password=md5($_REQUEST['password']);
		 $name=ucwords(strtolower($_REQUEST['name']));
		 $mobile1=$_REQUEST['mobile1'];
		 $mobile2=$_REQUEST['mobile2'];
		 $email=$_REQUEST['email'];
		 		// Change the format of Date---------------------------------------
				$DOB=$_REQUEST['dob'];
		 		$DOB_DATE=explode('/', $DOB);
				$dob=$DOB_DATE[2] ."-". $DOB_DATE[1] ."-". $DOB_DATE[0];
		 		//-----------------------------------------------------------------
		 $designation=$_REQUEST['designation'];
		 $active=$_REQUEST['active'];
		 $created_by=$_SESSION['sessionUserName'];// From Session
		 $time=mktime();
		 
		 
		 
		// CODE TO UPLOAD FILE---------------------------------------------------------------------
		//print_r($_FILES['file_photo']);
		$file_size=$_FILES['file_photo']['size'];
		
		$file_name=$_FILES['file_photo']['name'];
		
		$file_ext=strtolower(end(explode('.', $file_name)));
		
		$file_source=$_FILES['file_photo']['tmp_name'];
		
		$file_new_name=mktime(). "." . $file_ext;
		
		$file_destination='001_student_photo/' . $file_new_name ;
		
		$allowed_file_size=1048576;
		
		$allowed_file_extension=array('jpg');
		//set hidden field "validate" to 1 that could be checked from PHP code before SAVING RECORD
		if(empty($_FILES['file_photo']))
		 {
		 	array_push($error,"Please select Photograph of the user.");
		 }
		// Code to check Image 
		elseif($_FILES['file_photo']['name']==1)
		{
			array_push($error,"Please select another image of the user.");
		}
		elseif(!in_array('jpg', $allowed_file_extension))
		{
			array_push($error,"Please select only .jpg format image.");
		}
		elseif($file_size > $allowed_file_size)
		{
			array_push($error,"Image file size should not be more than 1 MB");
		}
		else
		{
				if(move_uploaded_file($file_source, $file_destination))
				{
					$image=$file_new_name;
				}	
		// CODE TO UPLOAD FILE END---------------------------------------------------------------------
		 //-----------------------------------------------------------------------------------------------------
				 $sql="INSERT INTO `user` (`usertype` ,`username` ,`password` ,`name` ,`image`, `mobile1` ,`mobile2` ,`email` ,`dob` ,
													`designation` ,`active` ,`created_by` ,`time`)
								VALUES 
								(:usertype ,:username ,:password ,:name ,:image, :mobile1 ,:mobile2 ,:email ,:dob ,
													:designation ,:active ,:created_by ,:time)";
				$statement=$connection->prepare($sql);
				
				$statement->bindParam(":usertype",		$usertype);
				$statement->bindParam(":username",		$username);
				$statement->bindParam(":password" ,		$password);
				$statement->bindParam(":name" ,			$name);
				$statement->bindParam(":image", 		$image);
				$statement->bindParam(":mobile1" ,		$mobile1);
				$statement->bindParam(":mobile2" ,		$mobile2);
				$statement->bindParam(":email" ,		$email);
				$statement->bindParam(":dob" ,			$dob);
				$statement->bindParam(":designation" ,	$designation);
				$statement->bindParam(":active" ,		$active);
				$statement->bindParam(":created_by" ,	$created_by);
				$statement->bindParam(":time",			$time);				
								
				if($statement->execute())
				{
					echo "<script>alert('Record Saved Successfully')</script>";
				}
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Add Student</title>
	<link href="datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
	<script src="datepicker/js/bootstrap-datepicker.js" type="text/javascript"></script>

    <link href="datepicker/css/datepicker.css" rel="stylesheet" type="text/css" />
	
	<!-- Custome Style -->
	<style type="text/css">
		div.columns       { width: 100%; }
		div.columns div   { width: 300px; float: left; padding:5px; overflow:hidden;display: inline-block;}
		div.clear         { clear: both; }
		<!-- Refer "http://www.ben-morris.com/using-the-div-tag-to-display-columns-rather-than-tables/" for more help -->
		
	</style>
	<script language="javascript">
	function validateEmail()
	{
	 
	   var emailID = document.myForm.email.value;
	   atpos = emailID.indexOf("@");
	   dotpos = emailID.lastIndexOf(".");
	   if (atpos < 1 || ( dotpos - atpos < 2 )) 
	   {
		   alert("Please Enter Valid Email ID of the User.");
		   document.myForm.email.focus();
		   return false;
	   }
	   return( true );
	}

	function validate()
	{
		if( document.myForm.usertype.value == "" )
	    {
		 alert( "Please Select User Type." );
		 document.myForm.usertype.focus() ;
		 return false;
	    }
		if( document.myForm.username.value == "" )
	    {
		 alert( "Please Enter Username to login." );
		 document.myForm.username.focus() ;
		 return false;
	    }
	    if( document.myForm.password.value == "")
	    {
		 alert( "Please Enter Password to login." );
		 document.myForm.password.focus() ;
		 return false;
	    }
		if( document.myForm.name.value == "" )
	    {
		 alert( "Please Enter the name of the User." );
		 document.myForm.name.focus() ;
		 return false;
	    }
	    if( document.myForm.mobile1.value == "" )
	    {
		 alert( "Please Enter the Mobile No. of the User." );
		 document.myForm.mobile1.focus() ;
		 return false;
	    }
		if( document.myForm.email.value == "")
	    {
	   	 alert( "Please Enter Email ID of the User." );
		 document.myForm.email.focus() ;
		 return false;
	    }
		if( document.myForm.email.value != "")
	    {
			 // Put extra check for data format
			 var ret = validateEmail();
			 if( ret == false )
			 {
				  return false;
			 }
	    }
		if( document.myForm.dob.value == "" || document.myForm.dob.value == "dd/mm/yyyy" )
	    {
		 alert( "Please Enter Date of Birth of the User." );
		 document.myForm.dob.focus() ;
		 return false;
	    }
	   
	    if( document.myForm.designation.value == "" )
	    {
		 alert( "Please Enter Designation of the User." );
		 document.myForm.designation.focus() ;
		 return false;
	    }
		if( document.myForm.file_photo.value == "" )
	    {
		 alert( "Please Select Photo of the User." );
		 document.myForm.file_photo.focus() ;
		 return false;
	    }
	}
</script>	
		
</head>

<body>

<div class="box box-primary box-solid">
                <div class="box-header with-border">
                  <h3 class="box-title"><i class="fa fa-user"></i><span style="color:#FFF"> Create a New User</span></h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div><!-- /.box-header -->
				
                <div class="box-body">
                  
				  <form method="post" action="" enctype="multipart/form-data" name="myForm" onsubmit="return(validate());">
                   
                     <!-- Row 1 -->
					<div class="columns">
					<div class="form-group">
						<label class="control-label  small" for="inputSuccess">*User Type</label>
						<select name="usertype" class="form-control input-sm" id="inputSuccess" onblur="validate_data">
							<option value="">-Select User Type-</option>
							<option value="staff" <?php if($usertype=="staff"){?> selected="selected" <?php } ?>>General User</option>
							<option value="admin" <?php if($usertype=="admin"){?> selected="selected" <?php } ?>>Administrator</option>
						</select>
					</div>			
						
					<div class="form-group">
						<label class="control-label small" for="inputSuccess">*Username</label>
						<input name="username"  type="text" class="form-control input-sm" id="username"  placeholder="Enter username for login." value="<?php echo $username; ?>"/>
					</div>	
					
					<div class="form-group">
					<label class="control-label small" for="inputSuccess">*Password</label>
<input name="password" type="text" class="form-control input-sm" id="inputSuccess"  placeholder="Create Password"/>
					</div>
				</div>	
					
				<div class="clear"></div>
				<div class="columns">
					<div class="form-group">	
						<label class="control-label small" for="inputSuccess">*User's Name</label>
						<input name="name" type="text" class="form-control input-sm" id="inputSuccess"  placeholder="Enter User's Name" value="<?php echo $name; ?>"/>
					</div>	
				</div>
				<div class="clear"></div>
				<div class="columns">
					<div class="form-group">		
						<label class="control-label small" for="inputSuccess">*Mobile No.</label>
						<input name="mobile1" type="text" class="form-control input-sm" id="inputSuccess"  placeholder="Enter students Mobile No." value="<?php echo $mobile1; ?>"/>
					</div>
					
					<div class="form-group">
						<label class="control-label small" for="inputSuccess">*Alternate Mobile No.</label>
						<input name="mobile2" type="text" class="form-control input-sm" id="inputSuccess"  placeholder="Enter alternate mobile no. of student." value="<?php echo $mobile2; ?>"/>
					</div>	
					
					<div class="form-group">
						<label class="control-label small" for="inputSuccess">*Email ID</label></td>
						<input name="email" type="text" class="form-control input-sm" id="inputSuccess"  placeholder="Enter Email ID of the student" value="<?php echo $email; ?>"/>
					</div>	
				</div>	
				<div class="clear"></div>
				
				<div class="clear"></div>
				<div class="columns">		
					<div class="form-group">
						<label class="control-label small" for="inputSuccess">*Date of Birth</label>
						<input type="text" name="dob" class="form-control input-sm" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo $DOB; ?>"/>
					</div>
					
					<div class="form-group">
						<label class="control-label small" for="inputSuccess">*Designation</label>
						<input name="designation" type="text" class="form-control input-sm" id="inputSuccess"  placeholder="Enter Designation of the user" value="<?php echo $designation; ?>"/>
					</div>	
					
					<div class="form-group">
						<label class="control-label small" for="inputSuccess">*Is the user Active?</label>
								<select name="active" class="form-control input-sm" id="inputSuccess" >
									<option value="">-Select Gender-</option>
									<option value="0" <?php if($active==0){?> selected="selected" <?php } ?>>Yes</option>
									<option value="1" <?php if($active==1){?> selected="selected" <?php } ?>>No</option>
								</select>
					</div>
				</div>	
					
				<div class="clear"></div>
				<div class="columns">
				  <div>
						<label for="exampleInputFile small">*Upload User's Photo</label></td>
						<input name="file_photo" type="file" id="exampleInputFile" class="form-control input-sm" >
						<label>
						
						</label>
					</div>
				</div>		
				<div class="clear"></div>

	  	
					<div class="box-footer">
					<input type="submit" name="submit" class="btn btn-primary" value="Save Record" onmouseover="return(validate());">
					</div>
					</form>
                  </div><!-- /.table-responsive -->
                </div><!-- /.box-body -->
               	<!--
			    <div class="box-footer clearfix">
                  <a href="javascript::;" class="btn btn-sm btn-info btn-flat pull-left">Place New Order</a>
                  <a href="javascript::;" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>
                </div><!-- /.box-footer -->
				
              </div>
			  
<!-- jQuery 2.1.3 -->
    
    <!-- InputMask -->
    <script src="plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
    <script src="plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
    <script src="plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
    
    <!-- Page script -->
    <script type="text/javascript">
      $(function () {
        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
        //Datemask2 mm/dd/yyyy
        $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
        //Money Euro
        $("[data-mask]").inputmask();

        //Date range picker
        $('#reservation').daterangepicker();
        //Date range picker with time picker
        $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
        //Date range as a button
        $('#daterange-btn').daterangepicker(
                {
                  ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                    'Last 7 Days': [moment().subtract('days', 6), moment()],
                    'Last 30 Days': [moment().subtract('days', 29), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                  },
                  startDate: moment().subtract('days', 29),
                  endDate: moment()
                },
        function (start, end) {
          $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
        );

        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
          checkboxClass: 'icheckbox_minimal-blue',
          radioClass: 'iradio_minimal-blue'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
          checkboxClass: 'icheckbox_minimal-red',
          radioClass: 'iradio_minimal-red'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
          checkboxClass: 'icheckbox_flat-green',
          radioClass: 'iradio_flat-green'
        });

        //Colorpicker
        $(".my-colorpicker1").colorpicker();
        //color picker with addon
        $(".my-colorpicker2").colorpicker();

        //Timepicker
        $(".timepicker").timepicker({
          showInputs: false
        });
      });
    </script>

  </body>
</html>
