<?php include('CODE_studentBatch.php'); ?>
<form action="" method="post" name="formStudentBatch">
<div class="box box-solid box-primary">
	<div class="box-header">
			<h3 class="box-title"><i class="fa fa-users"></i> Add Batch Details</h3>
	</div><!-- /.box-header -->
	
    <div class="box-body">
    	<div class="row">
			<div class="col-md-2">
				<div class="form-group">
                    <label class="small">* Batch Name</label>
					<input type="text" class="form-control input-sm" name="batchNo" value="<?php echo $studentBatch['batchNo']?>" />
				</div>	
			</div>
		</div>
		
    	<div class="row">
        	<div class="col-md-2">
            	<div class="form-group">
                    <label class="small"><i class="fa fa-users"></i> Batch Preference</label>
                    <select class="form-control input-sm" type="text" name="preference" onChange="document.getElementById('egender').innerHTML ='';">
                        <option value='' 					<?php if($studentBatch['preference']=='')					{?> selected="selected" <?php } ?>>None</option>
                        <option value="Morning" 			<?php if($studentBatch['preference']=='Morning')				{?> selected="selected" <?php } ?>>Morning</option>
                        <option value="Evening" 			<?php if($studentBatch['preference']=='Evening')			{?> selected="selected" <?php } ?>>Evening</option>
                        <option value="Thursday & Sunday" 	<?php if($studentBatch['preference']=='Thursday & Sunday'){?> selected="selected" <?php } ?>>Thursday & Sunday</option>
                        <option value="Saturday & Sunday" 	<?php if($studentBatch['preference']=='Saturday & Sunday'){?> selected="selected" <?php } ?>>Saturday & Sunday</option>
                        <option value="Private" 			<?php if($studentBatch['preference']=='Private')			{?> selected="selected" <?php } ?>>Private</option>
                    </select>
                    <span class="error" id="epreference"></span>
                </div>
            </div>
            
			
            <div class="col-md-2">
            	<div class="bootstrap-timepicker">
                    <div class="form-group">
                      <label class="small">Batch Start Time</label>
                      <div class="input-group">
                        <input type="text" class="form-control timepicker input-sm" name="batchStartTime" value="<?php echo $studentBatch[batchStartTime]; ?>"/>
                        <div class="input-group-addon">
                          <i class="fa fa-clock-o"></i>
                        </div>
                      </div><!-- /.input group -->
                    </div><!-- /.form group -->
                  </div>
				  <span class="error" id="ebatchStartTime"></span>
            </div>
            
            <div class="col-md-2">
            	<div class="bootstrap-timepicker">
                    <div class="form-group">
                      <label class="small">Batch End Time</label>
                      <div class="input-group">
                        <input type="text" class="form-control timepicker input-sm" name="batchEndTime" value="<?php echo $studentBatch[batchEndTime]; ?>"/>
                        <div class="input-group-addon">
                          <i class="fa fa-clock-o"></i>
                        </div>
                      </div><!-- /.input group -->
                    </div><!-- /.form group -->
                  </div>
				  <span class="error" id="ebatchEndTime"></span>
            </div>
            
            <div class="col-md-2">
            	<div class="form-group">
                    <label class="small">Batch Day</label>
                    <select class="form-control input-sm" type="text" name="day" onChange="document.getElementById('egender').innerHTML ='';">
						<option value='' 			<?php if($studentBatch['day']=='')		{?> selected="selected" <?php } ?>>	None</option>
						<option value="Monday" 		<?php if($studentBatch['day']=='Monday')	{?> selected="selected" <?php } ?>>	Monday</option>
						<option value="Tuesday" 	<?php if($studentBatch['day']=='Tuesday')	{?> selected="selected" <?php } ?>>	Tuesday</option>
						<option value="Wednesday" 	<?php if($studentBatch['day']=='Wednesday'){?> selected="selected" <?php }?>>Wednesday</option>
						<option value="Thursday" 	<?php if($studentBatch['day']=='Thursday'){?> selected="selected" <?php } ?>>	Thursday</option>
						<option value="Friday" 		<?php if($studentBatch['day']=='Friday')	{?> selected="selected" <?php } ?>>	Friday</option>
						<option value="Saturday" 	<?php if($studentBatch['day']=='Saturday'){?> selected="selected" <?php } ?>>	Saturday</option>
						<option value="Sunday" 		<?php if($studentBatch['day']=='Sunday')	{?> selected="selected" <?php } ?>>	Sunday</option>
                    </select>
                    <span class="error" id="eday"></span>
                </div>
            </div>
            
            <div class="col-md-2">
            	<div class="form-group">
                    <label class="small">* Trainer</label>
                    <select class="form-control input-sm" type="text" name="trainerName" onChange="document.getElementById('egender').innerHTML ='';">
                    <option value='' 		<?php if($studentBatch['trainerName']==''){?> selected="selected" <?php } ?>>--- Select Trainer ---</option>
                    <?php
						$sqlTrainer="select studID, name from student where deleted=:deleted and dropout=:dropout and currentBelt=:currentBelt";
						$studentTableName = $connection -> prepare($sqlTrainer);
						
						$deleted=0;
						$studentTableName -> bindParam(":deleted", 		$deleted);
						
						$dropout=0;
						$studentTableName -> bindParam(":dropout", 		$dropout);
						
						$currentBelt="Black";
						$studentTableName -> bindParam(":currentBelt",	$currentBelt);												
						
						
						$studentTableName -> execute();
						
						while($trainerName = $studentTableName -> fetch(PDO::FETCH_ASSOC))
						{
					?>
					<option value="<?php echo $trainerName[studID]; ?>" 	<?php if($studentBatch['trainerName']=="{$trainerName[studID]}"){?> selected="selected" <?php } ?>><?php echo ucwords(strtolower($trainerName[name])); ?></option>
                    <?php
						}
					?>
                    </select>
                    <span class="error" id="etrainerName"></span>
                </div>
            </div>
        
			<div class="col-md-2">
			<div class="form-group">
				<label class="small">Batch Start Date</label>
				<div class="input-group">
				  <div class="input-group-addon">
					<i class="fa fa-calendar"></i>
				  </div>
				  <input type="text" class="form-control input-sm" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask name="startDate"/>
				</div><!-- /.input group -->
			 </div>
		</div> 
	  
			
		</div>	
		<div class="box-footer">
				<button type="submit" name="createBatch" class="btn btn-primary">Add Batch</button>
		</div>
	</div>
    </div><!-- /.box-body -->	
		
		<?php
				// Include the view_StudentBatch.php to view the Batch Details
				include('files/admin/view_studentBatch.php');
		?>
		
</div><!-- /.box -->
</form>

