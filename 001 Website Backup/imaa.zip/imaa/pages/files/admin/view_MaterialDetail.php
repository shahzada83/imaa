<style>
td, tr
{
	font-size:12px;
}
</style>	
 		
            
<!-- /.row -->
<div class="row">
	<div class="col-lg-12">
		<div class="box box-success box-solid">
                <div class="box-header">
                  <h3 class="box-title">View Material Details</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped table-responsive">
                    <thead>
                      <tr>
					  	<th>Item Name</th>
                        <th>Size</th>
						<th>Quality</th>
						<th>Selling Price</th>
						<th align="center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
//***********************************************************************************************************************************************//
	$sqlProductDetail="SELECT * FROM materialdetail ORDER by itemName, size, quality";
	$statementProductDetail=$connection->query($sqlProductDetail); // We can use DELETE, INSERT and UPDATE QUERY as usual
	
	if($statementProductDetail->rowCount())
	{
	while($dataProductDetail = $statementProductDetail->fetch(PDO::FETCH_ASSOC)) // if row is returned from database/ table
	{
//***********************************************************************************************************************************************//	
?>
                      <tr>
                        <td>
							<strong style="color:#03C">
								<?php echo $dataProductDetail['itemName'];?>
							</strong>
						</td>
                        <td>
							<?php echo $dataProductDetail['size'];?> "
						</td>
						
                        <td>
							<?php echo $dataProductDetail['quality'];?>
						</td>
						
                        <td>
							Rs. <?php echo $dataProductDetail['sellingPrice'];?>
						</td>
                        
						
						
						<td align="center">
			<a href='files/action_student.php?tsk=delMaterial&slno=<?php echo $dataProductDetail['materialID']; ?>' 
			onClick="return confirm_action('Are you sure you want to Delete ths Record')" target=""
			class="btn btn-danger btn-sm pull-left"
			> 
			
			<i class="fa fa-trash"></i>&nbsp;&nbsp;&nbsp;Delete</a> </li>
						</td>
						
                      </tr>
<?php
//***********************************************************************************************************************************************//	
	}	// Close While
	}	// Close if
//***********************************************************************************************************************************************//	
?>                      
                    </tbody>
                    <tfoot>
                        <th>Item Name</th>
                        <th>Size</th>
						<th>Quality</th>
						<th>Selling Price</th>
						<th align="center">Action</th>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->

    
