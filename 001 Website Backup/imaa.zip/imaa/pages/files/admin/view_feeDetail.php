<style>
td, tr
{
	font-size:12px;
}
</style>	
 		
            
<!-- /.row -->
<div class="row">
	<div class="col-lg-12">
		<div class="box box-success box-solid">
                <div class="box-header">
                  <h3 class="box-title">View Fee Head Details</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped table-responsive">
                    <thead>
                      <tr>
					  	<th>Fee Head Name</th>
                        <th>Amount</th>
						<th>Created By</th>
						<th>Created On </th>
						<th align="center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
//***********************************************************************************************************************************************//
	$sqlFeeDetail="SELECT feedetail.* , user.name AS userName FROM feedetail, user WHERE user.userID = feedetail.createdBy and feedetail.active=:active";
	$statementFeeDetail=$connection->prepare($sqlFeeDetail); // We can use DELETE, INSERT and UPDATE QUERY as usual
	$active=0;
	$statementFeeDetail->bindParam(":active", $active);
	$statementFeeDetail->execute();
	if($statementFeeDetail->rowCount())
	{
	while($dataFeeDetail = $statementFeeDetail->fetch(PDO::FETCH_ASSOC)) // if row is returned from database/ table
	{
//***********************************************************************************************************************************************//	
?>
                      <tr>
                        <td>
							<strong style="color:#03C">
								<?php echo $dataFeeDetail['head'];?>
							</strong>
						</td>
                        <td>
							<?php echo $dataFeeDetail['amount'];?>
						</td>
						
                        <td>
							<?php echo $dataFeeDetail['userName'];?>
						</td>
						
                        <td>
							<?php echo date("d-M-Y  h:m:i A", $dataFeeDetail['createdOn']);?>
						</td>
                        
						
						
						<td align="center">
			<a href='<?php //deleteStudentBatchRecordFunction(); ?>' onClick="return confirm_action('Are you sure you want to Delete ths Record')" target=""> <i class="fa fa-drop" style="color:#FF0000"></i>Delete</a> </li>
						</td>
						
                      </tr>
<?php
//***********************************************************************************************************************************************//	
	}	// Close While
	}	// Close if
//***********************************************************************************************************************************************//	
?>                      
                    </tbody>
                    <tfoot>
                        <th>Fee Head Name</th>
                        <th>Amount</th>
						<th>Created By</th>
						<th>Created On </th>
						<th align="center">Action</th>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->

    
