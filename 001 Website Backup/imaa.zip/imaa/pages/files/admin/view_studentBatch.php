<style>
td, tr
{
	font-size:12px;
}
</style>	
 		
            
<!-- /.row -->
<div class="row">
	<div class="col-lg-12">
		<div class="box box-success box-solid">
                <div class="box-header">
                  <h3 class="box-title">View Batch Details</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped table-responsive">
                    <thead>
                      <tr>
					  	<th>Batch Name/ No.</th>
					  	<th>Preference</th>
                        <th>Day</th>
						<th>Time</th>
						<th>Trainer</th>
						<th>Created By/ On</th>
						<th align="center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
//***********************************************************************************************************************************************//
	$sqlStudentBatchQuery="SELECT `studentbatch`.*, `student`.`name`, `student`.`admID`  FROM `studentbatch`, `student`  WHERE `student`.`studID`=`studentbatch`.`studID` and `studentbatch`.`active`=0";
	$statementStudentBatch=$connection->query($sqlStudentBatchQuery); // We can use DELETE, INSERT and UPDATE QUERY as usual
	
	while($dataStudentBatch = $statementStudentBatch->fetch(PDO::FETCH_ASSOC)) // if row is returned from database/ table
	{
//***********************************************************************************************************************************************//	
?>
                      <tr>
					  	<td width="80px">
							<strong>
								<?php echo $dataStudentBatch['batchNo'];?>
							</strong>
						</td>
                        <td width="80px">
							<strong>
								<?php echo $dataStudentBatch['preference'];?>
							</strong>
						</td>
                        <td>
							<?php echo $dataStudentBatch['day'];?>
						</td>
						
                        <td>
							<?php echo $dataStudentBatch['time'];?>
						</td>
						
                        <td>
							<a href="main.php?pg=profile&admID=<?php echo $dataStudentBatch['admID']; ?>" target="_blank">
								<?php echo $dataStudentBatch['name'];?>
							</a>
						</td>
                        
						<td>
							<?php echo $dataStudentBatch['userName'];?><br>
							<?php echo date("d-M-Y  h:m:i A", $dataStudentBatch['createdOn']);?>
						</td>
						
						<td align="center">
			<a href='<?php //deleteStudentBatchRecordFunction(); ?>' onClick="return confirm_action('Are you sure you want to Delete ths Record')" target=""> <i class="fa fa-drop" style="color:#FF0000"></i>Delete</a> </li>
						</td>
						
                      </tr>
<?php
//***********************************************************************************************************************************************//	
	}	
//***********************************************************************************************************************************************//	
?>                      
                    </tbody>
                    <tfoot>
                       <th>Preference</th>
                        <th>Day</th>
						<th>Time</th>
						<th>Trainer</th>
						<th>Created By/ On</th>
						<th align="center">Action</th>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->

    
