
	<style type="text/css">
		div.columns       { width: 100%; }
		div.columns div   { width: 200px; float: left; padding:5px; overflow:hidden;display: inline-block;}
		div.clear         { clear: both; }
		<!-- Refer "http://www.ben-morris.com/using-the-div-tag-to-display-columns-rather-than-tables/" for more help -->
		
	</style>
        <!-- Content Header (Page header) -->
        <!-- Main content -->
		
		<!--------------------------------------------------------------------->
 <form method="post" action="" enctype="multipart/form-data">
   <!-- /.box -->
   <!--------------------------------------------------------------------->
              <div class="box box-primary box-solid">
                <div class="box-header with-border">
                  <h3 class="box-title">You are Viewing All Users</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table width="100%" class="table table-bordered table-striped" id="example1" style="font-size:11px;">
                    <thead>
                      <tr>
                        <th width="100">&nbsp;</th>
                        <th width="250">User's Detail</th>
                        <th width="250">Contact Detail </th>
                        <th>Other Details</th>
                        <th width="10px">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php
					$sql_user="select * from user where active=0 ORDER By name";
					$result=$connection->query($sql_user);
					
					while($data_user=$result->fetch(PDO::FETCH_ASSOC))
					{
					?>
                      <tr>
                        <td align="center">
							<img src="001_student_photo/<?php echo ($data_user['image'])?$data_user['image']:"no_image.png"; ?>" class="img-circle" alt="User Image" width="80px" height="80px" />						</td>
                        
						<td><?php echo ucwords(strtolower($data_user['name'])); ?><br />                          <?php echo "<b>".$data_user['designation']."</b>"; ?><br />
                          <?php echo "<b>Date of Birth: </b>"; ?> <?php echo short_date($data_user['dob']); ?> <br />						
						   <?php echo "<b>Status: </b>"; ?> <?php echo ($data_user['active']==0)?"Active":"<b>In-Active</b>"; ?> <br />		
						  
						  </td>
                        
						<td>
						<?php echo "<b>Contact No.   : </b>".$data_user['mobile1']; ?> <br />
						<?php echo "<b>Alternate No. : </b>".$data_user['mobile2']; ?> <br />	
						<?php echo "<b>Email ID : </b>".$data_user['email']; ?> <br />						</td>
                        
						<td>
						<b>Username : </b><?php echo $data_user['username']; ?><br /> 
						<b>User Type : </b><?php echo strtoupper($data_user['usertype']); ?><br />
						<b>Created By </b> <?php echo $data_user['created_by'] . " On " . date("d-M-Y h:i:s A",$data_user['time']); ?></td>
                        <td style="width:10px">
<div class="input-group-btn" style="width:10px; height:10px;">
	<button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
			<i class="glyphicon glyphicon-cog"></i>&nbsp;&nbsp;Action&nbsp;&nbsp;<span class="fa fa-caret-down"></span></button>
		<ul class="dropdown-menu">
			<?php $student_slno=$data_user['student_slno']; ?>
			<li><a href="#"><i class="fa fa-search" style="color:#FF9900"></i>Mark In-active</a></li>
			<li><a href="#"><i class="fa fa-edit" style="color:#33CC33"></i>Edit</a></li>
			<li class="divider"></li>
			<li><a href="#"><i class="fa fa-times-circle" style="color:#FF0000"></i>Delete</a></li>
		</ul>
</div><!-- /btn-group -->					  </td>
                      </tr>
					  <?php 
					  }
					  ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>&nbsp;</th>
                        <th>User's Detail</th>
                        <th>Contact Details </th>
                        <th>Other Details </th>
                        <th>&nbsp;</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
            </div><!-- /.col -->
</form>