<?php
##########################################################################################################
function backup_tables($host, $user, $pass, $name, $tables = '*')
{
  $data = "\n/*---------------------------------------------------------------".
          "\n  SQL DB BACKUP ".date("d.m.Y H:i")." ".
          "\n  HOST: {$host}".
          "\n  DATABASE: {$name}".
          "\n  TABLES: {$tables}".
          "\n  ---------------------------------------------------------------*/\n";
  $link = mysql_connect($host,$user,$pass);
  mysql_select_db($name,$link);
  mysql_query( "SET NAMES `utf8` COLLATE `utf8_general_ci`" , $link ); // Unicode

  if($tables == '*')
  { //get all of the tables
    $tables = array();
    $result = mysql_query("SHOW TABLES");
    while($row = mysql_fetch_row($result)){
      $tables[] = $row[0];
    }
  }
  else
  {
    $tables = is_array($tables) ? $tables : explode(',',$tables);
  }

  foreach($tables as $table)
  {
    $data.= "\n/*---------------------------------------------------------------".
            "\n  TABLE: `{$table}`".
            "\n  ---------------------------------------------------------------*/\n";           
    $data.= "DROP TABLE IF EXISTS `{$table}`;\n";
    $res = mysql_query("SHOW CREATE TABLE `{$table}`", $link);
    $row = mysql_fetch_row($res);
    $data.= $row[1].";\n";

    $result = mysql_query("SELECT * FROM `{$table}`", $link);
    $num_rows = mysql_num_rows($result);    

    if($num_rows>0)
	{
      $vals = Array(); $z=0;
      for($i=0; $i<$num_rows; $i++){
        $items = mysql_fetch_row($result);
        $vals[$z]="(";
        for($j=0; $j<count($items); $j++){
          if (isset($items[$j])) { $vals[$z].= "'".mysql_real_escape_string( $items[$j], $link )."'"; } else { $vals[$z].= "NULL"; }
          if ($j<(count($items)-1)){ $vals[$z].= ","; }
        }
        $vals[$z].= ")"; $z++;
      }
      $data.= "INSERT INTO `{$table}` VALUES ";      
      $data .= "  ".implode(";\nINSERT INTO `{$table}` VALUES ", $vals).";\n";
    }
  }
  mysql_close( $link );
  return $data;
}

#How to use:
#-------------------------------------------------------------------------------------------------------
// create backup
//////////////////////////////////////

		#$backup_file = 'db-backup-'.time().'.sql';
// get backup
		#$mybackup = backup_tables("myhost","mydbuser","mydbpasswd","mydatabase","*");

// 		save to file
#		$handle = fopen($backup_file,'w+');
#		fwrite($handle,$mybackup);
#		fclose($handle);
##########################################################################################################

$databaseName="imssihra_acaswebsite";
$sqlTableNames="SELECT table_name FROM information_schema.tables WHERE table_schema =  '$databaseName'";
$stmtTableNames=$connection->query($sqlTableNames);

if(isset($_REQUEST['submit']))
{
	
	$tableName=$_REQUEST[tableName];
	//print_r($tableName);
	foreach($tableName as $tbl)
	{
		if(!file_exists(dbBackup))
		{
			mkdir('dbBackup');
		}	
		$dir=mkdir("dbBackup/".date("d-M-Y"));
		$backup_file = 'dbBackup/'.date("d-M-Y")."/". time() . "-" . ++$slno . "_TABLE NAME _ " . $tbl . ".sql";
		// get backup
		//$mybackup = backup_tables("localhost","imssihra_acas","tan2345Shahzada","imssihra_acaswebsite",$tbl);
		$mybackup = backup_tables("localhost","imaakdpp_online","tan2345Shahzada","imaakdpp_online",$tbl);
		//$mybackup = backup_tables("localhost","root","","imaa",$tbl);
	
		// save to file
		$handle = fopen($backup_file,'w+');
		fwrite($handle,$mybackup);
		fclose($handle);	
	}	
}
?>
<style>
#loaderGIF
{
	display:none;
}
</style>
<div class="box box-solid box-warning">
		<div class="box-header">
		  <h3 class="box-title"><i class="fa fa-download"></i> List of All Tables in 'acas' Database</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
			<div class="row">
				<div class="col-md-4">
					<form action='' method='post'>
						<?php
							while($dataTableNames=$stmtTableNames->fetch(PDO::FETCH_ASSOC))
							{
						?>	
							<label >
								&nbsp;&nbsp;&nbsp;
								<input type='checkbox' name='tableName[]' value='<?php echo $dataTableNames[table_name]; ?>'> &nbsp;&nbsp;&nbsp;
								<?php echo $dataTableNames[table_name]; ?>
							</label>
							<br>
							<?php
							}
							?>
							
						<input type='submit' name='submit' value='Create Table Backup' class="btn btn-warning">
						<a href="#"  class="btn btn-danger" onclick="backupDatabase();">Backup Database (.ZIP)</a>
					</form>
				</div>
				<div class="col-md-4">
					<p id="backupMsg"></p>
					<center>
						<img src='ajax-loader.gif' id="loaderGIF">
					</center>
				</div>
				<div class="col-md-4">
					<h4>Backup Details</h4>
					<p>
						<?php 
							listFolderFiles('dbbackup');
						?>
					</p>
				</div>
			</div>	
		</div><!-- /.box-body -->
</div><!-- /.box -->
	  
	  <script>
	 
function backupDatabase() {
  document.getElementById('loaderGIF').style.display="block";
  var xhttp;    
 
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("backupMsg").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "files/myphp-backup.php", true);
  xhttp.send();
  document.getElementById('loaderGIF').style.display="none";
}
</script>