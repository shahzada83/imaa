<?php
include('database.php');
include('API.php');
//echo 'Hello';
if(isset($_POST[examFormNo]))
{
	$gradingData=prepareData($_POST);
	//print_r($gradingData);
	//$gradingData['date'],
	
	//check is the record already exists
	
	$sqlCheckPreviousEntry="SELECT * from `exam` where `studID`='{$gradingData[txtStudentID]}' and `FormNo`='$gradingData[examFormNo]' and `examMonth`='$gradingData[examMonth]'";
	
	$dataCheckPreviousEntry=Select(connectDB(), $sqlCheckPreviousEntry);
	if($dataCheckPreviousEntry[FormNo]!='')
	{
		$error =  "Form No. : $gradingData[examFormNo], already filled by the student";
	}	
	elseif($gradingData['date']=='dd/mm/yyyy')
	{
		$error = "Please enter date.";
	}
	elseif($gradingData['examFormNo']=='')
	{
		$error = "Please enter Form No..";
	}
	elseif($gradingData['examMonth']=='')
	{
		$error = "Please select Exam Month.";
	}
	elseif($gradingData['gradingFrom']=='')
	{
		$error = "Something went wrong. Refresh page or Login again or Contact 7739020000 if problem persist GF.";
	}
	elseif($gradingData['gradingTo']=='')
	{
		$error = "Something went wrong. Refresh page or Login again or Contact 7739020000 if problem persist GT.";
	}
	
	elseif((($gradingData['fee']+$gradingData['lateFine'])!=$gradingData['paid']) && ($gradingData['due']==0 or $gradingData['due']=='') )
	{
		$error = "Totalling Error";
	}
	elseif(trim($gradingData['paid'])=='')
	{
		$error = "Please enter amount received from student";
	}
	else
	{
		$fee = ($gradingData['feeText']=='')?$gradingData['fee']:$gradingData['feeText'];
		$data=array(
						'receiptNo'			=> $gradingData['receipt_no'],
						'studID'			=> $gradingData['txtStudentID'],
						'FormDate'			=> short_date($gradingData['date']),
						'FormNo'			=> $gradingData['examFormNo'],
						'examMonth'			=> $gradingData['examMonth'],
						'gradingFrom'		=> $gradingData['gradingFrom'],
						'gradingTo'			=> $gradingData['gradingTo'],
						'fee'				=> $fee,
						'lateFee'			=> $gradingData['lateFine'],
						'due'				=> $gradingData['due'],
						'totalReceived'		=> $gradingData['paid']
					);
		$msg= Insert(connectDB(), 'exam', $data);	
		echo "<script>alert('".$msg."')</script>";
		echo "<script>window.open('files/view_receipt_exam.php?rcpt={$gradingData['receipt_no']}', '_blank')</script>";
		file_put_contents('receiptNo',$receiptNo); // Update fee Receipt		
		echo "<script>document.location.href='main.php?pg=Z3JhZGluZyBmb3Jt'</script>";	

	}	
}

if(isset($error))
{
			echo "<div class='alert alert-danger alert-dismissible'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
					<h5><i class='icon fa fa-ban'></i> <b>ERROR ! </b> $error</h5>
					
				  </div>";
}	  
?>

		