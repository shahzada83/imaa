<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php include('CODEcourier.php'); ?>
<form action="" method="post" name="formCourier" onsubmit="validateCourier()">
<div class="box box-solid box-warning">
	<div class="box-header">
	  <h3 class="box-title">Student Profile</h3>
	</div><!-- /.box-header -->
	
	<div class="box-body">
		<div class="row">
			<div class="col-lg-2  col-md-2 col-xs-6">
				<div class="form-group">
					<label class="small">Type</label>
					<?php $admID=mktime(); ?>
					<select name="type" class="form-control input-sm" name="type">
						<option value="">		NONE	</option>
						<option value="out">	SENT	</option>
						<option value="in">		RECEIVED</option>
					</select>
				</div>
			</div>
			
			<div class="col-lg-2 col-md-2  col-xs-6">
				<div class="form-group">
					<label class="small">Date</label>
					<?php $admDate=date("d/m/Y"); ?>
					<input name="date" type="text" class="form-control input-sm" id="adm_date" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo $admDate; ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
					
					<span class="error" id="eAdmDate"></span>
				</div>
			</div>
			
			<div class="col-lg-2 col-md-2  col-xs-6">
				<div class="form-group">
					<label class="small">Courier Name</label>
					<input name="courierService" class="form-control input-sm"  list="head">
					<datalist id="head">
					<?php
					$sqlCourier="select distinct(courierService) from courier";
					$stmtCourier=$connection->query($sqlCourier);
					while($dataCourier = $stmtCourier->fetch(PDO::FETCH_ASSOC))
					{
					?>
						<option><?php echo $dataCourier[courierService]; ?></option>
					<?php
					}
					?>	
					</datalist>
					<span class="error" id="eheadname"></span>
				</div>	
			</div>
			
			<div class="col-lg-2 col-md-2  col-xs-6">
				<div class="form-group">
					<label class="small">Consignment No.</label>
					<input class="form-control input-sm" type="text" name="trackingNo">
					<span class="error" id="eAdmDate"></span>
				</div>
			</div>
			
		</div>
		
		<div class="row">
			<div class="col-lg-4 col-md-4  col-xs-6">
				<div class="form-group">
					<label class="small">To, Name</label>
					<input class="form-control input-sm" type="text" name="toName">
					<label class="small">Address</label>
					<textarea class="form-control input-sm" name="toAddress"></textarea>
					<span class="error" id="eAdmDate"></span>
				</div>
			</div>

			<div class="col-lg-4 col-md-4  col-xs-6">
				<div class="form-group">
					<label class="small">From</label>
					<textarea class="form-control input-sm" rows="5" name="from"></textarea>
					<span class="error" id="eAdmDate"></span>
				</div>
			</div>
			
			<div class="col-lg-4 col-md-4  col-xs-6">
				<div class="form-group">
					<label class="small">Document Details</label>
					<textarea class="form-control input-sm" rows="5" name="document"></textarea>
					<span class="error" id="eAdmDate"></span>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-lg-4 col-md-4  col-xs-6">
				<input class="btn btn-warning" type="submit" name="add_courier" value="Save Record" onmouseover="validate();">
			</div>
		</div>	
		
	</div><!-- /.box-body -->
</div><!-- /.box -->
</form>