<?php  
	
	#-----------------------------------------------------------------------------------------------------------#
	
	#		include 'class.php';																				#
	#		$array=array(																						#
	#						'username' 	=> 'shahzada',															#
	#						'password'	=> 'acas@99'															#
	#					);																						#
	#
	#		//$connection = connectDB();																		#
	#																											#
	#		$message 	= Insert(connectDB(), 'user', $array);													#
	#		$message 	= Update(connectDB(), 'user', $array, 'userID', 6);										#
	#																											#
	#		echo $message;																						#

	#-----------------------------------------------------------------------------------------------------------#
	
	
error_reporting(0);

	/*- This function is used to connect to database in PDO way -*/
	function connectDB()
	{
		/************************************************		
		$servername 		= "localhost";
		 $username 		= "imaakdpp_online";
		 $password 		= "tan2345Shahzada";
		 $dbname		= "imaakdpp_online";
		*************************************************/
		 $servername 	= "localhost";
		 $username 		= "root";
		 $password 		= "";
		 $dbname		= "imaa";
		 $connection;
		 
		try 
		{
			$connection = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
			$connection->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			$connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
			return $connection;
		} 
		catch (Exception $e) 
		{
			echo $error = $e->getMessage();
		}
	}
	
	/*- This function is used to prepare the $_POST data from form, for saving into database -*/
	function prepareData($rawData)
	{
		$readyData = array_map ('htmlspecialchars' 	, $rawData 		);
		$readyData = array_map ('trim'				, $readyData	);
		$readyData = array_map ('addslashes'		, $readyData	);
		
		return $readyData;
	}
	
	/*- This function is used to perform INSERT query through $_POST data from form, dynamically -*/
	function Insert($connection, $tableName, $data_array)
	{
		try 
		{
			$sqlQuery	 =	"INSERT INTO `{$tableName}` (`";
			$sqlQuery	.=	implode("`, `", array_keys($data_array))."`) VALUES('";
			$sqlQuery	.=	implode("', '", array_values($data_array))."')";
			
			//echo $sqlQuery; 
			
			if($connection->query($sqlQuery))
			{
				return "Record saved Successfully";
			}
		}	
		catch (Exception $e) 
		{
			return $e->getMessage();
		}
	}
	
	/*- This function is used to perform UPDATE query through $_POST data from form, dynamically -*/
	function Update($connection, $tableName, $data_array, $fieldName, $uniqueID)
	{
		$sqlQuery	 =	"UPDATE `{$tableName}` SET ";
		foreach($data_array as $key => $value)
		{
			$sqlQuery	.= 	"`" . $key . "` = '" . $value ."', ";		
		}
		$sqlQuery = substr($sqlQuery, 0, -2); // Removing the ", " from the $sqlQuery string
		
		$sqlQuery .= " WHERE `{$fieldName}`='" .$uniqueID. "'";
		
		if($connection->query($sqlQuery))
		{
			return "Record updated Successfully";
		}
	}
	
	/*- This function is used to perform SELECT query in the database -*/
	function Select($connection, $query)
	{
		//echo $query;
		$statement	=$connection->query($query);
		$data		=$statement->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

?>