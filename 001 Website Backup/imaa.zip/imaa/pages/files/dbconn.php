

<?php  //********** Connection to database using PDO
error_reporting(0);

try
{
	/**************************************************
	$connection = new PDO("mysql:host=localhost; dbname=imaa", "root", "");
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
	$connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
	//echo "Connected";
	
	
	/**************************************************/
	$connection = new PDO("mysql:host=localhost; dbname=imaakdpp_online", "imaakdpp_online", "tan2345Shahzada");
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
	$connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
	//echo "Connected";
	/***************************************************/
	
}
catch(PDOException $e)
{
	die("Sorry!! Something went wrong. Please contact administrator at Ph. 7739020000. ".$e->getmessage());
}
?>

<?php
/***************************************

			$_SESSION['userID']=$result[userID];
			 $_SESSION['sessionUserName']=$result[name];
			 $_SESSION['sessionUserType']=$result[usertype];
			 $_SESSION['sessionUserImage']=$result[image];
			 $_SESSION['sessionUserDesignation']=$result[designation];
			 $_SESSION['sessionUserTime']=$result[time];


feedetail TABLE DB
------------------------------------------------
feeDetailID		head				amount
------------------------------------------------
6				Admission Fee		600
7				Karate Dress Fee	700, 800, 2000
8				Track Suit Fee		800
9				Monthly Fee		600
***************************************/
?>