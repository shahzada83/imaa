<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php

//-------------------------------------
if(isset($_REQUEST['submit']))
{
	$old_pwd=md5($_REQUEST['old_pwd']);
	$new_pwd=md5($_REQUEST['new_pwd']);
	$c_new_pwd=md5($_REQUEST['c_new_pwd']);
	if($old_pwd=="")
	{
		echo "<script language='javascript'>alert('Please enter old password.')</script>";
	}
	elseif($new_pwd=="" or $c_new_pwd=="")
	{
		echo "<script language='javascript'>alert('Please enter new password.')</script>";
	}
	elseif($new_pwd!=$c_new_pwd)
	{
		echo "<script language='javascript'>alert('New Password does not match.')</script>";
	}
	else
	{
			$userID=$_SESSION['userID'];
			$sql="select password from user where userID='$userID'";
			
			$result = $connection->query($sql);
			$row = $result->fetch(PDO::FETCH_ASSOC); 
	
			if($old_pwd==$row['password'])
			{
				
				$sql="update user set password='$new_pwd' where userID='$userID'";
				if($connection->query($sql))
				{
					echo "<script language='javascript'>alert('Password Changed Successfully.')</script>";
				}
			}
		}
}
?>

<form id="form1" name="form1" method="post" action="">
   <div class="box box-primary expand-box box-solid">
                <div class="box-header with-border" style="text-align:left;">
                  <h3 class="box-title"><i class="fa fa-key"></i> &nbsp;&nbsp; Change Password</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
            		<div class="row">
						<div class="col-lg-3">		
							<div class="form-group">
								<label class="control-label small" for="inputSuccess"><i class="fa fa-unlock"></i>&nbsp;Old Password</label>
								<input name="old_pwd" type="password" id="old_pwd" class="form-control input-sm"/>
							</div>
						</div>	
						
						<div class="col-lg-3">		
							<div class="form-group">
								<label class="control-label small" for="inputSuccess"><i class="fa fa-lock"></i>&nbsp;New Password</label>
								<input name="new_pwd" type="password" id="new_pwd" class="form-control input-sm" />
							</div>
						</div>
						
						<div class="col-lg-3">		
							<div class="form-group">
								<label class="control-label small" for="inputSuccess"><i class="fa fa-lock"></i>&nbsp;Confirm Password</label>
								<input name="c_new_pwd" type="password" id="c_new_pwd" class="form-control input-sm"/>
							</div>
						<div>
						
						<div class="col-lg-3">	
							<div class="form-group">	
								<input name="submit" type="submit" id="submit" value="Update Password" <?php echo $buttonstyle; ?>  class="btn btn-primary"/>
							</div>	
						</div>
					</div> <!-- ./column -->
 				 </div><!-- /.box-body -->
  </div><!-- /.box -->
</form>
