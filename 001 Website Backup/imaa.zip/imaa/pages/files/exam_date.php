<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/


//-------------------------------------
if(isset($_REQUEST['submit']))
{
	$examMonth	=$_REQUEST['examMonth'];
	$lastDate	=short_date($_REQUEST['lastDate']);
	$lateFine	=$_REQUEST['lateFine'];
	
	if($examMonth=="")
	{
		echo "<script language='javascript'>alert('Please select Exam Month.')</script>";
	}
	elseif($lastDate=="dd/mm/yyyy")
	{
		echo "<script language='javascript'>alert('Please enter Last Date.')</script>";
	}
	elseif(trim($lateFine==''))
	{
		echo "<script language='javascript'>alert('New Password does not match.')</script>";
	}
	else
	{
			$config_exam_date	=	array(
										'examMonth'	=>	$examMonth,
										'lastDate'	=>	$lastDate,
										'lateFine'	=>	$lateFine
										);
			
			$msg	=	Insert(connectDB(), 'config_exam_date', $config_exam_date);
			if($msg)
			{
				echo "<script language='javascript'>alert('Exam Details Saved Successfully.')</script>";
				echo "<script>document.location.href='main.php?pg=ZXhhbSBkYXRl'</script>";
			}
	}
}
?>

<form id="form1" name="form1" method="post" action="">
   <div class="box box-primary expand-box box-solid">
                <div class="box-header with-border" style="text-align:left;">
                  <h3 class="box-title"><i class="fa fa-Calendar"></i> &nbsp;&nbsp; Add Exam Date</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
            		<div class="row">
						<div class="col-lg-3">		
							<div class="form-group">
								<label class="control-label small" for="inputSuccess"><i class="fa fa-calendar"></i>&nbsp;Exam Month</label>
								<select name="examMonth" id="examMonth" class="form-control input-sm" onChange="document.getElementById('show_msg_grading').innerHTML =''; checkPreviousRecord(document.getElementById('examFormNo').value);">
									<option></option>
									<option value="Apr - <?php echo date('Y'); ?>">	Apr - <?php echo date('Y'); ?>	</option>
									<option value="Aug - <?php echo date('Y'); ?>">	Aug - <?php echo date('Y'); ?>	</option>
									<option value="Dec - <?php echo date('Y'); ?>">	Dec - <?php echo date('Y'); ?>	</option>
								  </select>
							</div>
						</div>	
						
						<div class="col-lg-3">		
							<div class="form-group">
								<label class="control-label small" for="inputSuccess"><i class="fa fa-calendar"></i>&nbsp;Last Date</label>
							<input name="lastDate" type="text" class="form-control input-sm" id="adm_date" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo $admDate; ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
								
							</div>
						</div>
						
						<div class="col-lg-3">		
							<div class="form-group">
								<label class="control-label small" for="inputSuccess"><i class="fa fa-rupee"></i>&nbsp;Late Fine after Last Date</label>
								<input name="lateFine" type="text" id="c_new_pwd" class="form-control input-sm" maxlength=3 onKeyPress="return isNumberKey(event)" />
							</div>
						</div>
						
						<div class="col-lg-3">	
							<div class="form-group"><br>	
								<input name="submit" type="submit" id="submit" value="Add Date" class="btn btn-primary"/>
							</div>	
						</div>
					</div> <!-- ./column -->
 				 </div><!-- /.box-body -->
  </div><!-- /.box -->
</form>
<div class="box box-primary expand-box box-solid">
	 <table id="example2" class="table table-bordered table-striped table-responsive">
		<tr>
			<th>Exam Month	</th>
			<th>Last Date	</th>
			<th>Late Fine	</th>
			<th>Edit		</th>
			<th>Active		</th>
		</tr>
		<?php
		$sql="SELECT * from  config_exam_date ";
		$stmt=$connection->query($sql);
		while($data=$stmt->fetch(PDO::FETCH_ASSOC))
		{
		?>
		<tr>
			<td id="EM<?php echo $data['ID']; ?>"><?php echo $data['examMonth']; ?></td>
			<td id="LD<?php echo $data['ID']; ?>"><?php echo format_date($data['lastDate']); ?></td>
			<td id="LF<?php echo $data['ID']; ?>"><?php echo $data['lateFine']; ?></td>
			<td><a class='btn btn-aqua'  data-toggle='modal' data-target='#gradingForm' target='_blank' style="font-size:16px" onclick="fillData(<?php echo $data['ID']; ?>);"><i class="fa fa-edit"></i></a></td>
			<td></td>
		</tr>
		<?php
		}
		?>
	</table>
</div>

<form action="" method="post" name="formAddCourses" style="color:#000">
<div id="gradingForm" class="modal fade modal-primary" role="dialog">
  <div class="modal-dialog" style="width:800px">

    <!-- Modal content-->
    <div class="modal-content" style="width:800px">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Grading Form</h4>
      </div>
      <div class="modal-body">
	  <input type="hidden" class="form-control" id="txtStudentID" name="txtStudentID"  />
	 
	  
<!-- /.box-header -------------------------------------------------------------------------------------------------------------------------->
	
	<div class="box-body">
		<div id="show_msg_grading"></div>
		
		<div class="row">
				<div class="col-lg-3">		
					<div class="form-group">
						<label class="control-label small" for="inputSuccess"><i class="fa fa-calendar"></i>&nbsp;Exam Month</label>
						<select name="examMonth" id="EM" class="form-control input-sm" >
							<option></option>
							<option value="Apr - <?php echo date('Y'); ?>">	Apr - <?php echo date('Y'); ?>	</option>
							<option value="Aug - <?php echo date('Y'); ?>">	Aug - <?php echo date('Y'); ?>	</option>
							<option value="Dec - <?php echo date('Y'); ?>">	Dec - <?php echo date('Y'); ?>	</option>
						  </select>
					</div>
				</div>	
				
				<div class="col-lg-3">		
					<div class="form-group">
						<label class="control-label small" for="inputSuccess"><i class="fa fa-calendar"></i>&nbsp;Last Date</label>
					<input id="LD" name="lastDate" type="text" class="form-control input-sm" id="adm_date" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask value="<?php echo $admDate; ?>"  onChange="document.getElementById('eAdmDate').innerHTML ='';">
						
					</div>
				</div>
				
				<div class="col-lg-3">		
					<div class="form-group">
						<label class="control-label small" for="inputSuccess"><i class="fa fa-rupee"></i>&nbsp;Late Fine after Last Date</label>
						<input id="LF" name="lateFine" type="text" id="c_new_pwd" class="form-control input-sm" maxlength=3 onKeyPress="return isNumberKey(event)" />
					</div>
				</div>
				
				<div class="col-lg-3">	
					<div class="form-group"><br>	
						<input name="submit" type="submit" id="submit" value="Update Date" class="btn btn-info"/>
					</div>	
				</div>
			</div> <!-- ./column -->
		</div>
	<!-- /.box-body -->
</div>

</div>
      <div class="modal-footer">
		<button type="button" name="add_gradingFee" class="btn btn-primary" onClick="saveGradingData();">Submit</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</form>

<script>
	function fillData(ID)
	{
		document.getElementById('LF').value=document.getElementById("LF"+ID).innerHTML;
		document.getElementById('LD').value=document.getElementById("LD"+ID).innerHTML;
		document.getElementById('EM').value=document.getElementById("EM"+ID).innerHTML;
	}
</script>














