<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>

<?php
// Reference : http://www.phpcodify.com/export-data-to-excel-in-php-mysql/
include('dbconn.php');
 
$sql= "SELECT name, formNo,	rollNo, batchPreferene, mobile,	whatsapp from student where deleted=0 and dropout=0"; 
$stmt=$connection->prepare($sql);
$stmt->execute();
 
 
$columnHeader ='';
$columnHeader = "Name"."\t"."Reg. No."."\t"."Roll No."."\t"."Batch"."\t"."Mobile"."\t"."WhatsApp No"."\t";
 
 
$setData='';
 
while($rec =$stmt->FETCH(PDO::FETCH_ASSOC))
{
  $rowData = '';
  foreach($rec as $value)
  {
    $value = '"' . $value . '"' . "\t";
    $rowData .= $value;
  }
  $setData .= trim($rowData)."\n";
}
 
 
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=Book record sheet.xls");
header("Pragma: no-cache");
header("Expires: 0");
 
echo ucwords($columnHeader)."\n".$setData."\n";
 
?>