  <?php
 error_reporting(0);
	 $type=$_GET[type];
	 $studID=$_GET[studID];
 include('dbconn.php');
 
 switch($type)
 {
	 case "gradingFrom":
	 	 $sql="select `currentBelt` from `student` where `studID`='$studID'";
		 $result=$connection->query($sql);
		 $data=$result->fetch(PDO::FETCH_ASSOC);
		 $currentBeltName 	= $data[currentBelt];
		 echo $currentBeltName;
	 break;
	 
	  case "gradingTo":
		 $currentBelt=trim($_GET[currentBelt]);
		 $sql="select * from `gradingfee` where `BeltFrom`='$currentBelt'";
		 $result=$connection->query($sql);
		 $data=$result->fetch(PDO::FETCH_ASSOC);
		 $gradingTo1 		= $data[BeltTo];
		 $gradingToFee1 	= $data[fee];
		 
		 $sql="select * from `gradingfee` where `BeltFrom`='$gradingTo1'";
		 $result=$connection->query($sql);
		 $data=$result->fetch(PDO::FETCH_ASSOC);
		 $gradingto2 		= $data[BeltTo];
		 $gradingtoFee2 	= $data[fee];
		 
		 echo "	<option value=''></option>
				<option value='".$gradingTo1."'>".$gradingTo1."</option>
				<option value='".$gradingto2."'>".$gradingto2."</option>";
	 break;
	 
	 case "fee":
		 $currentBelt=trim($_GET[currentBelt]);
		 $sql="select * from `gradingfee` where `BeltFrom`='$currentBelt'";
		 $result=$connection->query($sql);
		 $data=$result->fetch(PDO::FETCH_ASSOC);
		 $gradingTo1 		= $data[BeltTo];
		 $gradingToFee1 	= $data[fee];
		 
		 $sql="select * from `gradingfee` where `BeltFrom`='$gradingTo1'";
		 $result=$connection->query($sql);
		 $data=$result->fetch(PDO::FETCH_ASSOC);
		 $gradingto2 		= $data[BeltTo];
		 $gradingtoFee2 	= $data[fee];
		 
		 echo "	<option value=''></option>
				<option value='".$gradingToFee1."'>".$gradingToFee1."</option>
				<option value='".($gradingToFee1+$gradingtoFee2)."'>".($gradingToFee1+$gradingtoFee2)."</option>";
	 break;
 }
 
 ?>