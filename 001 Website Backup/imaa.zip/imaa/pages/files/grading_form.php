<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>

    <!-- Automatic element centering -->
	<div class="row">
		<div class="" id="searchPart">
			<div class="lockscreen-wrapper">
			  <div class="lockscreen-logo">
				<a href="../../index2.html"><b>IMA A</b>cademy</a>
			  </div>
			  <!-- User name -->
				<center>
					<div class="lockscreen-name" id="studentName">Grading Form</div>
				</center>
			  <!-- START LOCK SCREEN ITEM -->
			  <div class="lockscreen-item">
				<!-- lockscreen image -->
				<div class="lockscreen-image">
				  <img src="../img/logoSmall.jpeg" alt="user image"/>
				</div>
				<!-- /.lockscreen-image -->

				<!-- lockscreen credentials (contains the form) -->
				<form class="lockscreen-credentials" onsubmit="searchStudent();">
				  <div class="input-group">
					<input type="text" class="form-control" placeholder="Admission ID/ Name" id="admissionID" onkeyup="searchStudent(this.value);" />
					
					<div class="input-group-btn">
					  <button class="btn"><i class="fa fa-arrow-right text-muted"></i></button>
					</div>
				  </div>
				</form><!-- /.lockscreen credentials -->

			  </div><!-- /.lockscreen-item -->
			  <div class="help-block text-center">
				Enter Admission ID or Student Name to Search
			  </div>
			  <div class='text-center'>
				<a class='btn btn-aqua btn-xs'  data-toggle='modal' data-target='#externalStudent' target='_blank' style='color:#F60'>Add External Student</a>
				
			  </div>
			  <div class='lockscreen-footer text-center'>
				Copyright &copy; 2017-2018 <b><a href="http://almsaeedstudio.com" class='text-black'>Internation Martial Arts Academy</a></b><br>
				All rights reserved
			  </div>
			</div><!-- /.center -->
		</div>	
		
		<div class="" id="divList">
          <!-- Widget: user widget style 1 -->
            
                
             
          </div>
          <!-- /.widget-user -->
        </div>
	
	</div>

	<script>
	function searchStudent(text)
	{
		  //alert(text);
		  document.getElementById("searchPart").className = "col-md-8";
		  document.getElementById("divList").className = "col-md-4";
		  var xhttp;    
		  if (text == "") {
			document.getElementById("divList").innerHTML = "";
			document.getElementById("searchPart").className = "";
		  document.getElementById("divList").className = "";
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			  document.getElementById("divList").innerHTML = this.responseText;
			}
		  };
		  xhttp.open("GET", "files/searchGradingStudentList.php?info="+text, true);
		  xhttp.send();
  	
	}
	</script>
	
	<script>
	function showStudentDetail(studID)
	{
		  //alert(studID);
		  document.getElementById('txtStudentID').value=studID;
		  var xhttp;    
		  if (studID == "") {
			document.getElementById("divList").innerHTML = "";
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			  document.getElementById("divList").innerHTML = this.responseText;
			}
		  };
		  xhttp.open("GET", "files/showGradingStudentProfile.php?studID="+studID, true);
		  xhttp.send();
		
		//call another function to fill up the text-boxes with other values
		getcurrentBelt(studID);
	}
	
	function getcurrentBelt()
	{
		  //alert(studID);
		  var studID =document.getElementById('txtStudentID').value;
		  var xhttp;    
		  if (studID == "") {
			document.getElementById("gradingFrom").innerHTML = "";
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) 
			{
				var Currentbelt	=	this.responseText;
				document.getElementById("gradingFrom").innerHTML = "<option>"+Currentbelt+"</option>" ;
				getGradingTo(studID, Currentbelt);
			}
		  };
		 //alert(studID);
		  xhttp.open("GET", "files/getcurrentBelt.php?type=gradingFrom&studID="+studID, true);
		  xhttp.send();
			
		
		
		
	}
	
	//this function is used to get grading to belt
	function getGradingTo(studID, Currentbelt)
	{
		//alert(Currentbelt);
		  var xhttp;    
		  if (studID == "") {
			document.getElementById("gradingTo").innerHTML = "";
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) 
			{
				document.getElementById("gradingTo").innerHTML = this.responseText;
				getGradingFEE(studID, Currentbelt);
			}
		  };
		
		  xhttp.open("GET", "files/getcurrentBelt.php?type=gradingTo&studID="+studID+"&currentBelt="+Currentbelt, true);
		  xhttp.send();		
	}
	
	// this function is used to get the fee for belt upgradation
	function getGradingFEE(studID, Currentbelt)
	{
		//alert(Currentbelt);
		  var xhttp;    
		  if (studID == "") {
			document.getElementById("fee").innerHTML = "";
			return;
		  }
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) 
			{
				document.getElementById("fee").innerHTML = this.responseText;
			}
		  };
		
		  xhttp.open("GET", "files/getcurrentBelt.php?type=fee&studID="+studID+"&currentBelt="+Currentbelt, true);
		  xhttp.send();		
	}
	</script>
	
<?php include('Modal_Grading_Form.php'); ?>
<?php include('add_external_student.php'); ?>
<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
