<?php

		/*********************SESSION VARIABLE*********************/
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<!-- =========================================================== -->

<!-- Small boxes (Stat box) -->
<div class="row">
<div class="col-lg-3 col-xs-6">
  <!-- small box -->
  <div class="small-box bg-aqua">
	<div class="inner">
	<?php
	// Count total no. of current students
	 $sqlStudCount="SELECT COUNT(`studID`) as studNo FROM  `student` where dropout=0 and deleted=0";
	 $statementStudCount=$connection->query($sqlStudCount);
	 $dataStudCount=$statementStudCount->fetch(PDO::FETCH_ASSOC);
	?>
	
	  <h3><?php echo $TotalStudent = $dataStudCount[studNo]; ?></h3>
	  <p>Current Students</p>
	</div>
	<div class="icon">
	  <i class="ion ion-person-add"></i>
	</div>
	<a href="main.php?pg=<?php echo base64_encode('reports'); ?>" class="small-box-footer">
	  More info <i class="fa fa-arrow-circle-right"></i>
	</a>
  </div>
</div><!-- ./col -->
<div class="col-lg-3 col-xs-6">
  <!-- small box -->
  <div class="small-box bg-green">
	<div class="inner">
	<?php
	// Count total no. of students paid this month fee
	$thisMonth=date("M-Y");
	 $sqlStudCountFee="SELECT COUNT(`studID`) as studNo FROM  `studentfee` where feeForMonth='$thisMonth' and feeDetailID=9";
	 $statementStudCountFee=$connection->query($sqlStudCountFee);
	 $dataStudCounFee=$statementStudCountFee->fetch(PDO::FETCH_ASSOC);
	?>
	   <h3><?php echo $TotalPaid = $dataStudCounFee[studNo]; ?></h3>
	  <p>Paid Monthly Fee for <?php echo $thisMonth; ?></p>
	</div>
	<div class="icon">
	  <i class="glyphicon glyphicon-check"></i>
	</div>
	<a href="main.php?pg=<?php echo base64_encode('reports');?>" class="small-box-footer">
	  More info <i class="fa fa-arrow-circle-right"></i>
	</a>
  </div>
</div><!-- ./col -->
<div class="col-lg-3 col-xs-6">
  <!-- small box -->
  <div class="small-box bg-yellow">
	<div class="inner">
	<?php
	// Count total no. of students paid this month fee
	$thisMonth=date("M-Y");
	?>
	   <h3><?php echo $TotalStudent - $TotalPaid; ?></h3>
	  <p>Pending Monthly Fee for <?php echo $thisMonth; ?></p>
	</div>
	<div class="icon">
	  <i class="glyphicon glyphicon-thumbs-down"></i>
	</div>
	<a href="main.php?pg=<?php echo base64_encode('reports');?>" class="small-box-footer">
	  More info <i class="fa fa-arrow-circle-right"></i>
	</a>
  </div>
</div><!-- ./col -->
<div class="col-lg-3 col-xs-6">
  <!-- small box -->
  <div class="small-box bg-red">
	<div class="inner">
	<?php
	// Count total no. of students paid this month fee
	$thisMonth=date("M-Y");
	 $sqlStudCountDue="SELECT sum(`dues`) as dues FROM  `studentfee`";
	 $statementStudCountDue=$connection->query($sqlStudCountDue);
	 $dataStudCounDue=$statementStudCountDue->fetch(PDO::FETCH_ASSOC);
	?>
	   <h3>Rs. <?php echo $TotalDue = $dataStudCounDue[dues]; ?></h3>
	  <p>Total Dues By  : <?php echo $thisMonth; ?></p>
	</div>
	<div class="icon">
	  <i class="ion ion-pie-graph"></i>
	</div>
	<a href="main.php?pg=<?php echo base64_encode('reports');?>" class="small-box-footer">
	  More info <i class="fa fa-arrow-circle-right"></i>
	</a>
  </div>
</div><!-- ./col -->
</div><!-- /.row -->

<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->

 <!-- =========================================================== -->

  <div class="row">
	<div class="col-md-3">
	  <div class="box box-primary collapsed-box box-solid">
		<div class="box-header with-border">
		  <h3 class="box-title">Belt Wise List</h3>
		  <div class="box-tools pull-right">
			<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
		  </div><!-- /.box-tools -->
		</div><!-- /.box-header -->
		<div class="box-body">
	   <table class="table table-condensed">
		<tr>
		  <th style="width: 10px">SL</th>
		  <th>Belt</th>
		  <th>Progress</th>
		  <th style="width: 40px">No. of Students</th>
		</tr>
		  <?php
		  $sqlbelt="SELECT COUNT(  `studID` ) as studNo,  `currentBelt` FROM  `student` where dropout=0 and deleted=0 GROUP BY  `currentBelt`";
		  $statementBelt=$connection->query( $sqlbelt);
		  while($dataBelt=$statementBelt->fetch(PDO::FETCH_ASSOC))
		  {
			  ++$slno;
		  ?>
		  	<tr>
                      <td><?php echo $slno; ?></td>
                      <td><?php echo $dataBelt[currentBelt]; ?></td>
                      <td>
                        <div class="progress progress-xs progress-striped active">
                          <div class="progress-bar progress-bar-primary" style="width: <?php echo $dataBelt[studNo]; ?>%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-blue"><?php echo $dataBelt[studNo]; $totalStudent += $dataBelt[studNo]; ?></span></td>
                    </tr>
		  
		  <?php
		  }
		  ?>
		  <tr>
		  	<td colspan="4"><b>Total Students : <?php echo $totalStudent; ?></b></td>
		  </tr>
		  </table>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->
	</div><!-- /.col -->
	
	<!-- =========================================================== -->
	<div class="col-md-3">
	  <div class="box box-success collapsed-box box-solid">
		<div class="box-header with-border">
		  <h3 class="box-title">Batch Wise List</h3>
		  <div class="box-tools pull-right">
			<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
		  </div><!-- /.box-tools -->
		</div><!-- /.box-header -->
		<div class="box-body">
	   <table class="table table-condensed">
		<tr>
		  <th style="width: 10px">SL</th>
		  <th>Batch</th>
		  <th>Progress</th>
		  <th style="width: 40px">No. of Students</th>
		</tr>
		  <?php
		  $sqlBatch="SELECT COUNT(  `studID` ) as studNo,  `batchPreferene` FROM  `student` where dropout=0 and deleted=0 GROUP BY  `batchPreferene`";
		  $statementBatch=$connection->query( $sqlBatch);
		  while($dataBatch=$statementBatch->fetch(PDO::FETCH_ASSOC))
		  {
			  ++$slno2;
		  ?>
		  	<tr>
                      <td><?php echo $slno2; ?></td>
                      <td><?php echo $dataBatch[batchPreferene]; ?></td>
                      <td>
                        <div class="progress progress-xs progress-striped active">
                          <div class="progress-bar progress-bar-success" style="width: <?php echo $dataBatch[studNo]; ?>%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-green"><?php echo $dataBatch[studNo]; $totalStudentBatch += $dataBatch[studNo]; ?></span></td>
                    </tr>
		  
		  <?php
		  }
		  ?>
		  <tr>
		  	<td colspan="4"><b>Total Students : <?php echo $totalStudentBatch; ?></b></td>
		  </tr>
		  </table>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->
	</div><!-- /.col -->
	
	<!-- =========================================================== -->
	
	<!-- =========================================================== -->

 
	<div class="col-md-3">
	  <div class="box box-warning collapsed-box box-solid">
		<div class="box-header with-border">
		  <h3 class="box-title">Gender Wise List</h3>
		  <div class="box-tools pull-right">
			<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
		  </div><!-- /.box-tools -->
		</div><!-- /.box-header -->
		<div class="box-body">
	   <table class="table table-condensed">
		<tr>
		  <th style="width: 10px">SL</th>
		  <th>Gender</th>
		  <th>Progress</th>
		  <th style="width: 40px">No. of Students</th>
		</tr>
		  <?php
		  $sqlGender="SELECT COUNT(  `studID` ) as studNo,  `gender` FROM  `student` where dropout=0 and deleted=0 GROUP BY  `gender`";
		  $statementGender=$connection->query( $sqlGender);
		  while($dataGender=$statementGender->fetch(PDO::FETCH_ASSOC))
		  {
			  ++$slno3;
		  ?>
		  	<tr>
                      <td><?php echo $slno3; ?></td>
                      <td><?php echo $dataGender[gender]; ?></td>
                      <td>
                        <div class="progress progress-xs progress-striped active">
                          <div class="progress-bar progress-bar-warning" style="width: <?php echo $dataGender[studNo]; ?>%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-orange"><?php echo $dataGender[studNo]; $totalGender += $dataGender[studNo]; ?></span></td>
                    </tr>
		  
		  <?php
		  }
		  ?>
		  <tr>
		  	<td colspan="4"><b>Total Students : <?php echo $totalGender; ?></b></td>
		  </tr>
		  </table>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->
	</div><!-- /.col -->
	
	<!-- =========================================================== --><!-- /.col -->
	<div class="col-md-3">
	  <div class="box box-danger collapsed-box box-solid">
		<div class="box-header with-border">
		  <h3 class="box-title">Occupation Wise List</h3>
		  <div class="box-tools pull-right">
			<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
		  </div><!-- /.box-tools -->
		</div><!-- /.box-header -->
		<div class="box-body">
	   <table class="table table-condensed">
		<tr>
		  <th style="width: 10px">SL</th>
		  <th>Occupation</th>
		  <th>Progress</th>
		  <th style="width: 40px">No. of Students</th>
		</tr>
		  <?php
		  $sqlOccupation="SELECT COUNT(`studID`) as studNo,  `occupation` FROM  `student` where dropout=0 and deleted=0 GROUP BY  `occupation`";
		  $statementOccupation=$connection->query( $sqlOccupation);
		  while($dataOccupation=$statementOccupation->fetch(PDO::FETCH_ASSOC))
		  {
			  ++$slno4;
		  ?>
		  	<tr>
                      <td><?php echo $slno4; ?></td>
                      <td><?php echo ($dataOccupation[occupation]=='')?'None':$dataOccupation[occupation]; ?></td>
                      <td>
                        <div class="progress progress-xs progress-striped active">
                          <div class="progress-bar progress-bar-danger" style="width: <?php echo $dataOccupation[studNo]; ?>%"></div>
                        </div>
                      </td>
                      <td><span class="badge bg-red"><?php $totalOccupation += $dataOccupation[studNo];  echo $dataOccupation[studNo];  ?></span></td>
                    </tr>
		  
		  <?php
		  }
		  ?>
		  <tr>
		  	<td colspan="4"><b>Total Students : <?php echo $totalOccupation; ?></b></td>
		  </tr>
		  </table>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->
	</div>
  </div><!-- /.row -->

<!-- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx -->	