<?php
	session_destroy();
	unset($_SESSION['userID']);
	unset($_SESSION['sessionUserName']);
	unset($_SESSION['sessionUserType']);
	unset($_SESSION['sessionUserImage']);
	unset($_SESSION['sessionUserDesignation']);
	unset($_SESSION['sessionUserTime']);
	echo "<script>document.location.href='../../index.php'</script>";
?>