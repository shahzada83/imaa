<?php

		/*********************SESSION VARIABLE*********************/
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
		//*********************SESSION VARIABLE*********************/
?>
<?php

/*
if($_SESSION['sessionUserType']=='admin')
{
		$menu=array(
		
		'student'=>array('admission','view students', 'reports', 'documents'),
		'enquiry'=>array('walk-In', 'promotional SMS', 'Website Enquiry'),
		'administrator'=>array('add user', 'view user', 'create report', 'add notice', 'add download', 'sms record', 'Fee Receipt'),
		'company'=>array('add company', 'view company', 'add course', 'view course'),
		);

}

else
*/
{
	
		$menu=array(
		
		'student'=>array('admission','view students', 'reports' ),
		'grading' => array('grading form', 'report and result'),
		'administrator'=>array('view user', 'view fee receipt'),
		'configuration'=>array('add user', 'add fee head', 'add product', 'create/ modify batch', 'backup database', 'exam date'),
		'stock'=>array('add stock', 'view stock')
		);

}

?>