<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<div class="box box-solid box-flat" >
	<div class="box-header" style="border-bottom:#666 1px solid">
	  <h4 class="box-title" style="color:#C00"><i class="fa fa-calendar-o"></i>  <b>Monthly Fee</b> </h4>
	</div><!-- /.box-header -->
	<div class="box-body">
	<h5 style="color:#360"><input type="checkbox" class="flat-red" name="checkHeadMonthlyFee" id="checkHeadMonthlyFee2" value="1" style="background-color:#FC9" onclick="calculateMonthlyFee();"/> Check to save monthly Fee 
	&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; 
	<span style="font-size:20px; color:#C00;" id="errmsg"></span></h5>
	<br />
	<div class="row">
			<div class="col-md-2" id="feeForMonth">
				<div class="form-group">
					<?php 
						 //$sqlMonth="SELECT `feeForMonth` from `studentfee` where `studID`='$studID' and `feeDetailID`=9   and feeForMonth !='' order by `feeID` DESC, `amount` DESC LIMIT 1";
						 $sqlMonth="SELECT `feeTill` as `feeForMonth` from `monthlyfeesummery` where `studID`='$studID' and `feeDetailID`='9' ORDER by mfsID DESC Limit 1";
					?>
					<label class="label_font"><i class="fa fa-calendar"></i> Fee from</label>
					
					<select class="form-control input-sm" name="feeFrom">
					<?php
//Find out the monthly fee not paid by the student, show the Month and Year in the control  accordangly
//If $fieldFeeDetail[head] == 'Monthly Fee' then the student has not paid any month fee, in this case find out the ADMISSION Month of the student
					
					$statmentMonth = $connection -> query($sqlMonth);
					$statmentMonth -> execute();
					if($statmentMonth -> rowCount()) // if row is returned from database/ table
					{
						$time = $statmentMonth->fetch(PDO::FETCH_ASSOC);	
						//date("M - Y", strtotime("+1 month", $time));
						$feeFrom = IncrimentMonth($time[feeForMonth], 1); // IncrimentMonth() is defined in API.php
					}
					else
					{
						$feeFrom=date("M-Y",strtotime($studentTable['admDate']));
					}
					?>		
					<option><?php echo $feeFrom; ?></option>
							
					</select>
					<span class="error" id="ereceiptNo"></span>
				</div>
			</div>
			
			<div class="col-md-2" id="feeForMonth">
				<div class="form-group">
				
					<label class="label_font"><i class="fa fa-calendar"></i> 
					<?php
						 $feeFromCal= "1-" . $feeFrom ;
						 $date1=date("Y-m-d", strtotime($feeFromCal));
						 $date2=date("Y-m-d");
						 $monthDiff= month_difference($date1, $date2);
					?>
					Fee Till  &nbsp;&nbsp;&nbsp;&nbsp;<span class="pull-right" id="totFee2" style="color:#FF0000"></span></label>
					<select class="form-control input-sm" name="feeTill" onchange="calculateMonthlyFee()" onclick="calculateMonthlyFee()"  id="feeTill">
					<?php
					// Show 12 months from the $feeFrom variable
					// if student has not paid the fee for more than 12 months than
						
					//*************************************************************	
					for($i=0; $i< abs($monthDiff)+12; $i++)
					{
					$final = IncrimentMonth($feeFrom, $i); // IncrimentMonth() is defined in API.php
					
					?>
					<option value="<?php echo $final; ?>" <?php if($final==date("M-Y")){?> selected="selected"<?php } ?>>
						( <?php echo $i+1; ?> ) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $final; ?>
					</option>
					<?php			
						$months .= $final .";"; 
						// Store the months in the array
						
					}
					
					?>
					</select>
					<input type="hidden" name="months" value="<?php echo $months; ?>" />
					<span class="error" id="ereceiptNo"></span>
				</div>
			</div>
		
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Fee Per Month</label>
					
						<select class="form-control input-sm" name="monthlyFee" id="monthlyFee" onchange="calculateMonthlyFee();" >
						<?php
						$newfee = end(explode("-",$feeFrom));
						if( $newfee >= 2017) {$newfee = 500;}
						else if( $newfee >= 2018) {$newfee = 600;}
						else if( $newfee >= 2019) {$newfee = 700;}
						$sqlMonthlyFee="SELECT `amount` from `feedetail` where `feeDetailID`=9";
						$stmtMonthlyFee=$connection->query($sqlMonthlyFee);
						$dataMonthlyfee=$stmtMonthlyFee->fetch(PDO::FETCH_ASSOC);
						$amt=explode(",",$dataMonthlyfee[amount]);
						foreach($amt as $amount)
						{
						?>
							<option <?php if($newfee == $amount){?> selected="selected" <?php } ?>><?php echo $amount; ?></option>
						<?php
						}
						?>	
						</select>
					<span class="error" id="eamount"></span>
				</div>
			</div>
		
			<div class="col-md-1">
				<div class="form-group">
					<?php
					//Calculate latefine as per the $monthDiff value
					// Formula (5x25) + (4x25) + (3x25) + (2x25) + (1x25) , where 5 is total due month and 25 is fine

					$fine=25; //Rs. 25
					$latefine=0;
					$date1=$feeFrom;
					$date2=date("Y-m-d");
					$monthDiff= month_difference($date1, $date2);
					
					
					for($i=$monthDiff; $i>=0; $i--) // $monthDiff value getting from <label>Fee Till</label>
					{
							$latefine += $i*$fine;
							$latefineString .=$i*$fine.";";
					}
					?>
					<label class="label_font">Late_Fine<span style="font-size:12; color:#C00" id="lateFineNoMonths">(<?php echo $monthDiff; ?>)</span></label>
					<input class="form-control input-sm" type="text" name="lateFine" value="<?php echo $latefine; ?>"  id="lateFine" onkeyup="calculateMonthlyFee()" >
					<input class="form-control input-sm" type="hidden" name="lateFineString" value="<?php echo $latefineString; ?>"  id="lateFineString" onkeyup="calculateMonthlyFee()">
				</div>
			</div>
			
			<div class="col-md-1">
				<div class="form-group">
					<label class="label_font">Discount</label>
					<input class="form-control input-sm" type="text" name="monthlyDiscount" value="" onkeyup="calculateMonthlyFee();"  onkeypress="return isNumberKey(event)" maxlength="6"  id="monthlyDiscount">
					<span class="error" id="ediscount"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font" style="color:#C00">(<i class="fa fa-rupee"></i>) Dues </label>
					<input class="form-control input-sm" type="text" name="monthlyDues" onkeyup="calculateMonthlyFee();" id="monthlyDues"   style="background-color:#FC9; color:#000">
					<span class="error" id="etotalFee"></span>
				</div>
			</div>
			
			<div class="col-md-2">
				<div class="form-group">
					<label class="label_font">Total Fee Received(<i class="fa fa-rupee"></i>)</label>
					<input class="form-control input-sm" type="text" name="TotalMonthlyFee"  readonly="readonly" id="TotalMonthlyFee"  >
					<span class="error" id="etotalFee"></span>
				</div>
			</div>
		
		</div>	
	
	</div><!-- /.box-body -->
 </div><!-- /.box -->