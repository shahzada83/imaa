issue_id_card.php, issue_karate_dress.php, issue_track_suite.php are all same files, but due to conflict in function names error, it has been defined in different file.

and is replica of issue_material.php