<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
	<link href="DataTable/bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/buttons.bootstrap.min.css" rel="stylesheet" type="text/css" >
</head>

<body>
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
                <th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
                <th>Adm.Date</th>
                <th>Phone</th>
                <th>Total Months as on <br /><?php echo date("M-Y"); ?></th>
				<th>Paid (Months)</th>
				<th>DUE (Months)</th>
				
            </tr>
        </thead>
        <tfoot>	
            <tr style="font-size:12px;">
                <th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
                <th>Adm.Date</th>
                <th>Phone</th>
                <th>Total Months as on <br /> <?php echo date("M-Y"); ?></th>
				<th>Paid (Months)</th>
				<th>DUE (Months)</th>
				
            </tr>
        </tfoot>
        <tbody>
<?php
include('../dbconn.php');
include('../API.php');

//***********************************************************************************************************************************************//
$sqlSTUDENT="SELECT * from student WHERE dropout=0 and deleted=0 and passout=0";
$statementSTUDENT = $connection->query($sqlSTUDENT);		
while($dataSTUDENT=$statementSTUDENT->fetch(PDO::FETCH_ASSOC))
{
	// Then find out admission fee date of the student from studentfee Table
	// This will help to determine the no. of monthy fee to be paid by the student till date
	
	$studID=$dataSTUDENT[studID];
	$sqlAdmDate="SELECT COUNT(feeForMonth) as TotalMonthPaid from `studentfee` where `studID`='$studID' and feeDetailID='9'"; // 9 for Monthly Fee, from feedetail Table
	$statementAdmDate=$connection->query($sqlAdmDate);
	$dataAdmDate=$statementAdmDate->fetch(PDO::FETCH_ASSOC);
	$TotalMonthPaid=$dataAdmDate[TotalMonthPaid]-1;
	
	$AdmissionDate = $dataSTUDENT[admDate];
	$thisMonth=date("Y-m-d");
	$TotalMonthExpected= month_difference($AdmissionDate, $thisMonth);
	
	if(($TotalMonthExpected-$TotalMonthPaid)<=0)
	{
		
	//elseif(($TotalMonthPaid -$TotalMonthExpected)>0 && $searchReport['case']=='0')
	
//***********************************************************************************************************************************************//	
?>			
            <tr style="font-size:12px; text-decoration:none; font-weight:100">
                <td>
					<a href="../../main.php?pg=<?php echo base64_encode('profile');?>&admID=<?php echo $dataSTUDENT[admID];?>" target="_blank">
						<?php echo ucwords(strtolower($dataSTUDENT['name'])); ?>
					</a>	
				</td>
                <td><?php echo $dataSTUDENT['batchPreferene'];?></td>
                <td><?php echo $dataSTUDENT['rollNo'];?></td>
                <td><?php echo format_date($dataSTUDENT['admDate']); ?></td>
                <td><?php echo $dataSTUDENT['mobile'];	?></td>
                <td><b><?php echo $TotalMonthExpected; ?></b></td>
				<td style="color:#009966"><b><?php echo $TotalMonthPaid; ?> </b></td>
				<td style="color:#FF0000"><b><?php echo $dueMonths =$TotalMonthExpected - ($TotalMonthPaid); ?></b></td>
				
            </tr>
<?php
	}
}
?>			
        </tbody>
    </table>
</body>


<script src="DataTable/jquery-1.12.4.js" type="text/javascript"></script>
<script src="DataTable/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/jszip.min.js" type="text/javascript"></script>
<script src="DataTable/pdfmake.min.js" type="text/javascript"></script>
<script src="DataTable/vfs_fonts.js" type="text/javascript"></script>
<script src="DataTable/buttons.html5.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.print.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.colVis.min.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
} );
</script>
</html>