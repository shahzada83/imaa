<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
	<link href="DataTable/bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/buttons.bootstrap.min.css" rel="stylesheet" type="text/css" >
</head>

<body>
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
                <th>Reg. No.</th>
				<th>Name</th>
                <th>Batch</th>
				
				<th>Date</th>
                <!--<th>Total Months as on <br /><?php echo date("M-Y"); ?></th>
				<th>Paid (Months)</th>-->
				<th>Form No</th>
				<th>Exam Month</th>
				<th>Grading From</th>
				<th>Grading To</th>
				<th>Fee</th>
				<th>Late Fee</th>
				<th>Total</th>
				<th>Paid</th>
				<th>Due</th>
				<th>RESULT</th>
            </tr>
        </thead>
        <tfoot>	
            <tr style="font-size:12px;">
                <th>Reg. No.</th>
				<th>Name</th>
                <th>Batch</th>
				
				<th>Date</th>
                <!--<th>Total Months as on <br /><?php echo date("M-Y"); ?></th>
				<th>Paid (Months)</th>-->
				<th>Form No</th>
				<th>Exam Month</th>
				<th>Grading From</th>
				<th>Grading To</th>
				<th>Fee</th>
				<th>Late Fee</th>
				<th>Total</th>
				<th>Paid</th>
				<th>Due</th>
				<th>RESULT</th>
            </tr>
        </tfoot>
        <tbody>
<?php
include('../dbconn.php');
include('../API.php');
$examMonth=$_GET[examMonth];

//***********************************************************************************************************************************************//
$sqlExam="SELECT * from exam WHERE examMonth='$examMonth'";
$statementExam = $connection->query($sqlExam);		
while($dataExam=$statementExam->fetch(PDO::FETCH_ASSOC))
{
	$sqlSTUDENT="SELECT * from student WHERE studID='$dataExam[studID]'";
	$statementSTUDENT = $connection->query($sqlSTUDENT);		
	$dataSTUDENT=$statementSTUDENT->fetch(PDO::FETCH_ASSOC);
?>			
            <tr style="font-size:12px; text-decoration:none; font-weight:100">
                <td><span title="Adm ID/ Adm Month Year/ Adm Form No"> <?php echo $dataSTUDENT['formNo'];?>/ <?php echo date("my",strtotime($dataSTUDENT['admDate']));?>/ <?php echo $dataSTUDENT['formNoActual'];?></span></td>
				<td>
					<a href="../../main.php?pg=<?php echo base64_encode('profile'); ?>&admID=<?php echo $dataSTUDENT[admID];?>" target="_blank">
						<?php echo ucwords(strtolower($dataSTUDENT['name'])); ?>
					</a>	
				</td>
                <td><?php echo $dataSTUDENT['batchPreferene'];?>/ <b>Roll: <?php echo $dataSTUDENT['rollNo'];?></b></td>
                <td><?php echo format_date($dataExam['FormDate']);	?></td>
				<td><?php echo $dataExam['FormNo'];	?></td>
				<td><?php echo $dataExam['examMonth'];	?></td>
				<td><?php echo $dataExam['gradingFrom'];	?></td>
				<td><?php echo $dataExam['gradingTo'];	?></td>
				<td><?php echo $dataExam['fee'];	?></td>
				<td><?php echo $dataExam['lateFee'];	?></td>
				<td><?php echo $dataExam['lateFee']+$dataExam['fee'];	?></td>
				<td><?php echo $dataExam['totalReceived'];	?></td>
				<td><?php echo $dataExam['due'];	?></td>
				<td><?php echo $dataExam['result'];	?></td>
            </tr>
<?php
	
}
?>			
        </tbody>
    </table>
</body>


<script src="DataTable/jquery-1.12.4.js" type="text/javascript"></script>
<script src="DataTable/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/jszip.min.js" type="text/javascript"></script>
<script src="DataTable/pdfmake.min.js" type="text/javascript"></script>
<script src="DataTable/vfs_fonts.js" type="text/javascript"></script>
<script src="DataTable/buttons.html5.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.print.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.colVis.min.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
} );
</script>
</html>