<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
	<link href="DataTable/bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/buttons.bootstrap.min.css" rel="stylesheet" type="text/css" >
</head>

<body>
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
                <th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
                <th>Pay Date</th>
                <th>Phone</th>
                <th>Dues (Rs.)</th>
				<th>Item</th>
				<th>Status</th>
				
            </tr>
        </thead>
        <tfoot>	
            <tr style="font-size:12px;">
                <th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
                <th>Pay Date</th>
                <th>Phone</th>
                <th>Dues (Rs.)</th>
				<th>Item</th>
				<th>Status</th>
				
            </tr>
        </tfoot>
        <tbody>
<?php
include('../dbconn.php');
include('../API.php');

$material=$_GET[material];
if($material==6)
{
	$sqlHead="SELECT `head` from `feedetail` where `feeDetailID`='$material'";
	$stmtHead=$connection->query($sqlHead);
	$dataHead=$stmtHead->fetch(PDO::FETCH_ASSOC);
	$headName = ($dataHead[head]=='Admission Fee')?'ID CARD':$material;
}
else
{
	$headName = $material;
}
//***********************************************************************************************************************************************//
if($material==6)// ID Card
{
	$sqlSTUDENT="SELECT `student`.*, `studentfee`.`feeDetailID`, `studentfee`.`payDate`, `studentfee`.`dues` from `student`, `studentfee` where `student`.`studID`=`studentfee`.`studID` and `studentfee`.`feeDetailID` ='$material' and `studentfee`.`stockIssueID`=0 ORDER by `studentfee`.`payDate`"; // 9 for Monthly Fee, from feedetail Table
}
else // Other Material
{
	$sqlSTUDENT="SELECT `student`.*, `studentfee`.`feeDetailID`, `studentfee`.`payDate`, `studentfee`.`dues` from `student`, `studentfee` where `student`.`studID`=`studentfee`.`studID` and `studentfee`.`itemName` ='$material' and `studentfee`.`stockIssueID`=0 ORDER by `studentfee`.`payDate`"; 
}
$statementSTUDENT = $connection->query($sqlSTUDENT);
while($dataSTUDENT=$statementSTUDENT->fetch(PDO::FETCH_ASSOC))
{
	
//***********************************************************************************************************************************************//	
?>			
            <tr style="font-size:12px; text-decoration:none; font-weight:100">
                <td>
					<a href="../../main.php?pg=<?php echo base64_encode('profile');?>&admID=<?php echo $dataSTUDENT[admID];?>" target="_blank">
						<?php echo ucwords(strtolower($dataSTUDENT['name'])); ?>
					</a>	
				</td>
                <td><?php echo $dataSTUDENT['batchPreferene'];?></td>
                <td><?php echo $dataSTUDENT['rollNo'];?></td>
                <td><?php echo format_date($dataSTUDENT['payDate']); ?></td>
                <td><?php echo $dataSTUDENT['mobile'];	?></td>
				<td style="color:#FF0000"><b>Rs. <?php echo $dataSTUDENT['dues']; ?></b></td>
                <td><?php echo $headName; //$dataSTUDENT['feeDetailID'];	?></td>
				<td style="color:#FF0000">PENDING</td>
				
				
            </tr>
<?php
}
?>			
        </tbody>
    </table>
</body>

<script src="DataTable/jquery-1.12.4.js" type="text/javascript"></script>
<script src="DataTable/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/jszip.min.js" type="text/javascript"></script>
<script src="DataTable/pdfmake.min.js" type="text/javascript"></script>
<script src="DataTable/vfs_fonts.js" type="text/javascript"></script>
<script src="DataTable/buttons.html5.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.print.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.colVis.min.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
} );
</script>
</html>