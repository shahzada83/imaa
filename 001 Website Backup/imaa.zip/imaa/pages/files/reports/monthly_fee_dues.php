<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
	<link href="DataTable/bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/buttons.bootstrap.min.css" rel="stylesheet" type="text/css" >
</head>

<body>
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
                <th>Adm ID</th>
				<th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
				<th>Phone</th>
                
				<th>Head</th>
                <!--<th>Total Months as on <br /><?php echo date("M-Y"); ?></th>
				<th>Paid (Months)</th>-->
				<th>DUE (Months)</th>
				<th>Dues Months</th>
				<th>Dues Amount (Rs)</th>
				<th>Late Fine (Rs)</th>
				<th>Total<br> Dues (Rs)</th>
				
            </tr>
        </thead>
        <tfoot>	
            <tr style="font-size:12px;">
                <th>Adm ID</th>
				<th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
				<th>Phone</th>
                
				<th>Head</th>
                <!--<th>Total Months as on <br /><?php echo date("M-Y"); ?></th>
				<th>Paid (Months)</th>-->
				<th>DUE (Months)</th>
				<th>Dues Months</th>
				<th>Dues Amount (Rs)</th>
				<th>Late Fine (Rs)</th>
				<th>Total<br> Dues (Rs)</th>
				
            </tr>
        </tfoot>
        <tbody>
<?php
include('../dbconn.php');
include('../API.php');

//***********************************************************************************************************************************************//
$sqlSTUDENT="SELECT * from student WHERE dropout=0 and deleted=0 and passout=0";
$statementSTUDENT = $connection->query($sqlSTUDENT);		
while($dataSTUDENT=$statementSTUDENT->fetch(PDO::FETCH_ASSOC))
{
	// Then find out admission fee date of the student from studentfee Table
	// This will help to determine the no. of monthy fee to be paid by the student till date
	
	$studID=$dataSTUDENT[studID];
	$sqlAdmDate="SELECT COUNT(feeForMonth) as TotalMonthPaid from `studentfee` where `studID`='$studID' and feeDetailID='9'"; // 9 for Monthly Fee, from feedetail Table
	$statementAdmDate=$connection->query($sqlAdmDate);
	$dataAdmDate=$statementAdmDate->fetch(PDO::FETCH_ASSOC);
	$TotalMonthPaid=$dataAdmDate[TotalMonthPaid];
	
	$AdmissionDate = $dataSTUDENT[admDate];
	$thisMonth=date("Y-m-d");
	$TotalMonthExpected= month_difference($AdmissionDate, $thisMonth)+1;
	
	if((abs($TotalMonthExpected) - abs($TotalMonthPaid))<=0)
	{
		continue;
	}
	//elseif(($TotalMonthPaid -$TotalMonthExpected)>0 && $searchReport['case']=='0')
	{
//***********************************************************************************************************************************************//	
?>			
            <tr style="font-size:12px; text-decoration:none; font-weight:100">
                <td><?php echo $dataSTUDENT['formNo'];?></td>
				<td width="200px">
					<a href="../../main.php?pg=<?php echo base64_encode('profile');?>&admID=<?php echo $dataSTUDENT[admID];?>" target="_blank">
						<?php echo ucwords(strtolower($dataSTUDENT['name'])); ?>
					</a>	
				</td>
                <td><?php echo $dataSTUDENT['batchPreferene'];?></td>
                <td><?php echo $dataSTUDENT['rollNo'];?></td>
                
                <td><?php echo $dataSTUDENT['mobile'];	?></td>
				<td width="100px">Monthly Fee</td>
				<?php
				/*
                <td><b><?php echo $TotalMonthExpected; ?></b></td>
				<td style="color:#009966"><b><?php echo $TotalMonthPaid; ?> </b></td>
				*/
				?>
				<td><b style="color:#FF0000"><?php echo $dueMonths =$TotalMonthExpected - ($TotalMonthPaid); ?></b></td>
				
				<td width="200px">
				<?php
					//Dues Months
					$sqlLastMonthPaid="select `feeForMonth` from studentfee where `studID`='$studID' and `feeDetailID`=9 ORDER BY feeID DESC Limit 1";
					$stmtLastMonthPaid=$connection->query($sqlLastMonthPaid);
					$dataLastMonthPaid=$stmtLastMonthPaid->fetch(PDO::FETCH_ASSOC);
					$lastMonthPaid=$dataLastMonthPaid[feeForMonth];
					if($lastMonthPaid)
					{
						echo "<b>" . IncrimentMonth($lastMonthPaid, 1) . "</b>" . "&nbsp&nbsp&nbsp&nbsp Till &nbsp&nbsp&nbsp&nbsp" . "<b>". date("M-Y") . "</b>";
					}
					else
					{
						echo "<b>" . date("M-Y", strtotime($AdmissionDate)) . "</b>" . "&nbsp&nbsp&nbsp&nbsp Till &nbsp&nbsp&nbsp&nbsp" . "<b>". date("M-Y") . "</b>";
					}	
				?>
				</td>
				
				<td>
				<?php
					$date1=date("Y-m-d", strtotime($lastMonthPaid));
					$date2=date("Y-m-d");
					$TotalmonthDiff= month_difference($date1, $date2); // Total Month till date
					if($TotalmonthDiff==577)// getting 577 value when one month is due, hence the code
					{
						 $TotalmonthDiff=1;
						 $MonthTotalTill_31_12_2017=0;
					}
					else
					{
						//echo $TotalmonthDiff;
						$MonthTotalTill_31_12_2017 = month_difference($date1, '2017-12-31'); // Total Months till 31.12.2017
						if($MonthTotalTill_31_12_2017 <=0)
						{
							$MonthTotalTill_31_12_2017=0;
						}
						
						//echo $TotalmonthDiff;
						$MonthTotalTill_31_12_2018 = month_difference($date1, '2018-12-31'); // Total Months till 31.12.2017
						if($MonthTotalTill_31_12_2018 <=0)
						{
							$MonthTotalTill_31_12_2018=0;
						}
					}
					
					//till 31.12.2017 the fee was 500 then after the fee is 600
					$TotalDueAmount=abs($MonthTotalTill_31_12_2017) * 500 + ($dueMonths - $MonthTotalTill_31_12_2017)*600;
					$TotalDueAmount=abs($MonthTotalTill_31_12_2018) * 600 + ($dueMonths - $MonthTotalTill_31_12_2018)*700;
					
				?>
				<span title="Rs. 600 x <?php echo $MonthTotalTill_31_12_2018; ?> Months (Total Months till 31-Dec-2018) + Rs. 700 x <?php echo $dueMonths - $MonthTotalTill_31_12_2018; ?> (Total Months from 01-Jan-2019 till <?php echo date("M-Y"); ?> )">  <?php echo abs($TotalDueAmount); ?> </span>
				</td>
				<td>
					<?php
					//Calculate latefine as per the $monthDiff value
					// Formula (5x25) + (4x25) + (3x25) + (2x25) + (1x25) , where 5 is total due month and 25 is fine

					$fine=25; //Rs. 25
					$latefine=0;
					
					for($i=$dueMonths-1; $i>=1; $i--) // $TotalmonthDiff-1 (-1 to exclude current month)
					{
							$latefine += $i*$fine;
					}
					echo $latefine;
					?>
				</td>
				<td>
					<?php
					echo $TotalDueAmount+$latefine;
					?>
				</td>
				
            </tr>
<?php
	}
}
?>			
        </tbody>
    </table>
</body>


<script src="DataTable/jquery-1.12.4.js" type="text/javascript"></script>
<script src="DataTable/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/jszip.min.js" type="text/javascript"></script>
<script src="DataTable/pdfmake.min.js" type="text/javascript"></script>
<script src="DataTable/vfs_fonts.js" type="text/javascript"></script>
<script src="DataTable/buttons.html5.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.print.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.colVis.min.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
} );
</script>
</html>