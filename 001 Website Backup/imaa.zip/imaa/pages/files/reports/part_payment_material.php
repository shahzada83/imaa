<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
	<link href="DataTable/bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" >
	<link href="DataTable/buttons.bootstrap.min.css" rel="stylesheet" type="text/css" >
</head>

<body>
<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr style="font-size:12px;">
				<th>AdmID</th>
                <th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
				<th>Belt</th>
				<th>Phone</th>
                <th>Pay_Date</th>
                <th>Receipt</th>
				<th>Item</th>
				<th>Price</th>	
				<th>Discount</th>
				<th>Paid</th>
				<th>Due_Amt</th>
            </tr>
        </thead>
        <tfoot>	
            <tr style="font-size:12px;">
				<th>AdmID</th>
                <th>Name</th>
                <th>Batch</th>
                <th>RollNo</th>
				<th>Belt</th>
				<th>Phone</th>
                <th>Pay_Date</th>
                <th>Receipt</th>
				<th>Item</th>
				<th>Price</th>	
				<th>Discount</th>
				<th>Paid</th>
				<th>Due_Amt</th>
            </tr>
        </tfoot>
        <tbody>
<?php
include('../dbconn.php');
include('../API.php');

//***********************************************************************************************************************************************//
//$sqlSTUDENT="SELECT  `monthlyfeesummery`.* ,  `student`.`admID`, `student`.`name` ,  `student`.`rollNo` ,  `student`.`currentBelt` ,  `student`.`mobile` ,  `student`.`whatsapp` ,  //`student`.`batchPreferene` 
//FROM  `monthlyfeesummery` ,  `student`
//WHERE  `student`.`studID` =  `monthlyfeesummery`.`studID` AND `monthlyfeesummery`.`dues`>0
//";

$sqlSTUDENT = "SELECT `studentfee`.*, SUM(`studentfee`.`dues`) as sumDues, 
				`student`.`admID`, `student`.`formNo`, `student`.`name` ,  `student`.`rollNo` ,  `student`.`currentBelt` ,  `student`.`mobile` ,  `student`.`whatsapp` ,  `student`.`batchPreferene` 
				FROM  `studentfee`, `student` 
				WHERE  
				`studentfee`.studID= `student`.studID and 
				`studentfee`.`dues` >0 AND (`studentfee`.`feeDetailID` != 9 OR  `studentfee`.`feeDetailID` != 6) GROUP BY  `studentfee`.`receiptNo`" ;

$statementSTUDENT = $connection->query($sqlSTUDENT);
while($dataSTUDENT=$statementSTUDENT->fetch(PDO::FETCH_ASSOC))
{
	
//***********************************************************************************************************************************************//	
?>			
            <tr style="font-size:12px; text-decoration:none; font-weight:100">
                <td><?php echo $dataSTUDENT['formNo'];?></td>
				<td>
					<a href="../../main.php?pg=<?php echo base64_encode('profile');?>&admID=<?php echo $dataSTUDENT[admID];?>" target="_blank">
						<?php echo ucwords(strtolower($dataSTUDENT['name'])); ?>
					</a>	
				</td>
                <td><?php echo $dataSTUDENT['batchPreferene'];?></td>
                <td><?php echo $dataSTUDENT['rollNo'];?></td>
				<td><?php echo $dataSTUDENT['currentBelt'];?></td>
				<td><?php echo $dataSTUDENT['mobile'];	?></td>
                <td><?php echo format_date($dataSTUDENT['payDate']); ?></td>
                <td><?php echo $dataSTUDENT['receiptNo'];	?></td>
				<td><?php echo $dataSTUDENT['itemName'];	?></td>
				<td><?php echo $dataSTUDENT['amount'];	?></td>
				<td><?php echo $dataSTUDENT['discount'];	?></td>
				<td><?php echo $dataSTUDENT['totalFeeReceived'];	?></td>
				
				<td style="color:#FF0000"><strong>Rs. <?php echo ceil($dataSTUDENT['sumDues']);	?></strong></td>
            </tr>
<?php
}
?>			
        </tbody>
    </table>
</body>


<script src="DataTable/jquery-1.12.4.js" type="text/javascript"></script>
<script src="DataTable/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.bootstrap.min.js" type="text/javascript"></script>
<script src="DataTable/jszip.min.js" type="text/javascript"></script>
<script src="DataTable/pdfmake.min.js" type="text/javascript"></script>
<script src="DataTable/vfs_fonts.js" type="text/javascript"></script>
<script src="DataTable/buttons.html5.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.print.min.js" type="text/javascript"></script>
<script src="DataTable/buttons.colVis.min.js" type="text/javascript"></script>
<script>
$(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    } );
 
    table.buttons().container()
        .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
} );
</script>
</html>