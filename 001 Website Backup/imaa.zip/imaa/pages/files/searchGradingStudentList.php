<?php
include('dbconn.php');
$search = $_GET[info];

$sqlStudent="SELECT `studID`, `formNo`, `rollNo`, `currentBelt`, `name`, `photo`, `gender`, `batchPreferene`, `admID` from student
where `formNo` LIKE '%$search%' or  `name` LIKE '%$search%'  LIMIT 6";

$statementStudent = $connection -> query($sqlStudent);
$statementStudent->execute();
$string1="
		<div class='box-footer no-padding'>
            <ul class='nav nav-stacked'>
		";

$string3="
			</ul>
        </div>
		";
while($dataStudentFee = $statementStudent->fetch(PDO::FETCH_ASSOC))
{
	//echo $dataStudentFee[name]."<br>";
	$studImage 	=	($dataStudentFee[photo]=='')?'no_image.png':$dataStudentFee[photo];
	
	$string2 .=	"
					<li class='bg-info' align='left'>
						<a href='#' class='' onclick='showStudentDetail($dataStudentFee[studID])'>
							<div class='row'>
								<div class='col-md-4'>
									<img class='img-circle' src='001_student_photo/". $studImage . "' alt='' height='80' width='80'>
								</div>
								<div class='col-md-8'>	
									
										<b>".  ucwords(strtolower($dataStudentFee[name]))."</b><br>
										Admission ID : " . $dataStudentFee[formNo] ."<br>
										Current Belt : " . $dataStudentFee[currentBelt] ."<br>
										Batch : " . $dataStudentFee[batchPreferene] . " -   Roll No. : " . $dataStudentFee[rollNo] ."<br>
									
								</div>
							</div>
						</a>		
					</li>
				";
}
echo $string1 . $string2 . $string3;
?>