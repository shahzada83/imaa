<?php
include('dbconn.php');
include('API.php');
include('database.php');
//echo 'HELLO';
$studID=$_GET[studID];
$sqlStudent="SELECT `student`.* from `student` where student.studID='$studID'";	

$statementStudent = $connection -> query($sqlStudent);
$statementStudent->execute();
$dataStudent=$statementStudent->fetch(PDO::FETCH_ASSOC);
//print_r($dataStudent);
	
	// Student Image
	
	$studImage 	=	($dataStudent[photo]=='')?'no_image.png':$dataStudent[photo];
	//echo $studImage;
	//echo $imgPath="001_student_photo/$studImage"; 
	
	//-------------
//---------------------------------OTHER FEE DUE-----------------------------------------
// ************************************************** LOOP BEGINS **************************************************
				// Show all those Fee Head whose payment has not been paid by the student
				$sqlfeeDetail="SELECT `type`, `feeDetailID`, `head`, `amount` FROM `feedetail` FD WHERE NOT EXISTS (SELECT  `feeDetailID`, `feeForMonth`  FROM `studentfee` SF WHERE FD.`feeDetailID` = SF.`feeDetailID` AND FD.`feeDetailID` !=9 AND SF.`studID`='$studID'  ORDER BY SF.`feeID` DESC)";
				
				$statementFeeDetail=$connection->query($sqlfeeDetail);
				$statementFeeDetail->execute();
				
				while($fieldFeeDetail=$statementFeeDetail->fetch(PDO::FETCH_ASSOC))
				{
						// If fee for material is due prepare the string to display to the user
						if($fieldFeeDetail[type]=='Material')
						{
							$material .= $fieldFeeDetail[head] . ", ";	
						}
						// If fee for service is due prepare the string to display to the user						
						elseif($fieldFeeDetail[type]=='Service')
						{
							$service .= $fieldFeeDetail[head] . ", ";	
						}
					
						$showButton=true;
						
						if($fieldFeeDetail[head]=='Monthly Fee')
						{
							$monthlyFee=$fieldFeeDetail[amount];
						}
						
				
				} // Clode While
				
				// Remove last ciomma from string
				 $service = substr(trim($service), 0, -1);
				 if($service!='')
				 {
					$ServiceFeeRemark = " FEE DUE AGAINST SERVICE FEE: <br><br> <span class='btn btn-danger btn-xs'><b>$service</b></span><br>";
					
					$showServiceRemark =
					"<li>
					  <i class='fa fa-rupee bg-Teal'></i>
					  <div class='timeline-item'>
						<p class='timeline-header no-border' style='color:#FF0'><a href='#'>$ServiceFeeRemark</a></p>
					  </div>
					</li>";
				 }
				 
				
				 $material = substr(trim($material), 0, -1);
				 if($material!='')
				 {
					$ProductFeeRemark = " <strong>FEE DUE AGAINST MATERIAL FEE: </strong> <br> <span class='btn btn-danger btn-xs'><b>$material</b></span>";
					
					$showMaterialRemark =
					"<li>
					  <i class='fa fa-shopping-cart bg-red'></i>
					  <div class='timeline-item'>
						<p class='timeline-header no-border' style='color:#FF0'><a href='#'>$ProductFeeRemark</a></p>
					  </div>
					</li>";
				 }
				 
				 
				 	
//---------------------------------OTHER FEE DUE-----------------------------------------	
//---------------------------------MONTHLY FEE DUE--------------------------------------------------

					 $date1=date($dataStudent['admDate']);
					 $date2=date("Y-m-d");
					 $monthDiff= month_difference($date1, $date2); // Total Months passes since admission till date
					
					
					//Find out the monthly fee not paid by the student, show the Month and Year in the control  accordangly
					//If $fieldFeeDetail[head] == 'Monthly Fee' then the student has not paid any month fee, in this case find out the ADMISSION Month of the student
					$sqlMonth="SELECT `feeForMonth` from `studentfee` where `studID`='$studID' and `feeDetailID`=9  ORDER by feeID";
					$statmentMonth = $connection -> query($sqlMonth);
					$statmentMonth -> execute();
					$feePaid = $statmentMonth -> rowCount();// Total Fee paid for month as per database
					$totalMonth=($monthDiff - $feePaid)+1;
					//$showButton=true;
						if($totalMonth < 0)
						{
							$monthFeeRemark= "Monthly Fee for ". convert_number(abs($totalMonth)) . " Month,  PAID in Advance.";
						}	
						elseif($totalMonth == 0)
						{						
							$monthFeeRemark=  "Monthly Fee Paid Till Current Month.";
						}	
						elseif($totalMonth > 0)	
						{
							$monthFeeRemark=  "Monthly Fee DUE for <span class='btn btn-danger btn-xs'>{$totalMonth} Months</span>  <br><br> TOTAL DUE AMOUNT :  <span class='btn btn-danger btn-xs'>Rs. " . $monthlyFee*($totalMonth) ."</span>";	
						}	

//---------------------------------MONTHLY FEE DUE--------------------------------------------------	
echo "
<div class='row'>
            <div class='col-md-12'>
              <!-- The time line -->
              <ul class='timeline'>
                <!-- timeline time label -->
				<li class='time-label'>
					<a href='main.php?pg=".base64_encode('profile')."&admID={$dataStudent[admID]}' target='_blank' data-toggle='tooltip' data-placement='bottom' title='Click here to view Student Profile'>
						<img class='img-circle' src='001_student_photo/". $studImage . "' alt='' height='70' width='70'>
					</a>
                </li>
				
                
				
				<li class='time-label'>
                  <span class='bg-purple disabled color-palette'>
                   
					<a  href='#' style='color:white; '><i class='fa fa-gg'></i> Current Belt : <b>" . strtoupper($dataStudent[currentBelt]) . "</b></a>
                  </span>
                </li>
				
                <!-- /.timeline-label -->
                <!-- timeline item -->
                <li>
                   <i class='fa fa-user bg-blue'></i>
                  <div class='timeline-item'>
                    <h5 class='timeline-header'>
					<a href='main.php?pg=".base64_encode('profile')."&admID={$dataStudent[admID]}' target='_blank' data-toggle='tooltip' data-placement='bottom' title='Click here to view Student Profile'>
						".ucwords(strtolower($dataStudent[name]))."
					</a> - Admission ID : $dataStudent[formNo]</h5>
                    <div class='timeline-body'>
                      <ul class=''>
						<li><b>BATCH : </b> $dataStudent[batchPreferene] | <b>Roll No : </b> $dataStudent[rollNo]</li>
						<li><b>REGISTRATION NO. : </b>". $dataStudent['formNo'] . "/ ". date('my',strtotime($dataStudent['admDate'])) ." / ". $dataStudent['formNoActual'] ."</li>
						
					  </ul>
                    </div>
                    <div class='timeline-footer'>
                      
                    </div>
                  </div>
                </li>
                <!-- END timeline item -->
                <!-- timeline item -->
                <li>
                  <i class='fa fa-calendar bg-red'></i>
                  <div class='timeline-item  bg-red disabled'>
                    <p class='timeline-header no-border' style='color:#FF0'><a style='color:#FFF'>$monthFeeRemark</a></p>
                  </div>
                </li>
				
				$showServiceRemark
				
				$showMaterialRemark
				";
			
			//Check if the student has filled up grading form earlier
			$sqlExam="select *, sum(due) as due from `exam` where `studID`='$studID' group by FormNo";	
			
			$statementExam = $connection -> query($sqlExam);
			$statementExam->execute();
			while($dataExam=$statementExam->fetch(PDO::FETCH_ASSOC))
			{	
			// Show Earlier form detail
			echo "<li>
                  <i class='fa fa-file-text bg-purple'></i>
                  <div class='timeline-item  bg-purple disabled'>
                    <h5 class='timeline-header text-purple'>
						<a style='color:#FFF'> Grading Exam Detail</a>
					</h5>
                    <div class='timeline-body'>
                      <ul class=''>
						<li><b>Form Date : </b> ". format_date($dataExam[FormDate]) ." | <b>Form No. : </b> $dataExam[FormNo]</li>
						<li><b>FROM : </b><span class='btn bg-yellow btn-xs'>". $dataExam[gradingFrom] . "</span> <b>TO : </b><span class='btn bg-yellow btn-xs'> $dataExam[gradingTo]</span></li>
						<li><b>DUE : </b> <span class='btn btn-danger btn-xs'> Rs. ". $dataExam[due] . " </span> </li>
					  </ul>
                    </div>
                    ";
				
			//Show Previous result
			if($dataExam[result]=='')
			{
				$result="</b>Result : </b> AWAITED";
			}
			else
			{
				$result="</b>Result : </b> $dataExam[result]";
			}	
			
			
				echo 	"<div class='timeline-footer'>
							<b style='color:#FFF'>$result</b>
						</div>
					  </div>
					</li>
						";	
			
			}
			
			
			
			
			// Show Grading Button	
			echo 	"<li class='time-label'>
					  <span class='bg-aqua'>
					   <a class='btn btn-aqua btn-xs'  data-toggle='modal' data-target='#gradingForm' target='_blank' style='color:#FFF'>Grading Form</a>
					  </span>
					</li>
				
                <li>
                  <i class='fa fa-clock-o bg-gray'></i>
                </li>
              </ul>
            </div><!-- /.col -->
          </div><!-- /.row -->

";
?>
