<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php
include('dbconn.php');

$sql="SELECT formNoActual from student ORDER By admDate";
$stmt=$connection->query($sql);
$regNo=101;
while($data=$stmt->fetch(PDO::FETCH_ASSOC))
{
	$sql2="UPDATE student set formNo='$regNo' where formNoActual='$data[formNoActual]'";
	$stmt2=$connection->query($sql2);
	$regNo++;
}
?>