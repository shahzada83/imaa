
<?php


	if(isset($_REQUEST['submit_photo_form']))
	{
		// CODE TO UPLOAD FILE---------------------------------------------------------------------
		//print_r($_FILES['file_photo']);
		$file_size=$_FILES['file_photo']['size'];
		$file_size_appform=$_FILES['appform']['size'];
		
		$file_name=$_FILES['file_photo']['name'];
		$file_name_appform=$_FILES['appform']['name'];
		
		$file_ext=strtolower(end(explode('.', $file_name)));
		$file_ext_appform=strtolower(end(explode('.', $file_name_appform)));
		
		$file_source=$_FILES['file_photo']['tmp_name'];
		$file_source_appform=$_FILES['appform']['tmp_name'];
		
		$file_new_name=mktime(). "." . $file_ext;
		$file_new_name_appform=mktime(). "." . $file_ext_appform;
		
		$file_destination='001_student_photo/' . $file_new_name ;
		$file_destination_appform='002_application_form/' . $file_new_name_appform ;
		
		$allowed_file_size=1048576;
		$allowed_file_size_appform=5048576;
		
		$allowed_file_extension=array('jpg');
		$allowed_file_extension_appform=array('jpg');
		
		if($_FILES['file_photo']['name']==1)
		{
			echo "<script>alert('File error, please select another image');</script>";	
		}
		elseif($_FILES['appform']['name']==1)
		{
			echo "<script>alert('File error, File seem to be corrupt or of different extension');</script>";	
		}
		elseif(!in_array('jpg', $allowed_file_extension))
		{
			echo "<script>alert('File extension should be .jpg');</script>";	
		}
		elseif(!in_array('jpg', $allowed_file_extension_appform))
		{
			echo "<script>alert('File extension should be .jpg');</script>";	
		}
		elseif($file_size > $allowed_file_size)
		{
			echo "<script>alert('File size should not be more than 1 MB');</script>";	
		}
		elseif($file_size_appform > $allowed_file_size_appform)
		{
			echo "<script>alert('File size should not be more than 5 MB');</script>";	
		}
		else
		{
			$photo=$file_new_name;
			if($photo!='')
			{
				if(move_uploaded_file($file_source, $file_destination))
				{
					$studID=$studentTable[studID];	
					if($connection->query("update student set photo='$photo' where studID='$studID'"))
					{
						//Insert into userLog table******************************************
						$userID=$_SESSION['userID'];
						$time=mktime();
						$tableName='student';	
						$primaryID="admID-" . $studentTable['admID'];
						$action='UPDATE';
						$perticular="$studentTable[name] - Profile Photo Updated.";
						// Call the Function insertUserLog() defined in API.php
						insertUserLog($userID, $time, $tableName, $primaryID, $action, $perticular);
						//Insert into userLog table******************************************
						echo "<script>alert('Student Photo Updated Successfully.');</script>";
						$admID=$studentTable[admID];
						echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$admID}';</script>";
					}
				}	
			}	
			
			$form=$file_new_name_appform;
			if($form!='')
			{
				if(move_uploaded_file($file_source_appform, $file_destination_appform))
				{
					$studID=$studentTable[studID];	
					if($connection->query("update student set formScan='$form' where studID='$studID'"))
					{
						//Insert into userLog table******************************************
						$userID=$_SESSION['userID'];
						$time=mktime();
						$tableName='student';	
						$primaryID="studID-" . $studentTable['studID'];
						$action='UPDATE';
						$perticular="$studentTable[name] - Application Form Updated.";
						// Call the Function insertUserLog() defined in API.php
						insertUserLog($userID, $time, $tableName, $primaryID, $action, $perticular);
						//Insert into userLog table******************************************
		
						echo "<script>alert('Student Application Form Updated Successfully.');</script>";
						$admID=$studentTable[admID];
						echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$admID}';</script>";
					}
				}
			}
	}
	$admID=$studentTable[admID];
	echo "<script>document.location.href='main.php?pg=".base64_encode('profile')."&admID={$admID};</script>";	
}
?>
		<style type="text/css">
			#upload_photo_form {display:none}
		</style>
		<script language="javascript">
			function showupload_photo_form()
			{
				document.getElementById('upload_photo_form').style.display='block'
			}
		</script>
<form method="post" name="myForm" action="" enctype="multipart/form-data" onsubmit="return(validate());">
<div class="box box-warning box-solid" id="upload_photo_form">
	<div class="box-header with-border">
	  <h3 class="box-title"> <i class="fa fa-upload"></i>&nbsp;&nbsp;Upload Form/ Photo of <?php echo ($studentTable['gender']=="Male")?'Mr. ':'Miss. ';?> <?php echo ucwords(strtolower($studentTable['name']));?></h3>
	  <div class="box-tools pull-right">
		<button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
	  </div><!-- /.box-tools -->
	</div><!-- /.box-header -->
	<div class="box-body">
	 
	 <div class="row">
		<div class="col-lg-4">
			<div class="form-group">
				<label  class="control-label" for="" style="font-size:12px"><i class="fa fa-file-o"></i> Upload Application Form</label>
				<input name="appform"  class="form-control input-sm" type="file" id="">
			</div>
		</div>		
	
		<div class="col-lg-4">
			<div class="form-group">
				<label  class="control-label" for="" style="font-size:12px"><i class="fa fa-camera"></i> Upload Students Photo</label>
				<input name="file_photo"  class="form-control input-sm" type="file" id="">
			</div>
		</div>	
		
		<div class="col-lg-4">
			<div class="form-group">
				<label   class="control-label" for="exampleInputFile"></label><br>
				<input type="submit" name="submit_photo_form" class="btn btn-primary" value="Upload">
			</div>
		</div>	
	</div>		
	<div class="clear"></div>	
	</div><!-- /.box-body -->
</div><!-- /.box -->
</form>  