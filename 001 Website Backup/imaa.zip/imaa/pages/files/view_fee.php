<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<style>
td, tr
{
	font-size:12px;
}
</style>	
 		
            
<!-- /.row -->
<style>
.example1
{ font-size:9px;}
</style>
<div class="row">
	<div class="col-lg-12">
		<div class="box box-primary box-solid  collapsed-box">
                <div class="box-header">
					<div class="box-tools pull-right">
                    	<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                  	</div><!-- /.box-tools -->
                  <h3 class="box-title">View Admission & Monthly Fee Details of <?php echo ($studentTable['gender']=="Male")?'Mr. ':'Miss. ';?> <?php echo ucwords(strtolower($studentTable['name']));?></h3>
                </div><!-- /.box-header -->
				 
                <div class="box-body table-responsive">
                  <table id="example1" class="table table-bordered table-striped table-responsive">
                    <thead>
                      <tr>
					  	<th>SL</th>
                        <th>Pay Head</th>
						<th>Month</th>
						<th>Date</th>
						<th>Receipt No.</th>
						<th>Pay Mode</th>
						<th>Fee</th>
						<th>Late Fine</th>
						<th>Discount</th>
						<th>Total</th>
						<th>Paid</th>
						<th>Due</th>
						<th>Reg. Sl.No</th>
						<th>Remark</th>
						<th>Receipt</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php
					$sqlStudentFee="select studentfee.*, feedetail.head from studentfee, feedetail where studentfee.studID=$studID and 
					feedetail.feeDetailID = studentfee.feeDetailID ORDER By studentfee.feeID DESC";
					$statementStudentFee = $connection -> query($sqlStudentFee);
					$statementStudentFee->execute();
					while($dataStudentFee = $statementStudentFee->fetch(PDO::FETCH_ASSOC))
					{
					?>
					
                      <tr>
                        <td><?php echo ++$slno; ?></td>
                        <td><h5><?php echo $dataStudentFee[head]; ?></h5></td>
						<th><?php 
								if($dataStudentFee[feeForMonth]=='' && $dataStudentFee[duesRemark]!='')
								{
									$dueRemark="<a href='#' data-toggle='popover' title='Due Remark' data-content='{$dataStudentFee[duesRemark]}'>DUE Remark</a>";
								}
								echo ($dataStudentFee[feeForMonth]=='')?$dueRemark:$dataStudentFee[feeForMonth]; ?></th>
						<td><?php echo format_date($dataStudentFee[payDate]); ?></td>
						<td><?php echo $dataStudentFee[receiptNo]; ?></td>
						<td>
							<a href="#" data-toggle="popover" title="Payment Detail" data-content="<?php echo $dataStudentFee[payModeRemark]; ?>"><?php echo $dataStudentFee[payMode]; ?></a>
						</td>
						<td><?php echo $dataStudentFee[amount]; ?></td>
						<td><?php echo $dataStudentFee[lateFine]; ?></td>
						<td><?php echo $dataStudentFee[discount]; ?></td>
						<td><?php echo $dataStudentFee[amount] + ($dataStudentFee[lateFine] - $dataStudentFee[discount]); ?></td>
						<td><?php echo $dataStudentFee[receivedAmount]; ?></td>
						<td style="color:#C00"><b><?php echo $dataStudentFee[dues]; ?></b></td>
						
						<td><?php 
						if($dataStudentFee[stockIssueID]==0 and $dataStudentFee[head]!='Monthly Fee')
						{
							echo "PENDING";	
						}
						elseif($dataStudentFee[stockIssueID]==0 and $dataStudentFee[head]=='Monthly Fee')
						{
							echo "";	
						}
						elseif($dataStudentFee[stockIssueID]==0 and $dataStudentFee[head]=='Admission Fee')
						{
							echo "ID CARD PENDING";	
						}
						else
						{
							echo ($dataStudentFee[head]=='Admission Fee')?"ID Card, Reg. SL.No." . $dataStudentFee[stockIssueID]:$dataStudentFee[stockIssueID]; 
						}
						?></td>
						<td>
							<a href="#" data-toggle="popover" title="Remark" data-content="<?php echo $dataStudentFee[remark]; ?>"><i class="fa fa-copy"></i></a>
						<?php echo $dataStudentFee[remark]; ?></td>
						<td><a href="files/view_receipt.php?rcpt=<?php echo $dataStudentFee[receiptNo]; ?>" target="_blank"><img src="001_student_photo/pdf.png"></a></td>
                      </tr>
					
					 <?php
					}
					?> 
                    </tbody>
                    <tfoot>
                       <tr>
					  	<th>SL</th>
                        <th>Pay Head</th>
						<th>Month</th>
						<th>Date</th>
						<th>Receipt No.</th>
						<th>Pay Mode</th>
						<th>Amount</th>
						<th>Discount</th>
						<th>Late Fine</th>
						<th>&nbsp;</th>
						<th>Total</th>
						<th>Reg. Sl.No</th>
						<th>Remark</th>
						<th>Receipt</th>
                      </tr>
                    </tfoot>
                  </table>
              </div><!-- /.box-body -->
              </div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->

