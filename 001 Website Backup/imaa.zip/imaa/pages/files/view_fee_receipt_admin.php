<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php
if(isset($_POST[showFeeReport]))
{
	$receiptNoFrom=$_POST[receiptNoFrom];
	$receiptNoTill=$_POST[receiptNoTill];
	
	
}
?>
<div class="box box-solid box-warning">
		<div class="box-header">
		  <h3 class="box-title">Search Receipt No's to View</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		<form action="" method="post" name="formViewFeeReceipt">
			<div class="row">
				<div class="col-lg-2  col-md-2 col-xs-6">
					<div class="form-group">
						<label class="small">Receipt No. From</label>
						<input class="form-control input-sm" type="text" name="receiptNoFrom" value="<?php echo $receiptNoFrom; ?>" onKeyPress="return isNumberKey(event)" maxlength="6">
						<span class="error" id="eFormNo"></span>
					</div>	
				</div>
				
				<div class="col-lg-2  col-md-2 col-xs-6">
					<div class="form-group">
						<label class="small">Receipt No. Till</label>
						<input class="form-control input-sm" type="text" name="receiptNoTill" value="<?php echo $receiptNoTill; ?>"  onKeyPress="return isNumberKey(event)" maxlength="6">
						<span class="error" id="eFormNo"></span>
					</div>	
				</div>
				
				<div class="col-md-2">
							
					<div class="form-group">
						<br />
					<input name="showFeeReport" type="submit" class="btn btn-primary" id="show"  onmouseover="return(validate());" value="Show Records" />
					</div>
				</div>
			</div>
		</form>
		
		<table id="example1" class="table table-bordered table-striped table-responsive">
		 	<thead>
                    <tr>
                      <th style="width: 10px">Name</th>
                      <th>Fee Head</th>
                      <th>Receipt No</th>
                      <th style="width: 40px">Payment Date</th>
					  <th>Fee For Month</th>
					  <th>Amount</th>
					  
                    </tr>
			</thead>			
		<!----------------------------------------------------------------------------------------------------------------------------------------->
		<?php
			 $sqlFee="	SELECT 
						studentfee . * , student.name, feedetail.head
						FROM studentfee, student, feedetail
						WHERE 
						student.studID = studentfee.studID
						AND feedetail.feeDetailID = studentfee.feeDetailID	
						AND studentfee.receiptNo >=  '$receiptNoFrom'
						AND studentfee.receiptNo <=  '$receiptNoTill'
						
						ORDER BY studentfee.feeID, studentfee.receiptNo";
		$statementProduct=$connection->query($sqlFee);
		while($dataProduct=$statementProduct->fetch(PDO::FETCH_ASSOC))
		{
		?>
		<tr>
			<td><?php echo $dataProduct['name']; ?></td>
			
			<td><?php echo $dataProduct['head']; ?></td>		
			
			<td><?php echo $dataProduct['receiptNo']; ?></td>
			
			<td><?php echo short_date($dataProduct['payDate']); ?></td>
			
			<td><?php echo $dataProduct['feeForMonth']; ?></td>
			
			<td><?php echo $dataProduct['amount']; ?></td>
		
			
		</tr>	
		<?php
		}
		?>
		<!----------------------------------------------------------------------------------------------------------------------------------------->
		</table>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->