<?php
session_start();

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/

	include('dbconn.php');
	include('API.php');
	$receiptNo=$_GET['rcpt'];
	//fetch data from student table
	$sql_student = "select `student`.`admDate`, `student`.`rollNo`, `student`.`formNo`, `student`.`gender`, `student`.`name`, `student`.`email`, `student`.`batchPreferene`, `studentfee`.`studID`, `studentfee`.`payDate`, `studentfee`.`createdOn` from  `student`,`studentfee` where `studentfee`.`studID`=`student`.`studID` and `studentfee`.`receiptNo`='$receiptNo'";
	$statement_student = $connection -> query($sql_student);
	$data_student=$statement_student->fetch(PDO::FETCH_ASSOC);
	$rollNo 	= $data_student[rollNo];
	$formNo	 	= $data_student[formNo];
	$name 		= $data_student[name];
	if($data_student[gender]=="Male")
	{
		$gender		= "Mr. ";
	}
	elseif($data_student[gender]=="Female")
	{
		$gender		= "Miss. ";
	}
	else
	{
		$gender		= "";
	}
	$email 		= $data_student[email];
	$batchPreferene = $data_student[batchPreferene];
	$studID 	= $data_student[studID];
	$payDate 	= format_date($data_student[payDate]);
	$createdOn 	= $data_student[createdOn];
?>	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
body,td,th {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
}
#main
{
	background:url(img/imaawater.png);
	background-repeat: no-repeat;
    
    background-position: center center; 
}
</style>
</head>

<body>
<div  id="main">
<table width="100%" border="0" cellspacing="0" id="maintable">
	<tr>
		<td width="1%" valign="middle">&nbsp;</td>
		<td height="50" valign="middle"><img src="../../img/logoSmall.jpeg" width="50" height="50" /></td>
		<td colspan="2" align="left" valign="middle"><h3 style="color:#A82123">PAYMENT RECEIPT</h3></td>
		<td width="4%" align="left" valign="middle"><p>&nbsp;</p>
		<p>&nbsp;</p></td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td align="left" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td height="40" colspan="2" style="border-top:1px solid #000; border-bottom:1px solid #000"><b style="color:#666">Student Name :</b> <?php echo $gender . strtoupper($name);?></td>
		<td width="56%" style="border-top:1px solid #000; border-bottom:1px solid #000; text-align: right;"><b style="color:#666">Date: </b> <?php echo $payDate; ?></td>
		<td align="left" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td>&nbsp;</td>
		<td width="36%">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="2"><b style="color:#666">AFFILIATED WITH</b></td>
		<td rowspan="2" valign="top"><table width="100%" border="0" cellspacing="0">
			<tr>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Registration No.</strong></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Receipt No.</strong></td>
				</tr>
			<tr>
				<td width="10%">&nbsp;</td>
				<td><?php echo $formNo; ?>/<?php echo date("my",strtotime($data_student['admDate']));?></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><?php echo $receiptNo; ?></td>
				</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
			<tr>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Batch </strong></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Roll No.</strong></td>
				</tr>
			<tr>
				<td>&nbsp;</td>
				<td><?php echo $batchPreferene; ?></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><?php echo $rollNo; ?></td>
				</tr>
		</table></td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="2" valign="top">KARATE ASSOCIATION OF INDIA, DISTRICT &amp; STATE KARATE ASSOCIATION,<br />
			INDIAN OLYMPIC ASSOCIATION, ASIAN KARATE FEDERATION, WORLD KARATE FEDERATION<br />
		<b>RECOGNISED BY:</b> GOVT. OF INDIA (MINISTER OF YOUTH AFFAIRS &amp; SPORTS)</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="2">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3">
		<table width="100%" border="0" style="border:1px solid #CCC; border-radius:5px;">
			<tr>
				<td>
				
				<?php
					$sql_studentfee = "select `studentfee`.*, `feedetail`.`head` from  `studentfee`,`feedetail` where `studentfee`.`receiptNo`='$receiptNo' and `studentfee`.`feeDetailID` = `feedetail`.`feeDetailID`";
					$statement_studentfee = $connection -> query($sql_studentfee);
					
					$months=array();
					$amountMonth=array();
								
					while($data_studentfee=$statement_studentfee -> fetch(PDO::FETCH_ASSOC))
					{
						if($data_studentfee[head]=='Admission Fee')
						{
							$admission=true;
							$amountAdm= $data_studentfee[amount];
							
							$NETdiscountAdm +=$data_studentfee[discount];
							$NETlatefineAdm += $data_studentfee[lateFine];
							$NETDUEAdm += $data_studentfee[dues];
							$totalAdm =$data_studentfee[amount] + $data_studentfee[lateFine] - $data_studentfee[discount] - $data_studentfee[dues]; $NETtotalAdm += $totalAdm;
						} // Closing If
						
						elseif($data_studentfee[head]=='Monthly Fee')
						{
							$monthlyFee=true;
							array_push($months, $data_studentfee[feeForMonth]);
							
							//print_r($months);
							
							array_push($amountMonth, $data_studentfee[amount]);
							$NetTotalMonth=$NetTotalMonth+$data_studentfee[amount];
							$NETdiscountMonth +=$data_studentfee[discount];
							$NETlatefineMonth += $data_studentfee[lateFine];
							$NETDUEMonth += $data_studentfee[dues];
							$totalMonth =$data_studentfee[amount] + $data_studentfee[lateFine] - $data_studentfee[discount] - $data_studentfee[dues]; $NETtotalMonth += $totalMonth;
						} // Closing elseIf
					}
					?>
				
				<table width="100%" border="0">
					<tr style="color:#666;">
						<th height="40" align="left" style="border-bottom:#666 1px solid;">DESCRIPTION</th>
						<th align="right" style="border-bottom:#666 1px solid;">RATE</th>
						<th align="right" style="border-bottom:#666 1px solid;">AMOUNT</th>
					</tr>
					<?php
					if($admission==true)
					{
					?>
					<tr style="color:#000;">
						<td height="40" align="left">
						Admission Fee
						
						<span style="color:#666">
							<?php
								if($NETdiscountAdm!=0)
								{
									echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Discount : -Rs. ". ceil($NETdiscountAdm);
								}
								
								if($NETDUEAdm!=0)
								{
									echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Balance : Rs. ".ceil($NETDUEAdm);
								}
								
							?>
						</span>	
						</td>
						
						<td align="right"><?php echo floor($amountAdm); ?></td>
						<td align="right"><?php echo floor($NETtotalAdm); ?></td>
					</tr>
					<?php
					}
					?>
					<tr>
						<th></th>
						<th></th>
						<th></th>
					</tr>
					<?php
					if($monthlyFee==true)
					{
					?>
					<tr style="color:#000;">
						<td height="40" align="left">
						Monthly Fee<br />
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Paid monthly fee for <?php echo sizeof($months); ?> Months (<b>FROM :</b><?php echo $months[0]; ?>, <b>TILL :</b> <?php echo end($months); ?>)
						
						<span style="color:#666">
							<?php
								if($NETlatefineMonth!=0)
								{
									echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Late Fine : Rs. ".ceil($NETlatefineMonth);
								}
								
								if($NETdiscountMonth!=0)
								{
									echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Discount : -Rs. ".ceil($NETdiscountMonth);
								}
								
								if($NETDUEMonth!=0)
								{
									echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Balance : Rs. ". ceil($NETDUEMonth);
								}
								
								
							?>
						</span>	
						</td>
						
						<td align="right">
							<?php
							$amtMonth	=	array_unique($amountMonth); 
							foreach($amtMonth as $amt)
							{
								echo $amt."<br>";
							}
							?>
						</td>
						<td align="right"><?php echo floor($NETtotalMonth); ?></td>
					</tr>
					<?php
					}
					?>
					<tr>
						<th></th>
						<th></th>
						<th></th>
					</tr>
					<tr style="color:#666;">
						<th height="40" align="left" style="border-top:#666 1px solid;">Balance (if Any) : Rs. <?php echo $finalDue=ceil($NETDUEMonth)+ceil($NETDUEAdm); ?>.00 (Rupees <?php echo convert_number($finalDue); ?> Only)</th>
						<th align="right" style="border-top:#666 1px solid;"></th>
						<th align="right" style="border-top:#666 1px solid;">Rs. <?php echo $finalTotal=floor($NETtotalMonth)+floor($NETtotalAdm); ?></th>
					</tr>
				</table>
				
				</td>
			</tr>
		</table>
		</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3"><b style="color:#666">Total Amount (in words) : </b> Rupees <?php echo convert_number($finalTotal); ?> Only</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3"><b>NOTE: </b>Fees once paid are non-transferable / non-adjustable / non-refundable under any circumstances and are subject to the exceptions as set out in the refund policy. </td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3"></td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3">
			<b style="color:#666">Batch Schedule for <?php echo $batchPreferene; ?></b>
			<?php
			$sql_batch = "select `day`, `time` from  `studentbatch`  where `preference`='$batchPreferene'";
			$statementBatch = $connection ->query($sql_batch);
			while($data_batch=$statementBatch->fetch(PDO::FETCH_ASSOC))
			{
			?>
				| <?php echo $data_batch[day]; ?> : <?php echo $data_batch[time]; ?>
			<?php
			}
			?>
		
		</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3"></td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td height="40" colspan="3" style="border-top:1px solid #000; border-bottom:1px solid #000; color:#333" align="center">
				<b>INTERNATIONAL MARTIAL ARTS ACADEMY</b><br />
				<b>Address :</b> St. Joseph's Club, Purulia Road Ranchi 834001 (Jharkhand)<br />
				<b>Contact No. :</b>  9835165518 | <b>E-Mail ID :</b>  kispottasunil2@gmail.com, s.k_karate@yahoo.co.in
		</td>
		<td align="left" valign="middle">&nbsp;</td>
	</tr>
</table>
</div>
</body>
</html>
