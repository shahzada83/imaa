
<?php
	include('dbconn.php');
	include('API.php');
	$receiptNo=$_GET['rcpt'];
	//fetch data from student table
	$sql_student = "select `student`.`admDate`, `student`.`rollNo`, `student`.`formNo`, `student`.`gender`, `student`.`name`, `student`.`email`, `student`.`batchPreferene`, `exam`.* from  `student`,`exam` where `exam`.`studID`=`student`.`studID` and `exam`.`receiptNo`='$receiptNo'";
	$statement_student = $connection -> query($sql_student);
	$data_student=$statement_student->fetch(PDO::FETCH_ASSOC);
	$rollNo 	= $data_student[rollNo];
	$formNo	 	= $data_student[formNo];
	$name 		= $data_student[name];
	$gender		= $data_student[gender];
	$email 		= $data_student[email];
	$batchPreferene = $data_student[batchPreferene];
	$studID 	= $data_student[studID];
	$payDate 	= format_date($data_student[FormDate]);
	$createdOn 	= $data_student[createdOn];

	if($data_student[gender]=="Male")
	{
		$gender		= "Mr. ";
	}
	elseif($data_student[gender]=="Female")
	{
		$gender		= "Miss. ";
	}
	else
	{
		$gender		= "";
	}
	$email 		= $data_student[email];
	$batchPreferene = $data_student[batchPreferene];
	$studID 	= $data_student[studID];
	$createdOn 	= $data_student[createdOn];
?>	

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
body,td,th {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
}
#main
{
	background:url(img/imaawater.png);
	background-repeat: no-repeat;
    
    background-position: center center; 
}
</style>
</head>

<body>
<div  id="main">
<table width="100%" border="0" cellspacing="0" id="maintable">
	<tr>
		<td width="1%" valign="middle">&nbsp;</td>
		<td width="3%" valign="middle"><img src="../../img/logoSmall.jpeg" width="50" height="50" /></td>
		<td colspan="2" align="left" valign="middle"><h3 style="color:#A82123">&nbsp;&nbsp;&nbsp; PAYMENT RECEIPT</h3></td>
		<td width="4%" align="left" valign="middle"><p>&nbsp;</p>
		<p>&nbsp;</p></td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td align="left" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td height="40" colspan="2" style="border-top:1px solid #000; border-bottom:1px solid #000"><b style="color:#666">Student Name :</b> <?php echo $gender . strtoupper($name);?></td>
		<td width="56%" style="border-top:1px solid #000; border-bottom:1px solid #000; text-align: right;"><b style="color:#666">Date: </b> <?php echo $payDate; ?></td>
		<td align="left" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td>&nbsp;</td>
		<td width="36%">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="2"><b style="color:#666">AFFILIATED WITH</b></td>
		<td rowspan="2" valign="top"><table width="100%" border="0" cellspacing="0">
			<tr>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Registration No.</strong></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Receipt No.</strong></td>
				</tr>
			<tr>
				<td width="10%">&nbsp;</td>
				<td><?php echo $formNo; ?>/<?php echo date("my",strtotime($data_student['admDate']));?></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><?php echo $receiptNo; ?></td>
				</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				</tr>
			<tr>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Batch </strong></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><strong style="color:#666">Roll No.</strong></td>
				</tr>
			<tr>
				<td>&nbsp;</td>
				<td><?php echo $batchPreferene; ?></td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td><?php echo $rollNo; ?></td>
				</tr>
		</table></td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="2" valign="top">KARATE ASSOCIATION OF INDIA, DISTRICT &amp; STATE KARATE ASSOCIATION,<br />
			INDIAN OLYMPIC ASSOCIATION, ASIAN KARATE FEDERATION, WORLD KARATE FEDERATION<br />
		<b>RECOGNISED BY:</b> GOVT. OF INDIA (MINISTER OF YOUTH AFFAIRS &amp; SPORTS)</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="2">&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3">
		<table width="100%" border="0" style="border:1px solid #CCC; border-radius:5px;">
			<tr>
				<td>
				
				<?php
					$sql_studentfee = "select `studentfee`.*, `materialdetail`.* from  `studentfee`,`materialdetail` where `studentfee`.`receiptNo`='$receiptNo' and `studentfee`.`feeDetailID` = `materialdetail`.`materialID`";
					$statement_studentfee = $connection -> query($sql_studentfee);
				?>
				
				<table width="100%" border="0">
					<tr style="border-bottom:#666 1px solid">
						<th align="left">Form No</th>
						<th align="left">Exam Session</th>
						<th align="left">Grading From</th>
						<th align="left">Grading To</th>
						<th align="left">FEE</th>
						<th align="left">LATE FEE</th>
						<th align="left">DUE</th>
						<th align="left">PAID</th>
					</tr>
					
					<?php
					$sql_studentfee = "select * from  `exam` where `receiptNo`='$receiptNo'";
					$statement_studentfee = $connection -> query($sql_studentfee);
					while($data_studentfee=$statement_studentfee -> fetch(PDO::FETCH_ASSOC))
					{
					
					?>
					
					<tr>
						<td align="left"><?php echo $data_studentfee[FormNo]; ?></td>
						<td><?php echo $data_studentfee[examMonth]; ?></td>
						<td><?php echo $data_studentfee[gradingFrom]; ?> BELT</td>
						<td><?php echo $data_studentfee[gradingTo]; ?> BELT</td>
						<td><?php echo $data_studentfee[fee]; ?></td>
						<td><?php echo $data_studentfee[lateFee]; ?></td>
						<td><?php echo $data_studentfee[due]; ?></td>
						<td><?php $finalTotal += $data_studentfee[totalReceived]; echo $finalTotal;  ?></td>
					</tr>
					<?php
					}
					?>
					<tr>
						<th height="40" colspan="6" align="left" style="border-top:#666 1px solid;">Balance (if Any) : Rs. <?php echo $finalDue=ceil($data_studentfee[due]); ?>.00 (Rupees <?php echo convert_number($data_studentfee[due]); ?> Only)</th>
						<th style="border-top:#666 1px solid;"></th>
						<th align="left" style="border-top:#666 1px solid;">Rs. <?php echo $finalTotal; ?></th>
					</tr>
				</table>
				
				</td>
			</tr>
		</table>
		</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3"><b style="color:#666">Total Amount (in words) : </b> Rupees <?php echo convert_number($finalTotal); ?> Only</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3"><b>NOTE: </b>Fees once paid are non-transferable / non-adjustable / non-refundable under any circumstances and are subject to the exceptions as set out in the refund policy. </td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td colspan="3"></td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td valign="middle">&nbsp;</td>
		<td height="40" colspan="3" style="border-top:1px solid #000; border-bottom:1px solid #000; color:#333" align="center">
				<b>INTERNATIONAL MARTIAL ARTS ACADEMY</b><br />
				<b>Address :</b> St. Joseph's Club, Purulia Road Ranchi 834001 (Jharkhand)<br />
				<b>Contact No. :</b>  9835165518 | <b>E-Mail ID :</b>  kispottasunil2@Gmail.com, s.k_karate@yauoo.co.in
		</td>
		<td align="left" valign="middle">&nbsp;</td>
	</tr>
</table>
</div>
</body>
</html>