<?php
	include('dbconn.php');
	include('API.php');
	$receiptNo=$_GET['rcpt'];
	//fetch data from student table
	$sql_student = "select `student`.`admDate`, `student`.`rollNo`, `student`.`formNo`, `student`.`gender`, `student`.`name`, `student`.`email`, `student`.`batchPreferene`, `studentfee`.`studID`, `studentfee`.`payDate`, `studentfee`.`createdOn` from  `student`,`studentfee` where `studentfee`.`studID`=`student`.`studID` and `studentfee`.`receiptNo`='$receiptNo'";
	$statement_student = $connection -> query($sql_student);
	$data_student=$statement_student->fetch(PDO::FETCH_ASSOC);
	$rollNo 	= $data_student[rollNo];
	$formNo	 	= $data_student[formNo];
	$name 		= $data_student[name];
	$gender		= $data_student[gender];
	$email 		= $data_student[email];
	$batchPreferene = $data_student[batchPreferene];
	$studID 	= $data_student[studID];
	$payDate 	= format_date($data_student[payDate]);
	$createdOn 	= $data_student[createdOn];
?>	
<style>
table {
    border-collapse: collapse;
}

table, th, td {
	
	
	font-family: Verdana, Geneva, sans-serif;
	font-size:12px;
	height:25px;
	
}
.style12 {font-size: small; font-family: Verdana, Arial, Helvetica, sans-serif; }
</style>
<table width="100%" border="0">
	<tr>
		<td align="center" colspan="3" class="no-border"><br />
		<p><img src="img/imaareceipt.png" height="150px"/></p>
		
		
	</tr>
	
	
	<tr>
		<td>
			<table width="100%" border="0" cellspacing="5" style="border-color:#FFF">
				<tr>
					<td width="30%">&nbsp;</td>
					<td width="40%">&nbsp;</td>
					<td width="30%">&nbsp;</td>
				</tr>
				<tr style="color:#FFF; bordercolor=#000000; padding:3px">
					<td colspan="3" valign="middle" align="center" bgcolor="#CC0000"><span style="font-size:18px"><b>FEE RECEIPT</b></span></td>
				</tr>
				<tr>
					<td><b>Receipt No. : </b><?php echo $receiptNo; ?></td>
					<td><b>Registration No. : 	</b>	<?php echo $formNo; ?>/<?php echo date("my",strtotime($data_student['admDate']));?>			</td>
					<td><b>Roll No. : 			</b>	<?php echo $rollNo; ?></td>
				</tr>
				<tr>
					<td><b>Date : </b><?php echo $payDate; ?></td>
					<td><b>Name : 				</b>	
						<?php 
						$studentName = ($gender=="Male")?'Mr. ':'Miss. ';
						echo $studentName .= ucwords(strtolower($name));
					?>	
					</td>
					<td><b>Batch : 				</b>	<?php echo $batchPreferene; ?>	</td>
				</tr>
				
				<tr>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td colspan="3">
						<table width="100%" border="1" style=" border-collapse: collapse; font-size:12px" cellpadding="5px">
							<tr style="color:#FFF">
								<th bgcolor="#CC0000">SL.No.</th>
								<th bgcolor="#CC0000" align="left">Product</th>
								<th bgcolor="#CC0000">Quality</th>
								<th bgcolor="#CC0000">Size (Inch)</th>
								<th bgcolor="#CC0000">Price</th>
								<th bgcolor="#CC0000">(-)</th>
								<th bgcolor="#CC0000">DUE</th>
								<th bgcolor="#CC0000">Paid</th>
							</tr>
							<?php
							$sql_studentfee = "select `studentfee`.*, `materialdetail`.* from  `studentfee`,`materialdetail` where `studentfee`.`receiptNo`='$receiptNo' and `studentfee`.`feeDetailID` = `materialdetail`.`materialID`";
							$statement_studentfee = $connection -> query($sql_studentfee);
							
										
							while($data_studentfee=$statement_studentfee -> fetch(PDO::FETCH_ASSOC))
							{
							?>
							<tr align="center">
								<td><?php echo ++$SLNO; ?></td>
								<td align="left"><?php echo $data_studentfee[itemName]; ?></td>
								<td><?php echo $data_studentfee[quality]; ?></td>
								<td><?php echo $data_studentfee[size]; ?></td>
								<td><?php echo $data_studentfee[amount]; $NETamount += $data_studentfee[amount]; ?></td>
								<td> - <?php echo $data_studentfee[discount]; $NETdiscount +=$data_studentfee[discount]; ?></td>
								<td><?php echo $data_studentfee[dues]; $NETDUE += $data_studentfee[dues]; ?></td>
								<td><?php echo $total =$data_studentfee[receivedAmount]; $NETtotal += $total; ?></td>
							</tr>
							<?php
							}
							?>
							<tr align="center" style="background-color:#CC0000; color:#FFF">
								<td colspan="4">&nbsp;</td>
								<td><?php echo $NETamount; ?></td>
								<td><?php echo $NETdiscount; ?></td>
								
								<td><?php echo $NETDUE; ?></td>
								<td><b><?php echo $NETtotal; ?></b></td>
							</tr>
							
							
							<tr align="left">
								<td colspan="8" style="border-bottom:0px #FFF">
								<?php
									if( $data_studentfee[duesRemark]!='')
									{
										echo "<b><i>NOTE: " . $data_studentfee[duesRemark] . "</i></b>";
									}
								?>
								</td>
							</tr>
							<tr align="left">
								<td colspan="8"><b>Amount in words : </b> Rupees <?php echo convert_number($NETtotal); ?> Only</td>
							</tr>
							<tr align="left">
								<td colspan="8"><table width="100%" border="0">
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td><span class="style12"><strong>Note :</strong> This is computer generated 
          Receipt and does not require signature. </span></td>
									</tr>
									<tr>
										<td align="left">
										
											<span style="text-align:center">
											<?php $text=$createdOn; ?>
											<img alt="<?php echo $text; ?>" src="barcode.php?codetype=Codabar&size=40&text=<?php echo $text; ?>" />
											<br />
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $text; ?>	
											</span>		  
										
										</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td>
											<table width="100%" border="1">
												<tr>
												<b>Batch Schedule for <?php echo $batchPreferene; ?></b><br /><br />
												<?php
												$sql_batch = "select `day`, `time` from  `studentbatch`  where `preference`='$batchPreferene'";
												$statementBatch = $connection ->query($sql_batch);
												while($data_batch=$statementBatch->fetch(PDO::FETCH_ASSOC))
												{
												?>
													<td><strong><?php echo $data_batch[day]; ?> : <?php echo $data_batch[time]; ?></strong></td>
												<?php
												}
												?>	
												</tr>
											</table>
										</td>
									</tr>
								</table></td>
							</tr>
							<tr align="left">
								<td colspan="8">&nbsp;</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
