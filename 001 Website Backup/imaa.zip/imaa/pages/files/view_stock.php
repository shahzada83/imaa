
<div class="box box-solid box-warning">
	<div class="box-header">
	  <h3 class="box-title">Stock Details</h3>
	</div><!-- /.box-header -->
	
	<div class="box-body">
	
		 <table id="example1" class="table table-bordered table-striped table-responsive">
		 <thead>
			<tr>
			  <th>Product</th>
			  <th>Quality</th>
			  <th>Size (")</th>
			  <th>Selling Price</th>
			  <th>Qty Status</th>
			  
			  <th>Quantity</th>
			  <th>Issued Qty</th>
			  <th>Stock In<br /> Hand</th>
			   <th><b>PENDING</b><br />FOR ISSUE</th>
			</tr>
		</thead>	
			<?php
			//$sqlStockView="SELECT stock.*, SUM(stock.qty) as totalQty, feedetail.head from stock, feedetail where feedetail.feeDetailID=stock.feeDetailID group by stock.feeDetailID,stock.quality order by stock.feeDetailID, stock.quality";
			$sqlStockView="SELECT materialdetail.* from materialdetail";
			$stmtStockView=$connection->query($sqlStockView);
			while($dataStockView=$stmtStockView->fetch(PDO::FETCH_ASSOC))
			{
			?>
			
			<tr class="<?php
					if($dataStockView[quality]=='High')
					  {
							echo "info"; 
					  }
					  elseif($dataStockView[quality]=='Medium')
					  {
						  echo "success";  
					  }
					  elseif($dataStockView[quality]=='Low')
					  {
						  echo "warning";  
					  }
					?>
				">
			
			  <td><?php echo ($dataStockView[feeDetailID]==6)?"ID CARD" : $dataStockView[itemName]; ?></td>
			  <td>
			  <b style="font-size:18px">
			  <?php 
				  if($dataStockView[quality]=='High')
				  {
						echo "<span class='label label-primary'>";  
				  }
				  elseif($dataStockView[quality]=='Medium')
				  {
					  echo "<span class='label label-success'>";  
				  }
				  elseif($dataStockView[quality]=='Low')
				  {
					  echo "<span class='label label-warning'>";  
				  }
				  echo $dataStockView[quality]; 
			  ?>
			  </b>
			  </td>
			  <td><b><?php echo $dataStockView[size]; ?></b></td>
			  <td><b><?php echo $dataStockView[sellingPrice]; ?></b></td>
			  <td><div class="progress progress-xs"><div class="progress-bar progress-bar-danger" style="width: <?php echo $var_stock_qty = $dataStockView[StockReceived];?>%"></div></div></td>
			  <td style="color:#060"><b><?php echo $dataStockView[StockReceived]; ?></b></td>
			  <td>
			  	<?php 
				// code if otherquery is run - commented above
				/*
				  if($dataStockView[quality]=='High')
				  {
						$feePaid=2000;  
				  }
				  elseif($dataStockView[quality]=='Medium')
				  {
					  	$feePaid=800;  
				  }
				  elseif($dataStockView[quality]=='Low')
				  {
					  $feePaid=700;  
				  }
				   elseif($dataStockView[feeDetailID]==6)
				  {
					  $feePaid=600;  
				  }
				  
				  $sqlItemIssue="select count(studID) as issued from studentfee where (stockIssueID!=0 or stockIssueID!=99999) and feeDetailID='$dataStockView[feeDetailID]' and amount='$feePaid'";
				  $stmtitemIssue=$connection->query($sqlItemIssue);
				  $dataIssueItem=$stmtitemIssue->fetch(PDO::FETCH_ASSOC);
				 
				  
				   echo $var_issued = $dataIssueItem[issuedQty];*/
			  ?>
			  
			  <?php echo $var_issued =  $dataStockView[StockIssued]; ?>
			  </td>
			  <td style="font-size:14px; color:#C00;">
			  	<b><?php echo $var_stock_qty-$var_issued; ?></b>
			  </td>
			  
			  <td style="font-size:14px; color:#C00;">
			  	<?php
				$sqlMaterial="SELECT count(studID) as PendingIssue from `studentfee` where feeDetailID='$dataStockView[materialID]' and feeDetailID!=6 and feeDetailID!=9  and stockIssueID=0";
				$statmentMaterial = $connection -> query($sqlMaterial);
				$dataPendingIssue = $statmentMaterial -> fetch(PDO::FETCH_ASSOC);
				//echo $dataPendingIssue[PendingIssue];
				?>
				<a href="main.php?pg=<?php echo base64_encode('view stock');?>&matID=<?php echo $dataStockView[materialID];?>" class="btn btn-<?php echo ($dataPendingIssue[PendingIssue]==0)?"success":"danger" ?>">
					<?php echo $dataPendingIssue[PendingIssue]; ?>
				</a>
			  </td>
			  
			</tr>
			<?php
			}
			?>
			 <tfoot>
				 <tr>
				  <th>Product</th>
				  <th>Quality</th>
				   <th>Qty Status</th>
				  <th>Quantity</th>
				  <th>Issued Qty</th>
				  <th>Stock In<br /> Hand</th>
				   <th><b>PENDING</b><br />FOR ISSUE</th>
				</tr>
			 
			 </tfoot>
	  </table>
	
	</div><!-- /.box-body -->
</div><!-- /.box -->
<?php
$matID=$_GET['matID'];
$qualitySTOCK=$_GET['qty'];
if(isset($matID))
{
?>
<div class="box box-solid box-danger">
	<div class="box-header">
	  <h3 class="box-title">Pending For Issue - Report</h3>
	  	<div class="box-tools pull-right">
			<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
		  </div><!-- /.box-tools -->
	</div><!-- /.box-header -->
	<div class="box-body">

	<iframe src="files/reports/stock_material_pending.php?matID=<?php echo $matID; ?>&qty=<?php echo $qualitySTOCK; ?>" height="50%" width="99%" frameborder="0"></iframe>
	
	</div>
</div>	
<?php
}
?>
<br /><br />