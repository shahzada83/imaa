<?php

		/*********************SESSION VARIABLE*********************/
		
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>

<?php
	$lst = $_GET[lst]; // from the URL, generated when user clicks on <View Dropout Students> or <View DELETED Students>
?>
<style>
td, tr
{
	font-size:12px;
}
</style>	
 		
            
<!-- /.row -->
<a href="main.php?pg=<?php echo base64_encode('view students'); ?>&lst=do"> <i class="fa fa-thumbs-down"></i> View DROPOUT Students</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="main.php?pg=<?php echo base64_encode('view students'); ?>&lst=del"> <i class="fa fa-times-circle"></i> View DELETED Students</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="main.php?pg=<?php echo base64_encode('view students'); ?>"> <i class="fa fa-user"></i> View CURRENT Students</a>
<br /><br />


<div class="row">

	<div class="col-lg-12">
		<div class="box box-primary box-solid">
                <div class="box-header">
                  <h3 class="box-title"><i class="fa fa-users"></i> You are viewing <b>
				  <?php
					if($lst=='do')
					{
						echo "Dropout Student List";
					}
						elseif($lst=='del')
					{
						echo "Deleted Student List";
					}
					else
					{
						echo "Current Student List";
					}
				  ?>
				  
				  
				  </b></h3>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                  <table id="example1" class="table table-bordered table-striped table-responsive">
                    <thead>
                      <tr>
					  	<th>Photo</th>
                        <th>Roll No</th>
						<th>Name</th>
						<th>Mobile No.</th>
						<th>Applied for Belt</th>
						<th align="center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
//***********************************************************************************************************************************************//
	if($lst=='do')
	{
		$statement=$connection->query("select * from `student` where `dropout`=1 and `deleted`=0"); // We can use DELETE, INSERT and UPDATE QUERY as usual
	}
	elseif($lst=='del')
	{
		$statement=$connection->query("select * from `student` where `deleted`=1"); // We can use DELETE, INSERT and UPDATE QUERY as usual
	}
	else
	{
		$statement=$connection->query("select * from `student` where `deleted`=0 and `dropout`=0"); // We can use DELETE, INSERT and UPDATE QUERY as usual
	}

	while($data = $statement->fetch(PDO::FETCH_ASSOC)) // if row is returned from database/ table
	{
//***********************************************************************************************************************************************//	
?>
                      <tr>
                        <td width="80px">
							<?php
								$profileImage=($data[photo] != '')?$data[photo]:'no_image.png';
							?>
                	<img src="001_student_photo/<?php echo $profileImage; ?>" height="80px" width="80px" class="img-circle" />
						</td>
                        <td>
							<strong>
								Registration No. : <?php echo $data['formNo'];?>/<?php echo date("my",strtotime($data['admDate']));?> <br />
								Roll No. : <?php echo $data['rollNo'];?><br>
								Batch : <?php echo $data['batchPreferene'];?>
							</strong>
						</td>
						
                        <td>
							<?php
								echo ($data['gender']=='Male')?"Mr. " : "Miss. ";
								echo ucwords(strtolower($data['name']));
							?>	
						</td>
						
                        <td>
							<i class="fa fa-phone"></i>&nbsp;&nbsp; <?php echo $data['mobile'];	?><br />
							<i class="fa fa-whatsapp"></i>&nbsp;&nbsp; <?php echo ($data['whatsapp']=='')?"NA":$data['whatsapp'];	?>
						</td>
                        
						<td>
							<strong>
								Current Belt: <?php echo $data['currentBelt']; ?><br />
								Grading For : <?php echo $data['gradingFor']; ?>
							</strong>
						</td>
						
						<td align="center">
						
						<a href="main.php?pg=<?php echo base64_encode('profile');?>&admID=<?php echo $data[admID];?>" class="btn btn-warning"><i class="fa fa-search" style="color:#FFFFFF"></i> View Profile</a>
						</td>
						
                      </tr>
<?php
//***********************************************************************************************************************************************//	
	}	
//***********************************************************************************************************************************************//	
?>                      
                    </tbody>
                    <tfoot>
                       <tr>
					  	<th>Photo</th>
                        <th>Roll No</th>
						<th>Name</th>
						<th>Mobile No.</th>
						<th>Applied for Belt</th>
						<th align="center">Action</th>
                      </tr>
					  <tr>
					  	<td colspan="6"><a href='files/export_to_excel.php' target="_blank"><img src="stud_image/excel.png" /> Export to Excel</a></td>
					  </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
