<?php

		/*********************SESSION VARIABLE*********************/
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<?php
	$admID=$_GET['admID'];
	if($admID=='')
	{
		echo "<script>alert('Invalid Student Selection')</script>";
		echo "<script>document.location.href='main.php'</script>";	
	}
	$statement=$connection->prepare("select * from student where admID=:admID"); // We can use DELETE, INSERT and UPDATE QUERY as usual
	$statement->bindParam(":admID", $admID);
	$statement->execute();
	$studentTable = $statement->fetch(PDO::FETCH_ASSOC); // if row is returned from database/ table
	
	$studID=$studentTable[studID];
	$admID=$studentTable[admID];
	//$studentTable[admID];
	
	//echo "<pre>";
	//print_r($data);
?>
<section class="content table-responsive" style="font-size:8px">

	  <div class="box box-solid box-warning">
		<div class="box-header">
		  <h3 class="box-title">Student Profile...</h3>
		  <div class="box-tools pull-left">
			<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
		  </div><!-- /.box-tools -->
		</div><!-- /.box-header -->
		<div class="box-body table-responsive">
		  <table id="example3" class="table" style="font-size:12px;">
			<thead>
			  <tr>
				<th>
<div class="input-group-btn" style="width:10px; height:10px;">
	
	<button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown"> 
		<i class="glyphicon glyphicon-cog"></i>&nbsp;&nbsp;Action&nbsp;&nbsp;<span class="fa fa-caret-down"></span>
	</button>
	
	<ul class="dropdown-menu">
		<!--
			<li> <a  href='stud_pages/action_student.php?tsk=rdo&slno=<?php echo $student_slno; ?>' 
			onclick="return confirm_action('Are you sure you want to Restore the student from DROP OUT?')"> <i class="fa fa-thumbs-up" style="color:#CC0000"></i>Restore DropOut </a> </li>
					
			<li><a href="main.php?pg=view student single&slno=<?php echo $student_slno; ?>"><i class="fa fa-search" style="color:#FF9900"></i>View</a></li> 
			<li class="divider"></li>
			<li><a href="#"><i class="fa fa-file" style="color:#FF9900"></i>Issue Certificate</a></li>
			<li><a href="#"><i class="fa fa-briefcase" style="color:#FF0000"></i>Issue Material</a></li>
			<li><a href="#"><i class="fa fa-user" style="color:#CC6600"></i>Issue ID Card</a></li>
			<li class="divider"></li>
			
			<li> <a  href='stud_pages/action_student.php?tsk=do&slno=<?php echo $student_slno; ?>' 
			onclick="return confirm_action('Are you sure you want to Mark the Status of Student as DROP OUT?')"> <i class="fa fa-thumbs-down" style="color:#CC0000"></i>DropOut </a> </li>

			<li> <a  href='stud_pages/action_student.php?tsk=rdo&slno=<?php echo $student_slno; ?>' 
			onclick="return confirm_action('Are you sure you want to Restore the student from DROP OUT?')"> <i class="fa fa-thumbs-up" style="color:#CC0000"></i>Restore DropOut </a> </li>

			<li class="divider"></li>

			<li> <a href='#' onclick="showrefund_cancle()">  <i class="fa fa-chain-broken" style="color:#FF0033"></i>Refund/ Cancle</a> </li>

			<li class="divider"></li>
		-->		
		<li> <a href='#' onclick="showFeeFormService();"> <i class="fa fa-calendar-o" style="color:#C00"></i>Monthly Fee</a> </li>
		<li> <a href='#' onclick="showFeeFormMaterial();"> <i class="fa fa-shopping-cart" style="color:#006666"></i>Fee against Material</a> </li>
		<li class="divider"></li>
		<li> <a href='main.php?pg=<?php echo base64_encode('edit student');?>&slno=<?php echo $studID;?>'> <i class="fa fa-edit" style="color:#0000CC"></i>Edit Record </a> </li>
		<li> <a href='#' onclick="showupload_photo_form()"> <i class="fa fa-upload" style="color:#006666"></i>Upload Photo/ App. Form</a> </li>
		<?php 
		// Option for Administrator
		if( $_SESSION['sessionUserType']=='admin'){?>
		<li class="divider"></li>
		<li> <a  href='files/action_student.php?tsk=do&slno=<?php echo $studID; ?>' 
		onclick="return confirm_action('Are you sure you want to Mark the Status of Student as DROP OUT?')"> <i class="fa fa-thumbs-down" style="color:#CC0000"></i>DropOut </a> </li>
		<li> <a  href='files/action_student.php?tsk=rdo&slno=<?php echo $studID; ?>' 
		onclick="return confirm_action('Are you sure you want to Restore the student from DROP OUT?')"> <i class="fa fa-thumbs-up" style="color:#CC0000"></i>Restore DropOut </a> </li>
		<li class="divider"></li>
		<li> <a href='files/action_student.php?tsk=del&slno=<?php echo $studID; ?>' 
		onclick="return confirm_action('Are you sure you want to Delete the Student Record?')"> <i class="fa fa-times-circle" style="color:#FF0000"></i>Delete Record </a> </li>
		<?php 
		} 
		// Option for Administrator
		?>
	</ul>
</div>
				</th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
			  </tr>
			</thead>
			<tbody>
			  <tr>
				<td>
					<?php
					$profileImage=($studentTable[photo] != '')?$studentTable[photo]:'no_image.png';
					?>
                	<img src="001_student_photo/<?php echo $profileImage; ?>" height="80px" width="80px" class="img-circle" titile="<?php echo $studID; ?>" />
                </td>
                <td>
                	<strong>Admission Date : </strong> <?php echo format_date($studentTable['admDate']);?><br />
                    
                    <strong>Registration No.: </strong><span title="Adm ID/ Adm Month Year/ Adm Form No"> <?php echo $studentTable['formNo'];?>/<?php echo date("my",strtotime($studentTable['admDate']));?>/<?php echo $studentTable['formNoActual'];?></span><br />
                    <?php if($studentTable['rollNo']!=''){ ?>
						<strong>Roll No: </strong> <?php echo $studentTable['rollNo'];?><br />
						<strong>Batch : </strong>  <?php echo $studentTable['batchPreferene'];?><br />
						<strong>BELT : </strong>  <?php echo strtoupper($studentTable['currentBelt']);?>
                	<?php } ?>
                </td>
				<td>
                	<strong>Name : </strong> 	<?php  $studName=($studentTable['gender']=="Male")?'Mr. ':'Miss. ';?>
												<?php echo $studName .= ucwords(strtolower($studentTable['name']));?><br />
                    <strong>Father's Name : </strong> <?php echo ucwords(strtolower($studentTable['fatherName']));?><br />
                    <strong>Aadhar No. : </strong> <?php echo $studentTable['aadharNo']; //aadharPhoto?><br />
                    <strong>Date of Birth : </strong> <?php echo format_date($studentTable['dob']);?>
                </td>
				<td>
                	<strong>Mobile No. : </strong> <?php echo $studentTable['mobile'];?><br />
					<strong>WhatsApp No. : </strong> <i class="fa fa-whatsapp"></i>&nbsp;&nbsp; <?php echo ($studentTable['whatsapp']=='')?"NA":$studentTable['whatsapp'];?><br />
                    <strong>Email ID : </strong> <?php echo $studentTable['email'];?><br />
                    <strong>Address : </strong> <?php echo $studentTable['address'];?>
                </td>
				<td> 
                	
                    <strong>Blood Group : </strong> <?php echo $studentTable['bloodGroup'];?><br />
                    <strong>Height : </strong> <?php echo $studentTable['height'];?><br />
                    <strong>Weight : </strong> <?php echo $studentTable['weight'];?><br />
                    <strong>Disability : </strong> <?php echo ($studentTable['disability']==1)?$studentTable['disabilityDetail']:'None';?>
                </td>
				<td>
                	<strong>Remark : </strong> <?php echo $studentTable['remark'];?><br />
                    <strong>Status : </strong> 
					<?php 
						if($studentTable['passout']==1)
						{
							echo "<b>PASSOUT</b>";
						}
						elseif($studentTable['dropout']==1)
						{
							echo "<b>DROPOUT</b>";
						}
						elseif($studentTable['deleted']==1)
						{
							echo "<b>DELETED RECORD</b>";
						}
						else
						{
							echo "<b>Current Student</b>";
						}
					?>	
					<br />
					<span style="font-size:8px"> <?php echo $studID; ?></span>
                </td>
			  </tr>
			 
			</tbody>
			<tfoot>
			  <tr>
				<th>
					<?php 
							if($studentTable[formScan] == '' || $studentTable[photo] == '')
							{
								// Show option to upload application form
								echo "<a href='#' onclick=\"showupload_photo_form()\"> <i class=\"fa fa-upload\" style=\"color:#006666\"></i>  Upload Photo/ App. Form</a> ";
							}
							else
							{
								echo "<a href='#'>View App. Form</a>";								
							}
					?>
				</th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
			  </tr>
			</tfoot>
		  </table>
		</div><!-- /.box-body -->
	  </div><!-- /.box -->
			<?php 
					include('files/upload_photo_form.php');
					include('files/add_student_fee_material.php');
					include('files/add_student_fee_service.php');
					include('files/add_student_due_fee.php');
					include('files/add_student_due_fee_Material.php');
					include('files/view_student_status.php');
					include('files/view_fee.php');
					include('files/view_fee_material.php');
			?>

</section>