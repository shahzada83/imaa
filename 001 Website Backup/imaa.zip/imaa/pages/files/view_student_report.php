<script>
function show_criteria(ans) 
	{
	  if (ans == '6') 
	  {
	    lit = '<label class="control-label" for="inputSuccess"><i class="fa fa-check"></i>Status</label>'
		lit = lit + '<SELECT NAME="criteria" class="form-control">'
		lit = lit + '<option value="pending" <?php if($criteria=='pending'){?> selected="selected" <?php } ?>>Pending</option>'
		lit = lit + '<option value="issued" <?php if($criteria=='issued'){?> selected="selected" <?php } ?>>ISSUED</option>'
		lit = lit + '</SELECT>'
		
		document.getElementById('data').InnerHTML=lit;
	  }	
	  if (ans != '6' || ans != '9') 
	  {
	    lit = '<label class="control-label" for="inputSuccess"><i class="fa fa-check"></i>Status</label>'
		lit = lit + '<SELECT NAME="criteria" class="form-control">'
		lit = lit + '<option value="pending" <?php if($criteria=='pending'){?> selected="selected" <?php } ?>>Pending</option>'
		lit = lit + '<option value="issued" <?php if($criteria=='issued'){?> selected="selected" <?php } ?>>ISSUED</option>'
		lit = lit + '</SELECT>'
		
		document.getElementById('data').InnerHTML=lit;
	  }	
	  if (ans == '9') 
	  {
	    lit = '<label class="control-label" for="inputSuccess"><i class="fa fa-check"></i>Status (As On : <?php echo date("M-Y"); ?>)</label>'
		lit = lit + '<SELECT NAME="criteria" class="form-control">'
		lit = lit + '<option value="due" <?php if($criteria=='due'){?> selected="selected" <?php } ?>>Dues</option>'
		lit = lit + '<option value="no_due" <?php if($criteria=='no_due'){?> selected="selected" <?php } ?>>No Dues</option>'
		lit = lit + '</SELECT>'
		
		document.getElementById('data').InnerHTML=lit;
	  }
		
	 
	  if (ans == '' || ans == 'dues' ||  ans == 'part_payment' ||  ans == 'part_payment_material') 
	  {
		lit = ''
		
		document.getElementById('data').innerHTML='';
	  }
 	 document.getElementById('data').innerHTML=lit
	}
</script>	
<body onLoad="show_criteria(document.myForm.type.value)">
<form method="post" action="" enctype="multipart/form-data" name="myForm"  onSubmit="return(validate());" >
		
		<div class="box box-warning box-solid">
                <div class="box-header with-border">
                  <h3 class="box-title"><i class="fa fa-bar-chart-o"></i> View Student Report </h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="row">
					<!----------------------------------------------------->  	
					<?php
					$field		=	$_POST[field];
					$criteria	=	$_POST[criteria];
					?>
						<div class="col-md-3">
							<div class="form-group">
								<label class=""><i class="fa fa-search"></i> Search On </label>
								<select name="field" class="form-control input-sm" id="type" onChange="show_criteria(document.myForm.type.value)">
								<option value="">-Field-</option>
								
								<option value="part_payment" <?php if($field=='part_payment'){?> selected="selected" <?php } ?>>Due Fee's (SERVICE)</option>
								<option value="part_payment_material" <?php if($field=='part_payment_material'){?> selected="selected" <?php } ?>>Due Fee's (PRODUCT)</option>
								<option value="9" <?php if($field=='9'){?> selected="selected" <?php } ?>>Monthly Fee</option>
								<option value="6" <?php if($field=='6'){?> selected="selected" <?php } ?>>ID Card</option>
								<?php
								$sqlMaterial="select distinct(itemName) from studentfee";
								$statementMaterial=$connection->query($sqlMaterial);
								while($dataMaterial=$statementMaterial->fetch(PDO::FETCH_ASSOC))
								{
									if($dataMaterial[itemName]!='')
									{
								?>
									<option value="<?php echo $dataMaterial[itemName]; ?>" <?php if($field==$dataMaterial[itemName]){?> selected="selected" <?php } ?>><?php echo $dataMaterial[itemName]; ?></option>
								<?php
									}
								}
								?>	
								</select>
								<span class="error" id="eFormNo"></span>
							</div>	
						</div>
						
							<div class="col-md-3">
							
							<div class="form-group">
								<span id="data"></span>
							</div>
						</div>
						
						<div class="col-md-3">
							
							<div class="form-group">
								<br />
							<input name="showReport" type="submit" class="btn btn-primary" id="show"  onmouseover="return(validate());" value="Show Record" />
							</div>
						</div>
					<!----------------------------------------------------->	
				  </div> <!-- CLOSE ROW -->
				</div>  
        </div><!-- /.box-body -->
</form>

<?php 
if(isset($_POST[showReport]))
{
?>
<div class="box box-solid box-warning">
	<div class="box-header">
	  <h3 class="box-title">Report</h3>
	</div><!-- /.box-header -->
	<div class="box-body">
	<?php
	if(isset($_POST[showReport]))
	{
		$field		=	$_POST[field];
		$criteria	=	$_POST[criteria];
		if($field==9 && $criteria=='due')
		{
		?>
			<iframe src="files/reports/monthly_fee_dues.php" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		elseif($field==9 && $criteria=='no_due')
		{
		?>
			<iframe src="files/reports/monthly_fee_no_dues.php" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		elseif($field!=6 && $field !=9 && $criteria=='pending')
		{
		?>
			<iframe src="files/reports/material_due.php?material=<?php echo $field; ?>" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		elseif(($field!=6 && $field!=9) && $criteria=='issued')
		{
		?>
			<iframe src="files/reports/material_no_due.php?material=<?php echo $field; ?>" class="responsive" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		elseif(($field==6) && $criteria=='pending')
		{
		?>
			<iframe src="files/reports/material_due.php?material=<?php echo $field; ?>" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		elseif(($field==6) && $criteria=='issued')
		{
		?>
			<iframe src="files/reports/material_no_due.php?material=<?php echo $field; ?>" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		elseif($field=='part_payment')
		{
		?>
			<iframe src="files/reports/part_payment.php" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		elseif($field=='part_payment_material')
		{
		?>
			<iframe src="files/reports/part_payment_material.php" height="90%" width="100%" frameborder="0"></iframe>
		<?php
		}
		?>
	<?php
	}
	?>	
	</div><!-- /.box-body -->
</div><!-- /.box -->
<?php
}
?>
</body>	  

