<?php

		/*********************SESSION VARIABLE*********************/
		session_start();
		if(!isset($_SESSION['userID']))
		 {
		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";
			echo "<script>document.location.href='../index.php'</script>";
		 }	
		//*********************SESSION VARIABLE*********************/
?>
<script>
function showFeeFormMaterial()
{
		document.getElementById('formMaterial').style.display="block";
		document.getElementById('formService').style.display="none";
		document.getElementById('formDue').style.display="none";
		
		  var xhttp;    
		  var studID=document.getElementById('studID').value;
		  
		  xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			  document.getElementById("divTableAddStudentFeeMaterial").innerHTML = this.responseText;
			}
		  };
		  //alert("files/AjaxFeeMaterial/viewtemp_MaterialFee_Inadd_student_fee_material.php?studID="+studID);
		  xhttp.open("GET", "files/AjaxFeeMaterial/viewtemp_MaterialFee_Inadd_student_fee_material.php?studID="+studID, true);
		  xhttp.send();
}
function showFeeFormService()
{
		document.getElementById('formService').style.display		="block";
		document.getElementById('formMaterial').style.display		="none";
		document.getElementById('formDue').style.display			="none";
		document.getElementById('formStudentItemDue').style.display	="none";
}
function showDueFeeService()
{
		document.getElementById('formDue').style.display			="block";
		document.getElementById('formService').style.display		="none";
		document.getElementById('formMaterial').style.display		="none";
		document.getElementById('formStudentItemDue').style.display	="none";
}
function showDueFeeItemFn()
{
		document.getElementById('formStudentItemDue').style.display	="block";
		document.getElementById('formDue').style.display			="none";
		document.getElementById('formService').style.display		="none";
		document.getElementById('formMaterial').style.display		="none";
}
</script>

<div class="box box-solid box-info">
	<div class="box-header">
	  <h3 class="box-title" style="color:#000"><i class="fa fa-info-circle"></i> <strong>Student Status</strong></h3>
	  	<div class="box-tools pull-left">
			<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
		</div><!-- /.box-tools -->
	</div><!-- /.box-header -->
	<div class="box-body" style="font-size:12px;">
		<!--  Show all those Fee Head whose payment has not been paid by the student -->
		<div class="row">
			<div class="col-md-8">
				<?php
				// ************************************************** LOOP BEGINS **************************************************
				// Show all those Fee Head whose payment has not been paid by the student
				$sqlfeeDetail="SELECT `type`, `feeDetailID`, `head`, `amount` FROM `feedetail` FD WHERE NOT EXISTS (SELECT  `feeDetailID`, `feeForMonth`  FROM `studentfee` SF WHERE FD.`feeDetailID` = SF.`feeDetailID` AND FD.`feeDetailID` !=9 AND SF.`studID`='$studID'  ORDER BY SF.`feeID` DESC)";
				
				$statementFeeDetail=$connection->query($sqlfeeDetail);
				$statementFeeDetail->execute();
				
				while($fieldFeeDetail=$statementFeeDetail->fetch(PDO::FETCH_ASSOC))
				{
						// If fee for material is due prepare the string to display to the user
						if($fieldFeeDetail[type]=='Material')
						{
							$material .= $fieldFeeDetail[head] . ", ";	
						}
						// If fee for service is due prepare the string to display to the user						
						elseif($fieldFeeDetail[type]=='Service')
						{
							$service .= $fieldFeeDetail[head] . ", ";	
						}
					
						$showButton=true;
						
						if($fieldFeeDetail[head]=='Monthly Fee')
						{
							$monthlyFee=$fieldFeeDetail[amount];
						}
						
				?>
				
				<?php
				} // Clode While
				
				// Remove last ciomma from string
				 $service = substr(trim($service), 0, -1);
				 echo " <strong>FEE DUE AGAINST SERVICE FEE: </strong> &nbsp;&nbsp;&nbsp;<span style='font-size:14px; color:#C00'><b>$service</b></span><br>";
				 $material = substr(trim($material), 0, -1);
				 echo " <strong>FEE DUE AGAINST MATERIAL FEE: </strong> &nbsp;&nbsp;&nbsp;<span style='font-size:14px; color:#C00'><b>$material</b></span>";
				 
				?>
			</div>
			
		</div>	
		
		<!--  Show all those Dues (Monthly Fee) whose payment has not been paid by the student -->
		<div class="row">
			<div class="col-md-8">
				<?php
								
					//Find out the monthly fee Dues by the student
					$sqlDue="SELECT SUM(dues) as due from `studentfee` where `studID`='$studID' and `itemName`=''";
					$statmentDue = $connection -> query($sqlDue);
					$feeDue = $statmentDue->fetch(PDO::FETCH_ASSOC);
					if($feeDue[due])
					{
						echo "<h5 style='color:#C00' >Total Dues On <u>\"$studName\"</u> Against <span class='label label-warning'> <i class='fa fa-check-square-o'></i> SERVICE FEE </span>: <b>Rs. " .ceil($feeDue[due]) ." </b> <a class='badge bg-green' data-toggle='modal' data-target='#myModal'>View Detail</a></h5>";
					}
					
					?>
					<!------------MODAL STARTS -------->
						<!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>-->
						
						<!-- Modal -->
						<div id="myModal" class="modal fade" role="dialog">
						  <div class="modal-dialog">
						
							<!-- Modal content to show fee receipts-->
							<div class="modal-content" style="width:800px">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Due Details of <?php echo $studName; ?></h4>
							  </div>
							  <div class="modal-body">
								
								<div class="box-body no-padding">
								  <table class="table table-condensed">
									<tr>
									  <th style="width: 10px">SL.No</th>
									  <th>Date</th>
									  <th>Receipt No.</th>
									  <th>Fee Head</th>
									  <th>Month</th>
									  <th>Pay Mode</th>
									  <th>Amount</th>
									  
									  <th>Discount</th>
									  <th>Dues</th>
									  <th>Late Fine</th>
									  
									  <th>Paid</th>
									</tr>
									<?php
									
									$sqlDues="SELECT studentfee.*, feedetail.head from studentfee, feedetail where feedetail.feeDetailID = studentfee.feeDetailID and studentfee.dues!=0 and studentfee.studID='$studID' and itemName='' ORDER BY studentfee.receiptNo";
									$statementDue=$connection->query($sqlDues);
									while($dataDue=$statementDue->fetch(PDO::FETCH_ASSOC))
									{
										++$slnoDue1;
									?>
									<tr>
									  <td><?php echo $slnoDue1; ?></td>
									  <td><?php echo format_date($dataDue[payDate]); ?></td>
									  <td><?php echo $dataDue[receiptNo]; ?></td>
									  <td><?php echo $dataDue[head]; ?><?php echo $dataDue[itemName]; ?></td>
									  <td><?php echo $dataDue[feeForMonth]; ?></td>
									  <td><?php echo $dataDue[payMode]; ?></td>
									  <td><?php echo $dataDue[amount]; $amountTotal2 += $dataDue[amount];?></td>
									  <td><?php echo $dataDue[discount]; $discount2 += $dataDue[discount];?></td>
									  <td style="color:#C00"><?php echo $dataDue[dues]; $dues2 += $dataDue[dues]; ?></td>
									  <td><?php echo $dataDue[lateFine]; $lateFine2 += $dataDue[lateFine]; ?></td>
									  <td><?php echo $net = $dataDue[amount]-$dataDue[discount]-$dataDue[dues]+$dataDue[lateFine]; $totalNet2 += $net; ?></td>
									</tr>
									<?php
									}
									?>
									<tr>
									  <td colspan="6" align="right"><b>TOTAL : </b></td>
									  
									  <td><b><?php echo $amountTotal2;?></b></td>
									  <td><b><?php echo $discount2;?></b></td>
									  <td style="color:#C00"><b><?php echo $dues2; ?></b></td>
									   <td><b><?php echo $lateFine2; ?></b></td>
									  <td><b><?php echo $totalNet2; ?></b></td>
									</tr>
								  </table>
								</div>
								
							  </div>
							  <div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							  </div>
							</div>
						
						  </div>
						</div>
					<!----------MODAL ENDS ---------->
			</div>
			<div class="col-md-4">
				<?php
					if($feeDue[due]>0)	
					{
						$buttonDUES=true;
				?>
					<br />
					<a href="#" onclick="showDueFeeService();" class="btn btn-success"><i class="fa fa-rupee" style="color:#FFFFFF"></i> &nbsp;&nbsp;&nbsp;Update Service Due Fee</a>
				<?php		
					}
				?>	
			</div>
		</div>
		<br>
		<!--  Show all those Months (Monthly Fee) whose payment has not been paid by the student -->
		<div class="row">
			<div class="col-md-8">
				<?php
					 $date1=date($studentTable['admDate']);
					 $date2=date("Y-m-d");
					 $monthDiff= month_difference($date1, $date2); // Total Months passes since admission till date
					
					
					//Find out the monthly fee not paid by the student, show the Month and Year in the control  accordangly
					//If $fieldFeeDetail[head] == 'Monthly Fee' then the student has not paid any month fee, in this case find out the ADMISSION Month of the student
					$sqlMonth="SELECT `feeForMonth` from `studentfee` where `studID`='$studID' and `feeDetailID`=9  ORDER by feeID";
					$statmentMonth = $connection -> query($sqlMonth);
					$statmentMonth -> execute();
					$feePaid = $statmentMonth -> rowCount();// Total Fee paid for month as per database
					$totalMonth=($monthDiff - $feePaid)+1;
					//$showButton=true;
						if($totalMonth < 0)
						{
							echo "<strong style='font-size:18px; color:#030;'>Monthly Fee for ". convert_number(abs($totalMonth)) . " Month,  PAID in Advance.";
							$showButton2=true;
						}	
						elseif($totalMonth == 0)	
						{
							echo "<h5 style='color:#006600;'>Monthly Fee Paid Till Current Month.</h5>";
							$showButton2=true;
						}	
						elseif($totalMonth > 0)	
						{
							echo "<strong style='font-size:12px; color:#FF0000;'>Monthly Fee DUE for {$totalMonth} Months. </strong> (<strong>TOTAL DUE AMOUNT :  <span style='color:#FF0000; font-size:20px;'>Rs. " . $monthlyFee*($totalMonth) . "</strong></span>)";	
							$showButton2=true;
						}	
					
					?>
			</div>
			<div class="col-md-4">
						<?php 
						if($showButton2==true) 
						{
						?>
							<a href="#" onclick="showFeeFormService();" class="btn btn-danger"><i class="fa fa-calendar" style="color:#FFFFFF"></i> &nbsp;&nbsp;&nbsp;Update Monthly Fee</a>
						<?php 
						} 
						?>
			</div>
		</div>
		<br />
		
		<!--  Show all those Dues (item) whose payment has not been paid by the student -->
		<div class="row">
			<div class="col-md-8">
				<?php
								
					//Find out the item  Dues by the student
					$sqlDueItem="SELECT SUM(dues) as due from `studentfee` where `studID`='$studID' and `itemName`!=''";
					$statmentDueItem = $connection -> query($sqlDueItem);
					$feeDueItem = $statmentDueItem->fetch(PDO::FETCH_ASSOC);
					if($feeDueItem[due])
					{
						echo "<h5 style='color:#C00' >Total Dues On <u>\"$studName\"</u> Against <span class='label label-danger'> <i class='fa fa-shopping-cart'></i> PRODUCT FEE </span>: <b>Rs. $feeDueItem[due] </b> <a class='badge bg-green' data-toggle='modal' data-target='#myModalItem'>View Detail</a></h5>";
					}
					?>
					<!------------MODAL STARTS -------->
						<!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>-->
						
						<!-- Modal -->
						<div id="myModalItem" class="modal fade" role="dialog">
						  <div class="modal-dialog">
						
							<!-- Modal content to show fee receipts-->
							<div class="modal-content" style="width:800px">
							  <div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">&times;</button>
								<h4 class="modal-title">Due Details of <?php echo $studName; ?></h4>
							  </div>
							  <div class="modal-body">
								
								<div class="box-body no-padding">
								  <table class="table table-condensed">
									<tr>
									  <th style="width: 10px">SL.No</th>
									  <th>Date</th>
									  <th>Receipt No.</th>
									  <th>Pay Mode</th>
									  <th>Item</th>
									  <th>Price</th>
									  <th>Discount</th>
									  <th>Dues</th>
									  <th>Paid</th>
									</tr>
									<?php
									
									$sqlDuesItem="SELECT studentfee.* from studentfee  where studentfee.dues!=0 and studentfee.studID='$studID' and itemName!='' ORDER BY studentfee.receiptNo";
									$statementDueItem=$connection->query($sqlDuesItem);
									while($dataDueItem=$statementDueItem->fetch(PDO::FETCH_ASSOC))
									{
										++$slnoDue3;
									?>
									<tr>
									  <td><?php echo $slnoDue3; ?></td>
									  <td><?php echo format_date($dataDueItem[payDate]); ?></td>
									  <td><?php echo $dataDueItem[receiptNo]; ?></td>
									  <td><?php echo $dataDueItem[payMode]; ?></td>
									  <td><?php echo $dataDueItem[itemName]; ?></td>
									  <td><?php echo $dataDueItem[amount]; $amountTotal3 += $dataDueItem[amount];?></td>
									  <td><?php echo $dataDueItem[discount]; $discount3 += $dataDueItem[discount];?></td>
									  <td style="color:#C00"><?php echo $dataDueItem[dues]; $dues3 += $dataDueItem[dues]; ?></td>
									  <td><?php echo $dataDueItem[receivedAmount]; $receivedAmount3 += $dataDueItem[receivedAmount]; ?></td>
									</tr>
									<?php
									}
									?>
									<tr>
									  <td colspan="5" align="right"><b>TOTAL : </b></td>
									  
									  <td><b><?php echo $amountTotal3;?></b></td>
									  <td><b><?php echo $discount3;?></b></td>
									  <td style="color:#C00"><b><?php echo $dues3; ?></b></td>
									  
									 
									  <td><b><?php echo $receivedAmount3; ?></b></td>
									</tr>
								  </table>
								</div>
								
							  </div>
							  <div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							  </div>
							</div>
						
						  </div>
						</div>
					<!----------MODAL ENDS ---------->
			</div>
			<div class="col-md-4">
				<?php
					if($feeDueItem[due]>0)	
					{
						$buttonDUESitem=true;
				?>
					<br />
					<a href="#" onclick="showDueFeeItemFn();" class="btn btn-success"><i class="fa fa-rupee" style="color:#FFFFFF"></i> &nbsp;&nbsp;&nbsp;Update Product Due Fee</a>
				<?php		
					}
				?>	
			</div>
		</div>
		<br />
		
		<!--  Show all those Fee head for which material has not been issued against payment collected -->
		<div class="row">
		<?php
		// Material Issue Details/ Status
		$sqlMaterial="SELECT `studentfee`.`feeID`, `studentfee`.`receiptNo`,`studentfee`.`feeDetailID`,`studentfee`.`amount`, `studentfee`.`receivedAmount`,`materialdetail`.* from `studentfee`, `materialdetail` 
					where `studentfee`.`studID`='$studID' and `studentfee`.`stockIssueID`=0 AND `studentfee`.`duesRemark`='' AND `studentfee`.`dues`=0 and `studentfee`.`feeDetailID` != 9 and `studentfee`.`feeDetailID`=`materialdetail`.`materialID` ORDER by feeID";
		
		$statmentMaterial = $connection -> query($sqlMaterial);
		$statmentMaterial -> execute();
		
		while($statusMaterial = $statmentMaterial->fetch(PDO::FETCH_ASSOC))
		{
			$product =($statusMaterial[itemName]=='Admission Fee')?'ID Card':$statusMaterial[itemName];
			$feeID=$statusMaterial[feeID];// to alter the record
			$materialID=$statusMaterial[feeDetailID];
			$quality=$statusMaterial[quality];
			$size=$statusMaterial[size];
			$receiptNo=$statusMaterial[receiptNo];
			$paid=$statusMaterial[receivedAmount]
		?>
		<div class="col-md-3">
			<div class="popover-markup" data-toggle="popover">
				<a href='#' class='trigger btn btn-primary'><i class='fa fa-ticket' style='color:#FFFFFF'></i> &nbsp;&nbsp;&nbsp;ISSUE <?php echo $product; ?> </a>
				<div class="head hide"  data-placement="right">
					<!-- Heading Goes -->
					<strong>
					<?php
					// Pass material type through heading
					echo $product;
					 // Track the feeID to update the record stockIssueID in studentfee table
					?>
					Issue Form
					
					</strong>
					<!-- Heading Ends-->
				</div>
				<div class="content hide">
					<!-- Popover Content Goes Here -->	
						<?php 
						// Check if stock exists in stockSummery
						$sqlCheckStockSummery="SELECT (StockReceived-StockIssued) as `stock` from `materialdetail` where `materialID`='$materialID'";
						$stmtCheckStockSummery=$connection->query($sqlCheckStockSummery);
						$dataStockSummery=$stmtCheckStockSummery->fetch(PDO::FETCH_ASSOC);
						if($dataStockSummery[stock]>0)
						{
							include('files/issue_Material.php'); 
							
							echo "<table id='example1' class='table table-bordered table-striped table-responsive'>
								<tr class='info'>
									<th>Item</th>
									<th>Quality</th>
									<th>Size</th>
								</tr>
								<tr class='warning'>
									<td>{$product}</td>
									<td>{$quality}</td>
									<td>{$size}</td>
								</tr>
							</table>";		
							echo "<center><span class='badge bg-green'>STOCK IN HAND : " . $dataStockSummery[stock] . "</span>";
							echo "<span class='label label-primary' style='font-size:12px'>Paid : Rs. " . $paid . "</span> &nbsp; &nbsp; &nbsp; <span class='label label-danger' style='font-size:12px'>Receipt No. : {$receiptNo}</span></center>"; 
							  
						}
						else
						{
							
							echo "<span class='label label-danger' style='font-size:16px'>SORRY! NO STOCK</span></center>"; 
							
							echo "<table id='example1' class='table table-bordered table-striped table-responsive'>
								<tr class='info'>
									<th>Item</th>
									<th>Quality</th>
									<th>Size</th>
								</tr>
								<tr class='warning'>
									<td>{$product}</td>
									<td>{$quality}</td>
									<td>{$size}</td>
								</tr>
							</table>";	
						}
						
						
						?>
					<!-- Popover Content Ends Here -->
				</div> <!-- .content hide -->
			</div>	
		</div>	
		
		<?php
		}
		?>
		</div>
			
	</div><!-- /.box-body -->
</div><!-- /.box -->

<?php 
						if($showButton2==true) 
						{
						?>
							<a href="#" onclick="showFeeFormService();" class="btn btn-danger"><i class="fa fa-calendar" style="color:#FFFFFF"></i> &nbsp;&nbsp;&nbsp;Update Monthly Fee</a>
						<?php 
						} 
						
						?>&nbsp;&nbsp;&nbsp;
<button type="button" class="btn btn-warning " data-toggle="modal" data-target="#materialSales"> <i class="fa fa-shopping-cart"></i> &nbsp;&nbsp;&nbsp; Sales</button>&nbsp;&nbsp;&nbsp;
<a href='#' onclick="showFeeFormMaterial();" class="btn btn-primary pull-right"> <i class="fa fa-shopping-cart"></i> &nbsp;&nbsp;&nbsp; Show Added Item List</a>&nbsp;&nbsp;&nbsp;
<?php
// if student have due then show due button
if($buttonDUES==true)
{
?>
<a href='#' onclick="showDueFeeService();" class="btn btn-success"> <i class="fa fa-rupee"></i> &nbsp;&nbsp;&nbsp;Update Due Fee</a>
<?php
}
?>
<br /><br />
<!------------MODAL STARTS -------->
	<!-- Modal -->
	<div id="materialSales" class="modal fade" role="dialog">
	  <div class="modal-dialog" style="width:90%">
	
		<!-- Modal content to show fee receipts-->
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Add Material for Sale to <?php echo $studName; ?></h4>
		  </div>
		  <div class="modal-body">
			
			<div class="box-body no-padding">
			  
			<?php   include('files/addfeeMaterialAjax.php'); ?>
			  
			</div>
			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal" onclick="showFeeFormMaterial();">Done</button>
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  </div>
		</div>
	
	  </div>
	</div>
<!----------MODAL ENDS ---------->