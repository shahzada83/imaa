
<?php
session_start();//error_reporting(0);/*echo "<script>alert(".$_SESSION['userID'].")</script>";
		/*********************SESSION VARIABLE*********************/		if(!isset($_SESSION['userID']))		 {		 	echo "<script>alert('Un-authorized Access. Please Login')</script>";			echo "<script>document.location.href='../index.php'</script>";		 }	
		//*********************SESSION VARIABLE*********************/

		include('files/menu.php');		include('files/dbconn.php');		include('files/database.php');		include('files/API.php');
?>		
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>IMAA</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- iCheck for checkboxes and radio inputs -->
    <link href="plugins/iCheck/all.css" rel="stylesheet" type="text/css" />
    <!-- Bootstrap Color Picker -->
    <link href="plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet"/>
    <!-- Bootstrap time Picker -->
    <link href="plugins/timepicker/bootstrap-timepicker.min.css" rel="stylesheet"/>
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="plugins/iCheck/all.css" rel="stylesheet" type="text/css" />
	<!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
	
	<style>
		label, td, tr		{			font-size:12px;		}
	</style>
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
      <header class="main-header">
        <a href="main.php" class="logo">
			<p></p><img src="../img/logoimaa.png" height="" width="" class="img-responsive">
		</a>
		
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Tasks: style can be found in dropdown.less -->
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="001_student_photo/<?php echo $_SESSION['sessionUserImage']; ?>" class="user-image" alt="User Image"/>
                  <span class="hidden-xs"><?php echo $_SESSION['sessionUserName']; ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
				  	<img src="001_student_photo/<?php echo $_SESSION['sessionUserImage']; ?>" class="img-circle" alt="User Image"/>
                    <p>
                      <strong><?php echo $_SESSION['sessionUserName']; ?></strong> <br> 
					  <?php echo $_SESSION['sessionUserDesignation']; ?>
                      <small>Member Since :  <?php echo date("d - M - Y",$_SESSION['sessionUserTime']); ?> </small>
					  
					   <?php
					   	/*
					  	echo $_SESSION['userID'];
						echo $_SESSION['sessionUserName'];
						echo $_SESSION['sessionUserType'];
						echo $_SESSION['sessionUserImage'];
						echo $_SESSION['sessionUserDesignation'];
						echo $_SESSION['sessionUserTime'];
						*/
					  ?>
                    </p>
                  </li>
                  <!-- Menu Body -->
                 
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="main.php?pg=<?php base64_encode('password'); ?>" class="btn btn-default btn-flat">Change Password</a>
                    </div>
					
                    <div class="pull-right">
                      <a href="main.php?pg=<?php echo base64_encode("logout");?>" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
		  
		  
		  
            <div class="pull-left image">
             <img src="001_student_photo/<?php echo $_SESSION['sessionUserImage']; ?>" class="img-circle" alt="User Image"/>
            </div>
            <div class="pull-left info">
              <p><?php echo $_SESSION['sessionUserName']; ?></p>

              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
          <form action="" method="get" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="searchName" class="form-control" placeholder="Search Student name" list="StudName" />
			  	<datalist id="StudName">
					<?php
					$sqlStudName="SELECT admID, name, formNo from student order by name";
					$statementStudentName=$connection->query($sqlStudName);
					while($dataStudentName=$statementStudentName->fetch(PDO::FETCH_ASSOC))
					{
					?>
					<option><?php echo ucwords(strtolower($dataStudentName[name])); ?>-<?php echo $dataStudentName[formNo]; ?>-<?php echo $dataStudentName[admID]; ?></option>
					<?php
					}
					?>
				</datalist>
				
				
              <span class="input-group-btn">
                <button type='submit' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
		  
		  <?php
		  if(isset($_GET[searchName]))
		  {
				$name=$_GET[searchName];
				$admID=end(explode('-', $name));
				if($admID=='')
				{
						echo "<script>document.location.href='main.php?'</script>"  ;	
				}
				else
				{
					echo "<script>document.location.href='main.php?pg=".base64_encode('profile') ."&admID={$admID}'</script>"  ;
				}
	  	  }
		  ?>
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <!-- <li class="header">HEADER</li>
            <!-- Optionally, you can add icons to the links 
            <li class="active"><a href="#"><span>Link</span></a><</li>
            <li><a href="#"><span>Another Link</span></a></li> -->
			<?php
			foreach($menu as $mmkey=>$mmvalue)
			{
			?>
            <li class="treeview">
              <a href="#"><i class="fa fa-arrow-circle-right"></i><span><?php echo ucwords($mmkey); // echo Menu Heading ?></span> 
			  <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
			  		<?php
					foreach($mmvalue as $sm)
					{
					?>
                <li><a href="main.php?pg=<?php echo base64_encode($sm); ?>"><i class="fa fa-check-square-o"></i>
				<?php echo ucwords($sm); // echo Sub Menu Heading ?></a></li>
                	<?php
					}
					?>
              </ul>
			  
			 </li> <!-- / li treeview  -->
			<?php
			} // for($menu as $mmkey=>$mmvalue)
			?>
          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
       <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
		<?php if($_GET['pg']=="Add Student"){?>
          <h1>
            Student's Section
            <!-- <small>Optional description</small> -->
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-eye"></i> View Students</a> | </li> 
            <li><a href="#"><i class="fa fa-th"></i> View Status</a></li>
          </ol>
        </section>
		<?php } ?>
        <!-- Main content -->
      
			  
			     <!-- Your Page Content Here -->
			     <?php
			   
			   $pg=$_GET['pg'];
			   
			   //include('LMS_pages/add_students_new.php');
			   switch(base64_decode($pg))
			   {
			   		
					case 'sale': // view student
						include('files/AjaxFeematerial/add_material_fee.php');
					break;
					
					//------------------------------Administrator Option Starts------------------------------//
					
					case 'add user': // view student
						include('files/admin/add_user.php');
					break;
					
					case 'view fee receipt': // view student
						include('files/view_fee_receipt_admin.php');
					break;
					
					case 'view user': // view student
						include('files/admin/view_user.php');
					break;
					
					case 'add fee head': // view student
						include('files/admin/add_feeHead.php');
					break;
					
					case 'add product': // view student
						include('files/admin/add_MaterialHead.php');
					break;
					
					case 'create/ modify batch': // view student
						include('files/admin/studentBatch.php');
					break;
					
					case 'backup database': // view student
						include('files/backupDatabase.php');
					break;
					
					
					//------------------------------Administrator Option Ends------------------------------//
					
					// Student Menu
			   		case 'logout': // Add Student
						session_unset(); 
						session_destroy();
						echo "<script>document.location.href='../index.php'</script>";
					break;
					
					case 'password': // Add Student
						include('files/edit_password.php');
					break;
					case 'exam date': 						include('files/exam_date.php');					break;
					// Student Menu
			   		case 'admission': // Add Student
						include('files/add_student.php');
					break;
					case 'edit student': // Add Student
						include('files/edit_student.php');
					break;
					case 'view students': // view student
						include('files/view_student_list.php');
					break;
					case 'reports': // view student
						include('files/view_student_report.php');
					break;
					case 'profile': // view student
						include('files/view_student_profile.php');
					break;
					
					//stock
					case 'add stock': // view student
						include('files/add_stock.php');
					break;
					
					case 'view stock': // view student
						include('files/view_stock.php');
					break;
					
					//-----------------------------------------------
					case 'grading form': // view student
						include('files/grading_form.php');
					break;										case 'report and result': // view student
						include('files/grading_report_result.php');
					break;										
					//-----------------------------------------------
					default:
						include('files/home_page.php');
					
			   }
			   ?>
	        

<!-- Small modal -->

<!-- POPOVER for Update START ----------------->	
<!------------REFERENCE http://wolfslittlestore.be/2013/12/easy-popovers-with-bootstrap/ ---------->


</div><!---------------------->			
<!-- /.content-wrapper -->
      <footer class="main-footer small">
        <div class="pull-right hidden-xs pull-right">
		<a href="http://www.acas.co.in" target="_blank">
         <img src="001_student_photo/logo.png" height="25%" width="25%" class="img-responsive pull-right" alt="ACAS Pvt Ltd" title="Developed and Managed By">
		</a> 
        </div>
        <strong>Copyright &copy; 2017-2018 <a href="http://www.imaakarate.com">International Martial Arts Academy</a>.</strong> All rights reserved.
      </footer>
    </div><!-- ./wrapper -->

	<link rel="stylesheet" href="dist/datepicker.css">
    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- InputMask -->
    <script src="plugins/input-mask/jquery.inputmask.js" type="text/javascript"></script>
    <script src="plugins/input-mask/jquery.inputmask.date.extensions.js" type="text/javascript"></script>
    <script src="plugins/input-mask/jquery.inputmask.extensions.js" type="text/javascript"></script>
    <!-- date-range-picker -->
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- bootstrap color picker -->
    <script src="plugins/colorpicker/bootstrap-colorpicker.min.js" type="text/javascript"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.min.js" type="text/javascript"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
    <!-- Page script -->
    <script type="text/javascript">
      $(function () {
        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
        //Datemask2 mm/dd/yyyy
        $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
        //Money Euro
        $("[data-mask]").inputmask();

        //Date range picker
        $('#reservation').daterangepicker();
        //Date range picker with time picker
        $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
        //Date range as a button
        $('#daterange-btn').daterangepicker(
                {
                  ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                    'Last 7 Days': [moment().subtract('days', 6), moment()],
                    'Last 30 Days': [moment().subtract('days', 29), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                  },
                  startDate: moment().subtract('days', 29),
                  endDate: moment()
                },
        function (start, end) {
          $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
        );

        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
          checkboxClass: 'icheckbox_minimal-blue',
          radioClass: 'iradio_minimal-blue'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
          checkboxClass: 'icheckbox_minimal-red',
          radioClass: 'iradio_minimal-red'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
          checkboxClass: 'icheckbox_flat-green',
          radioClass: 'iradio_flat-green'
        });

        //Colorpicker
        $(".my-colorpicker1").colorpicker();
        //color picker with addon
        $(".my-colorpicker2").colorpicker();

        //Timepicker
        $(".timepicker").timepicker({
          showInputs: false
        });
      });
    </script>
	
	<!-- DATA TABES SCRIPT -->
    <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
	<script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
	  
	  <!-- DATA TABES SCRIPT ENDS-->
<!-- POPOver -->	
$('.popover-markup > .trigger').popover({
    html : true,
    title: function() {
      return $(this).parent().find('.head').html();
    },
    content: function() {
      return $(this).parent().find('.content').html();
    },
    container: 'body',
    placement: 'top'
});

<!-- POPOver -->

    </script>
	
	
	
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});
</script>

  </body>
</html>
