<script>
	document.location.href="imaa/index.php";
</script>